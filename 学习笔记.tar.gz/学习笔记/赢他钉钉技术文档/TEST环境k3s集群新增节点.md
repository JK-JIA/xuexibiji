# TEST环境k3s集群新增节点

### 基础环境配置

1  ssh开启 root 密码登录

```shell
vim /etc/ssh/sshd_config

PermitRootLogin yes
PasswordAuthentication yes
```

2 如果无法登录，查看 root 账户是否被锁定

```shell
root@root:~# passwd -S root
# L 表示锁定，重设密码可以解决
root L 07/31/2024 0 99999 7 -1   

root@root:~# passwd root
root@root:~# passwd -S root
root P 07/31/2024 0 99999 7 -1
```

3 配置阿里云apt源

```shell
cp -a /etc/apt/sources.list /etc/apt/sources.list-bak
vim /etc/apt/sources.list

deb https://mirrors.aliyun.com/ubuntu/ focal main restricted universe multiverse
deb-src https://mirrors.aliyun.com/ubuntu/ focal main restricted universe multiverse

deb https://mirrors.aliyun.com/ubuntu/ focal-security main restricted universe multiverse
deb-src https://mirrors.aliyun.com/ubuntu/ focal-security main restricted universe multiverse

deb https://mirrors.aliyun.com/ubuntu/ focal-updates main restricted universe multiverse
deb-src https://mirrors.aliyun.com/ubuntu/ focal-updates main restricted universe multiverse

# deb https://mirrors.aliyun.com/ubuntu/ focal-proposed main restricted universe multiverse
# deb-src https://mirrors.aliyun.com/ubuntu/ focal-proposed main restricted universe multiverse

deb https://mirrors.aliyun.com/ubuntu/ focal-backports main restricted universe multiverse
deb-src https://mirrors.aliyun.com/ubuntu/ focal-backports main restricted universe multiverse
```
```plaintext
apt update
```

4 安装常用工具

```plaintext
sudo apt install -y  curl wget git vim unzip net-tools 
```

5 关闭防火墙

```plaintext
ufw status
Status: active

ufw disable
```

6 关闭selinux，默认是不安装selinux

```plaintext
getenforce
Command 'getenforce' not found, but can be installed with:
apt install selinux-utils
```

7 优化内核参数

```plaintext
cat >> /etc/sysctl.conf << EOF
net.ipv4.ip_forward = 1  
net.ipv4.conf.all.proxy_arp = 1
EOF

sysctl -p /etc/sysctl.conf
```

8 设置hostname，两台机器不能一样

```plaintext
root@root:~# cat /etc/hostname 
master01

root@root:~# cat /etc/hosts
127.0.0.1 localhost
127.0.1.1 master01
192.168.3.102 master02
```

安装部署

两种方式

1.  使用内置 etcd 集群
    
2.  使用单独部署的 etcd 集群
    

### k3s 集群新增节点

**一、master-server 角色加入集群**

1 在 master节点( 192.168.3.204 )查看加入集群需要的 token

```shell
cat /var/lib/rancher/k3s/server/node-token
K10d7014685ddbdf915b6a66b6d5edfd111d13f30507ce085432ec8d53fa7cf86de::server:d7c3371a24fca48762bc6234c7907d6e
```

2 node节点 安装 k3s server 并加入集群, --cluster-init 参数用master角色加入k3s集群

以 master 角色加入集群

```c
curl -sfL https://rancher-mirror.rancher.cn/k3s/k3s-install.sh |  INSTALL_K3S_VERSION=v1.26.8+k3s1 \
INSTALL_K3S_MIRROR=cn sh -s - \
--server https://192.168.3.204:6443 \
--token K10d7014685ddbdf915b6a66b6d5edfd111d13f30507ce085432ec8d53fa7cf86de::server:d7c3371a24fca48762bc6234c7907d6e
```

 忽略 k3s 没启动起来的报错

安装 supervisorctl 管理工具

```c
apt install supervisor
```

编写 k3s-server 启动脚本

```c
cd  /etc/supervisor/conf.d
  
cat k3sserver.conf 
[program:k3sserver]
command=/usr/sbin/k3s server
    --kube-proxy-arg "proxy-mode=ipvs"
    --disable traefik
    --disable servicelb
    --flannel-iface ens32
    --node-ip 192.168.3.208
    --kubelet-arg=max-pods=300
    --datastore-endpoint "https://192.168.3.201:2379"
    --datastore-cafile "/etc/etcd/ca.pem"
    --datastore-certfile "/etc/etcd/etcd.pem"
    --datastore-keyfile "/etc/etcd/etcd-key.pem"
    --token K10d7014685ddbdf915b6a66b6d5edfd111d13f30507ce085432ec8d53fa7cf86de::server:d7c3371a24fca48762bc6234c7907d6e 
stderr_logfile=/var/log/k3sserver.err.log
stdout_logfile=/var/log/k3sserver.out.log
```

启动服务

```c
supervisorctl reread
supervisorctl update
```
```c
supervisorctl status
k3sserver                        RUNNING   pid 26634, uptime 0:07:56
```

重启 k3s 服务

```plaintext
supervisorctl stop  k3sserver
supervisorctl start k3sserver
```

在 master 节点，查看 node ，是否正常

```c
kubectl get node 
NAME       STATUS                     ROLES                  AGE      VERSION
sh-3-204   Ready,SchedulingDisabled   control-plane,master   3y281d   v1.26.8+k3s1
sh-3-208   Ready                      control-plane,master   169d     v1.26.8+k3s1
sh-3-220   Ready                      control-plane,master   8m27s    v1.26.8+k3s1
sh-3-233   Ready                      control-plane,master   679d     v1.26.8+k3s1
yt-dev1    Ready,SchedulingDisabled   control-plane,master   524d     v1.26.8+k3s1

```

配置镜像加速

```c
vim /etc/rancher/k3s/registries.yaml
mirrors:
  quay.io:
    endpoint:
      - quay.m.daocloud.io
      - https://y9nssnda.mirror.aliyuncs.com
  docker.io:
    endpoint:
      - docker.m.daocloud.io
      - https://y9nssnda.mirror.aliyuncs.com
  gcr.io:
    endpoint:
      - gcr.m.daocloud.io
      - https://y9nssnda.mirror.aliyuncs.com
  ghcr.io:
    endpoint:
      - ghcr.m.daocloud.io
      - https://y9nssnda.mirror.aliyuncs.com
  
```

**二、以 k3s agent 角色加入集群** 

```c
 以 k3s agent 角色加入集群 
 (K3S_URL替换为你自己的server ip， NODE_TOKEN 使用2步骤查看的token)

curl -sfL https://rancher-mirror.rancher.cn/k3s/k3s-install.sh | INSTALL_K3S_VERSION=v1.26.8+k3s1 K3S_URL=https://192.168.3.204:6443 K3S_TOKEN=K10d7014685ddbdf915b6a66b6d5edfd111d13f30507ce085432ec8d53fa7cf86de::server:d7c3371a24fca48762bc6234c7907d6e sh -s -
```