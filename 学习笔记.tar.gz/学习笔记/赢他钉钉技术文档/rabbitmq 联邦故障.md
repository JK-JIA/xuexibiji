# rabbitmq 联邦故障

生产环境 mq 联邦集群消息同步规则：hk >eu，us  ；  eu > hk ； us > hk

mq 联邦原理和配置，见架构文档：[《跨区域Dubbo和消息互通》](https://alidocs.dingtalk.com/api/doc/transit?dentryUuid=kDnRL6jAJM34oyx4HLeo9lqAWyMoPYe1&queryString=utm_medium%3Ddingdoc_doc_plugin_card%26utm_source%3Ddingdoc_doc)

![image](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/a/RygEoJnkbuy3oX43/9787b708cffd4e04a90cd87151287fce0454.png)

### 一  集群名字冲突

事故现象：

生产环境发现 rabbitmq 联邦消息，hk 发出，eu 和 us 只有一边可以收到；

正常应该是 hk 发消息， eu 和 us 都会收到；

原因：

eu mq 集群 和 us mq集群名称冲突，cluster\_name 都叫：rabbitmq-01，所以发送消息的时候会随机到  eu 和 us 集群

解决方法：修改 mq 集群名字，在控制台即可修改

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/1wvqrojZj1p8Oako/img/c27d4799-a0df-4fda-993f-dd22c3bf342f.png)

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/1wvqrojZj1p8Oako/img/fdcf69e8-29eb-4dd3-b5d3-c5a8ede6d1c7.png)

修改完毕后，测试一下 发消息，是否可以收到；不行的话，重新配置一下联邦重新测试一下；

### 二  删除老联邦交换机

修改完 eu 和 us 名字之后，会产生新的联邦队列；打开控制台页面，会发现老的队列消息还没清除掉，

要手动删除老队列和交换机，不然会一直有消息进入挤压消息；（zk-mq02 是老的名字，新的前面加了 eu 和 us）

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/1wvqrojZj1p8Oako/img/f054fb76-ebba-4671-8da6-ce81c4963630.png)

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/1wvqrojZj1p8Oako/img/82a6253d-8795-4f6c-aff0-0bb7375ab7cd.png)

过滤出来 zk-mq-02 的队列，点击进入，下滑手动删除，队列删除后交换机也会被删掉

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/1wvqrojZj1p8Oako/img/07d76156-4e3d-4a50-af52-9f8484f0e178.png)

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/1wvqrojZj1p8Oako/img/2be5a8c8-e198-4f98-a016-5b85e67f029e.png)

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/1wvqrojZj1p8Oako/img/36da0ee5-7cb0-42f8-8c4b-f4ed53ac8aaf.png)

队列全部删除后，老的交换机也会跟着删除