# pre环境监控系统搭建

本文档为 prometheus + grafana 监控平台部署文档，其中使用部署方式为 operator 方式部署

### Prometheus Operator 简介：

Prometheus Operator 是一个专为 Kubernetes 设计的 Operator，用于自动化 Prometheus 及相关组件（如 Alertmanager、ServiceMonitor 等）的部署和管理。它通过 Kubernetes 自定义资源定义（CRD）简化了 Prometheus 监控系统的配置和扩展，使得运维人员能够以 Kubernetes 原生的方式管理监控堆栈。

Prometheus Operator 的核心功能包括：

1.  **自动化部署**：通过 CRD 管理 Prometheus 和 Alertmanager 实例的生命周期。
    
2.  **动态配置**：基于 Kubernetes 标签自动发现监控目标，无需手动编写 Prometheus 配置文件。
    
3.  **高可用性**：支持 Prometheus 和 Alertmanager 的多副本部署，确保监控系统的高可用。
    
4.  **集成与扩展**：支持与 Grafana、PrometheusRule 等组件的无缝集成。
    

通过 Prometheus Operator，用户可以在 Kubernetes 集群中快速搭建一套完整的监控系统，同时享受 Kubernetes 的灵活性和可扩展性

**github 官网项目名称为**：kube-prometheus 

### 参考文献：

github官网：（[https://github.com/prometheus-operator/prometheus-operator/tree/main](https://github.com/prometheus-operator/prometheus-operator/tree/main)）

官方文档：（[https://prometheus-operator.dev/docs/getting-started/installation/#install-using-kube-prometheus](https://prometheus-operator.dev/docs/getting-started/installation/#install-using-kube-prometheus)）

### 部署prometheus-operator + grafana

#### 克隆 prometheus-operator 仓库

```c
git clone https://github.com/prometheus-operator/kube-prometheus.git
```

#### 安装 crd 资源

（所有配置文件都在 /kube-prometheus/manifests 文件夹）

```c
kubectl create -f manifests/setup
```

等待全部创建完成（返回为空即全部完成）

```c
until kubectl get servicemonitors --all-namespaces ; do date; sleep 1; echo ""; done
```

#### 分类目录

```c
cd /kube-prometheus/manifests
mkdir alertmanager
mv alertmanager* alertmanager

mkdir blackboxExporter
mv blackboxExporter* blackboxExporter
  
mkdir grafana
mv grafana* grafana


```

输出如下，分类后更整洁

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/r4mlQpxewLjdOxow/img/f90c3830-beaf-4ff8-a2ff-3a9d63b486e9.png)

#### 创建 crd 资源，安装 operator ， prometheus，grafana

```c
cd /kube-prometheus/manifests
kubectl apply -f .
kubectl apply -f grafana/
```

4.1 查看资源状态

```c
 kubectl get pod -n monitoring
NAME                                   READY   STATUS    RESTARTS   AGE
grafana-c8d4c5cb8-5n9rf                1/1     Running   0          48m
kube-state-metrics-7dcd87f75f-tlnn4    3/3     Running   0          3d3h
node-exporter-gjrh2                    2/2     Running   0          3d3h
node-exporter-k85ql                    2/2     Running   0          3d3h
node-exporter-zfrvr                    2/2     Running   0          3d3h
node-exporter-zrm4n                    2/2     Running   0          3d3h
prometheus-adapter-784f566c54-sjhv9    1/1     Running   0          3d3h
prometheus-adapter-784f566c54-zdt5t    1/1     Running   0          3d3h
prometheus-k8s-0                       2/2     Running   0          52m
prometheus-k8s-1                       2/2     Running   0          52m
prometheus-operator-744c7d6f4f-tlz28   2/2     Running   0          3d3h
```

现在已经安装完毕，但是想要访问需要创建 ingress 文件，或修改 svc 为 nodeport 暴露端口

### ingress 暴露服务

#### grafana 暴露服务

```c
cat grafana-ingress.yaml
  
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: grafana-ingress
  namespace: monitoring
spec:
  ingressClassName: nginx
  rules:
  - host: grafana.hkpre.yintaerp.com
    http:
      paths:
      - backend:
          service:
            name: grafana
            port:
              number: 3000
        path: /
        pathType: Prefix
```

#### prometheus 暴露服务

```c
cat prometheus-ingress.yaml
  
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: prometheus-k8s-ingress
  namespace: monitoring
spec:
  ingressClassName: nginx
  rules:
  - host: prometheus.hkpre.yintaerp.com
    http:
      paths:
      - backend:
          service:
            name: prometheus-k8s
            port:
              number: 9090
        path: /
        pathType: Prefix
```
```c
kubectl apply -f prometheus-ingress.yaml
kubectl apply -f grafana-ingress.yaml
```

查看创建的 ingress 

```c
kubectl get ingress -n monitoring 
NAME                     CLASS   HOSTS                           ADDRESS                                                                         PORTS   AGE
grafana-ingress          nginx   grafana.hkpre.yintaerp.com      k8s-ingressn-ingressn-099e95e6d9-8e50612eb9f23130.elb.ap-east-1.amazonaws.com   80      4d23h
prometheus-k8s-ingress   nginx   prometheus.hkpre.yintaerp.com   k8s-ingressn-ingressn-099e95e6d9-8e50612eb9f23130.elb.ap-east-1.amazonaws.com   80      4d23h
```

访问 grafana 域名  [grafana.hkpre.yintaerp.com](https://grafana.hkpre.yintaerp.com/)

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/r4mlQpxewLjdOxow/img/9bb1144d-7e2e-4c61-83fd-a66f0d07c86e.png)

访问 prometheus 域名  [prometheus.hkpre.yintaerp.com](https://prometheus.hkpre.yintaerp.com/)

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/r4mlQpxewLjdOxow/img/5432be4c-a9a6-401a-a256-c22dc07e28ad.png)

### 持久化存储

在 Prometheus Operator 的默认配置中，Prometheus 的存储使用的是 Kubernetes 的 `emptyDir` 类型存储。  `emptyDir` 是一种临时存储方式，它会将数据存储在 Pod 所在节点的文件系统中。当 Pod 被删除或重新调度到其他节点时，`emptyDir` 中的数据会被清空。这意味着 Prometheus 的监控数据在 Pod 重启或迁移时可能会丢失

所以我们要使用持久化存储，把目标文件挂载到外部服务，这里挂载到 aws 的 efs 文件系统

#### 创建 storageclass 

```c
cat prometheus-stroageclass.yaml 
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: prometheus-k8s-db
parameters:
  directoryPerms: "755"
  fileSystemId: fs-0edbb81afa0166302
  provisioningMode: efs-ap
provisioner: efs.csi.aws.com
reclaimPolicy: Delete
volumeBindingMode: Immediate
```

#### 创建 grafana pvc 文件

```c
cat grafana-pvc.yaml 
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: grafana-pvc
  namespace: monitoring
spec:
  accessModes:
  - ReadWriteOnce
  resources:
    requests:
      storage: 5Gi
  storageClassName: prometheus-k8s-db
```

#### grafana 定义持久化存储

注释掉原来的配置，原来为临时存储

```c
vim grafana/grafana-deployment.yaml 

      volumes:
      - name: grafana-storage
        persistentVolumeClaim:
          claimName: grafana-pvc
      #- emptyDir: {}
      #  name: grafana-storage
```

#### prometheus 持久化存储

自定义 prometheus-prometheus.yaml ，最下面新增配置

```c
# 新增配置文件
  additionalScrapeConfigs:
    name: additional-scrape-configs
    key: prometheus-additional.yaml

# 新增持久化存储,yaml 末尾添加
#加这个参数，表示prometheus数据保留的天数，默认会是1天
  retention: 7d
  storage:
    volumeClaimTemplate:
      spec:
        storageClassName: prometheus-k8s-db
        resources:
          requests:
            storage: 30Gi
```

更新配置，重启容器

```c
kubectl apply -f grafana/grafana-deployment.yaml 
kubectl apply -f prometheus-prometheus.yaml
```

查看 pvc 状态

bound 状态即为绑定成功

```c
kubectl get pvc -n monitoring 
NAME                                 STATUS   VOLUME                                     CAPACITY   ACCESS MODES   STORAGECLASS        VOLUMEATTRIBUTESCLASS   AGE
grafana-pvc                          Bound    pvc-97fda566-da8a-4777-a1c6-71761eda992b   5Gi        RWO            prometheus-k8s-db   <unset>                 45h
prometheus-k8s-db-prometheus-k8s-0   Bound    pvc-de25fad5-07e5-42c4-9e88-845402cc1cc1   30Gi       RWO            prometheus-k8s-db   <unset>                 45h
prometheus-k8s-db-prometheus-k8s-1   Bound    pvc-2ae0f3c8-6aca-4d87-a5ea-56bff5e22205   30Gi       RWO            prometheus-k8s-db   <unset>                 45h
```

### 添加自定义监控

operator 安装完毕后，会自动监控 k8s 集群各种指标，但是如果需要添加其他 node-exporter 监控项

需要创建自定义配置，具体操作如下，prometheus 使用 secrect 把配置文件挂载到容器内部，我们需要创建自定义 prometheus 配置文件，并挂载到容器内

#### 新增 secrects 配置文件

operator 安装，默认使用 secrcts 类型挂载配置文件到容器中

```c
cat prometheus-additional.yaml 
- job_name: node-exporter
  static_configs:
  - targets: ["172.40.40.35:9100"]
    labels:
      instance: 'hkpre-jenkins'
  - targets: ["172.40.42.108:9100"]
    labels:
      instance: 'hkpre-nginx01'
  - targets: ["172.40.43.50:9100"]
    labels:
      instance: 'hkpre-nginx02'
```

#### 创建secrects 脚本

```c
cat newcfg.sh 
kubectl create secret generic additional-scrape-configs --from-file=prometheus-additional.yaml --dry-run=client -o yaml > additional-scrape-configs.yaml
kubectl apply -f additional-scrape-configs.yaml -n monitoring
```

### 节点添加 exporter 监控

#### 安装docker && docker-compose

如果节点没有 docker / docker-compose 服务，参考下列安装：

```c
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

sudo apt-get update
sudo apt-get install docker-ce docker-ce-cli containerd.io docker-compose-plugin -y

sudo curl -SL https://github.com/docker/compose/releases/download/v2.6.0/docker-compose-linux-aarch64 -o /usr/local/bin/docker-compose && chmod +x /usr/local/bin/docker-compose
```

##### 节点添加 node-exporter 监控

编辑 docker-compose.yaml 文件

```c
mkdir node-exporter && cd  node-exporter 

  
cat <<EOF > docker-compose.yaml
---
version: '3.3'

services:
  node_exporter:
    image: quay.io/prometheus/node-exporter:latest
    container_name: node_exporter
    command:
      - '--path.rootfs=/host'
    network_mode: host
    pid: host
    restart: unless-stopped
    volumes:
      - '/:/host:ro,rslave'
EOF
```

启动容器

```c
docker-compose up -d
```

##### 编辑 prometheus 配置文件，添加

```c
cat prometheus-additional.yaml 
  
- job_name: node-exporter
  static_configs:
  - targets: ["172.40.40.35:9100"]
    labels:
      instance: 'hkpre-jenkins'
  - targets: ["172.40.42.108:9100"]
    labels:
      instance: 'hkpre-nginx01'
  - targets: ["172.40.43.50:9100"]
    labels:
      instance: 'hkpre-nginx02'
```

##### 创建secrects 脚本

```c
cat newcfg.sh 
kubectl create secret generic additional-scrape-configs --from-file=prometheus-additional.yaml --dry-run=client -o yaml > additional-scrape-configs.yaml
kubectl apply -f additional-scrape-configs.yaml -n monitoring
```

查看 prometheus 平台，是否正确收集到

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/r4mlQpxewLjdOxow/img/543b071b-96e9-4ecb-a146-2c62bf4e35ec.png)

#### 添加 rabbitmq exporter 监控

rabbitmq 开启 prometheus exporter 插件参考文档

[《exporter部署文档》](https://alidocs.dingtalk.com/api/doc/transit?dentryUuid=YMyQA2dXW797may7c2k9LqGOJzlwrZgb&queryString=utm_medium%3Ddingdoc_doc_plugin_card%26utm_source%3Ddingdoc_doc)

##### 编辑 prometheus 配置文件，添加

```c
cat prometheus-additional.yaml 

- job_name: pre-rabbitmq
  static_configs:
  - targets: ["172.40.175.63:15692"]
    labels:
      mqhostname: 'hkpre-mq'
      instance: '172.40.175.63'
  - targets: ["172.41.162.130:15692"]
    labels:
      mqhostname: 'eupre-mq'
      instance: '172.41.162.130'
  - targets: ["172.42.134.36:15692"]
    labels:
      mqhostname: 'uspre-mq'
      instance: '172.42.134.36'
```

##### 创建secrects 脚本

```c
cat newcfg.sh 
kubectl create secret generic additional-scrape-configs --from-file=prometheus-additional.yaml --dry-run=client -o yaml > additional-scrape-configs.yaml
kubectl apply -f additional-scrape-configs.yaml -n monitoring
```

执行脚本

```c
cd /root/kube-prometheus/yaml
  
root@ip-172-40-40-35:~/kube-prometheus/yaml# ls
additional-scrape-configs.yaml  grafana-pvc.yaml  newcfg.sh  prometheus-additional.yaml  prometheus-stroageclass.yaml
root@ip-172-40-40-35:~/kube-prometheus/yaml# ./newcfg.sh 
secret/additional-scrape-configs configured
```

查看 prometheus target ，是否已经拿到数据

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/r4mlQpxewLjdOxow/img/e914da33-6df7-4cc2-afe3-84bb90f07118.png)

#### 添加 zookeeper exporter 监控

部署 zk-exporter 文档参考

[《exporter部署文档》](https://alidocs.dingtalk.com/api/doc/transit?dentryUuid=YMyQA2dXW797may7c2k9LqGOJzlwrZgb&queryString=utm_medium%3Ddingdoc_doc_plugin_card%26utm_source%3Ddingdoc_doc)

##### 编辑 prometheus 配置文件，添加

```c
cat prometheus-additional.yaml 

- job_name: pre-rabbitmq
  static_configs:
  - targets: ["172.40.175.63:15692"]
    labels:
      mqhostname: 'hkpre-mq'
      instance: '172.40.175.63'
  - targets: ["172.41.162.130:15692"]
    labels:
      mqhostname: 'eupre-mq'
      instance: '172.41.162.130'
  - targets: ["172.42.134.36:15692"]
    labels:
      mqhostname: 'uspre-mq'
      instance: '172.42.134.36'
```

##### 创建secrects 脚本

```c
cat newcfg.sh 
kubectl create secret generic additional-scrape-configs --from-file=prometheus-additional.yaml --dry-run=client -o yaml > additional-scrape-configs.yaml
kubectl apply -f additional-scrape-configs.yaml -n monitoring
```

执行脚本

```c
cd /root/kube-prometheus/yaml
  
root@ip-172-40-40-35:~/kube-prometheus/yaml# ls
additional-scrape-configs.yaml  grafana-pvc.yaml  newcfg.sh  prometheus-additional.yaml  prometheus-stroageclass.yaml
root@ip-172-40-40-35:~/kube-prometheus/yaml# ./newcfg.sh 
secret/additional-scrape-configs configured
```

### grafana 模板

这里分享一些好用的模板，打开网站，复制模板号，导入grafana  dashboard 即可

1.  k8s 集群模板文件
    

```c
https://grafana.com/grafana/dashboards/13105-k8s-dashboard-cn-20240513-starsl-cn/
```

2.  node-exporter 好用模板，导入文件
    

[请至钉钉文档查看附件《Node Exporter Dashboard(Linux宿主机精简版)-1740999352578.json》](https://alidocs.dingtalk.com/i/nodes/G1DKw2zgV2R7pYZ7s1QbgvDwVB5r9YAn?corpId=ding70528ab867da334c35c2f4657eb6378f&doc_type=wiki_doc&iframeQuery=anchorId%3DX02m7vht606xu4o7yn28eo&rnd=0.12457442060709756&sideCollapsed=true&utm_scene=team_space)

3.  rabbitmq-exporter 模板
    

```c
https://grafana.com/grafana/dashboards/10991-rabbitmq-overview/
```