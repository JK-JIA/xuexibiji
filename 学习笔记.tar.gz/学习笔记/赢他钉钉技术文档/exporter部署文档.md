# exporter部署文档

本文档旨在指导用户如何部署和配置 Prometheus Exporter，以便将各种服务和应用的指标数据暴露给 Prometheus 服务器进行监控。Exporter 是 Prometheus 生态系统中的一个关键组件，它负责从目标系统收集指标数据，并以 Prometheus 支持的格式提供这些数据。通过部署 Exporter，用户可以实现对各种服务（如 Node、MySQL、RabbitMQ、Zookeeper 等）的监控。

### 节点添加 exporter 监控

#### 安装docker && docker-compose

如果节点没有 docker / docker-compose 服务，参考下列安装：

```c
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

sudo apt-get update
sudo apt-get install docker-ce docker-ce-cli containerd.io docker-compose-plugin -y

sudo curl -SL https://github.com/docker/compose/releases/download/v2.6.0/docker-compose-linux-aarch64 -o /usr/local/bin/docker-compose && chmod +x /usr/local/bin/docker-compose
```

#### 节点添加 node-exporter 监控

编辑 docker-compose.yaml 文件

```c
mkdir node-exporter && cd  node-exporter 

  
cat <<EOF > docker-compose.yaml
---
version: '3.3'

services:
  node_exporter:
    image: quay.io/prometheus/node-exporter:latest
    container_name: node_exporter
    command:
      - '--path.rootfs=/host'
    network_mode: host
    pid: host
    restart: unless-stopped
    volumes:
      - '/:/host:ro,rslave'
EOF
```

启动容器

```c
docker-compose up -d
```

### 添加 zookeeper exporter 监控

编辑 docker-compose.yaml 文件

hosts ip 填写 mq 集群三个节点的地址

```c
cat docker-compose.yaml 
  
version: '3'
services:
  zk-exporter:
    container_name: zk-exporter
    image:  ubuntu:22.04
    restart: always  
    volumes:
    - ./zookeeper-exporter:/bin/zookeeper-exporter
    ports:
    - 9117:9141
        # multitarget
    entrypoint:
    - /bin/zookeeper-exporter
    command: --zk-hosts="172.33.165.34:2181,172.33.170.64:2181,172.33.160.20:2181" --timeout=5
```

同级目录下载 zookeeper-exporter 文件

```c
ls zk-exporter/
docker-compose.yaml  zookeeper-exporter
```

[请至钉钉文档查看附件《zookeeper-exporter》](https://alidocs.dingtalk.com/i/nodes/YMyQA2dXW797may7c2k9LqGOJzlwrZgb?corpId=ding70528ab867da334c35c2f4657eb6378f&doc_type=wiki_doc&iframeQuery=anchorId%3DX02m7viebt8hgkebl8vh4d&rnd=0.12452253625237719&sideCollapsed=true&utm_scene=team_space)

### 添加 Rabbitmq exporter 监控

rabbitmq 支持 prometheus 插件，直接开启插件即可使用

启用插件后，RabbitMQ 会在默认的 15692 端口上暴露 Prometheus 格式的指标

1.  手动命令开启插件
    

```c
rabbitmq-plugins enable rabbitmq_prometheus
```

2.  写入插件配置文件中，启动自动加载
    

```c
cat rabbitmq/enabled_plugins 
[rabbitmq_delayed_message_exchange,rabbitmq_federation,rabbitmq_federation_management,rabbitmq_management,rabbitmq_prometheus].
```

部署mq参考一下 docker-compose 文件

[《zookeeper-rabbitmq搭建》](https://alidocs.dingtalk.com/api/doc/transit?dentryUuid=YQBnd5ExVEwPoXkPiyOrMKxZ8yeZqMmz&queryString=utm_medium%3Ddingdoc_doc_plugin_card%26utm_source%3Ddingdoc_doc)

访问 15692 端口，查看指标

```c
curl -s 172.40.175.63:15692/metrics | head -n 3
# TYPE erlang_mnesia_held_locks gauge
# HELP erlang_mnesia_held_locks Number of held locks.
erlang_mnesia_held_locks 0
```

全部 exporter 文件集合

[请至钉钉文档查看附件《exporters.tar.gz》](https://alidocs.dingtalk.com/i/nodes/YMyQA2dXW797may7c2k9LqGOJzlwrZgb?corpId=ding70528ab867da334c35c2f4657eb6378f&doc_type=wiki_doc&iframeQuery=anchorId%3DX02m7viqb2r2dah2mfcxll&rnd=0.12452253625237719&sideCollapsed=true&utm_scene=team_space)