# RDS 慢SQL查询手册

## 简介

随着业务的快速发展，数据库数据量不断攀升，慢SQL问题也日益凸显，严重影响系统性能和用户体验。为协助开发人员高效定位和优化慢SQL，本手册记录了如何将RDS数据库中的慢SQL保存至指定存储， 并介绍了开发人员如何查询和使用这些保存的慢SQL记录。通过标准化的操作流程，助力开发团队快速发现问题、优化性能，保障系统的稳定运行。

方案一

优势：可视化，易操作

缺点：记录所有sql 操作，不单单是 慢 sql 

调整数据监控保存sql文本字节的大小

aws  RDS 数据库，默认提供了 **Performance Insights** 监控工具，用于收集和存储关于数据库性能的各种信息。它通过一系列的表和视图提供以下功能：

1.  **监控 SQL 语句的执行情况**：包括执行时间、锁等待时间、资源消耗等。
    
2.  **监控数据库内部的线程、事件、锁等信息**：帮助分析性能瓶颈。
    
3.  **提供详细的性能数据**：用于优化数据库性能和排查问题。
    

视图如下：

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMJry0PDq3p8/img/892b8cae-abc9-44fc-82a8-98c699cebcb8.png)

也可以查询慢sql 语句，但是有一个问题是，默认限制了只能保存 4096 字节的语句，超出的会被截断

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMJry0PDq3p8/img/5811f10c-5061-4711-95b6-0545aeca4339.png)

解决方法：

参数 `performance_schema` 是 MySQL 提供的一个用于监控数据库性能的工具。它并不是专门用来存储慢 SQL 语句的，而是用于存储和监控数据库运行时的各种性能数据，包括但不限于 SQL 语句的执行情况。

修改 `performance_schema` 参数为 8 字节：8192

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMJry0PDq3p8/img/1797b96f-fc64-4b88-b60c-76b3a62afe7e.png)

方案二

解决方案：把慢sql 文件输出方式改为，输出到 table ，开启mysql 自带的 慢sql 语句保存机制，设置参数 log\_output='TABLE' ；可以定义时间，超出多久为慢sql，并记录到 table 表里

优势：存储完整，可以sql 语句查询

缺点：占用数据库性能 

一、RDS 数据库参数组

参数含义：

参考文献：（[https://dev.mysql.com/doc/refman/8.0/en/log-destinations.html](https://dev.mysql.com/doc/refman/8.0/en/log-destinations.html)）

（[https://docs.aws.amazon.com/zh\_cn/AmazonRDS/latest/AuroraUserGuide/AuroraMySQL.Reference.ParameterGroups.html](https://docs.aws.amazon.com/zh_cn/AmazonRDS/latest/AuroraUserGuide/AuroraMySQL.Reference.ParameterGroups.html)）

```c
1 slow_query_log： //设置为1以启用慢查询日志，默认值为0
2 slow_query_log_file: //
/*
log_output='FILE'	     # 表示将日志存入文件slow.log，默认值是'FILE'　
log_output='TABLE'	     # 表示将日志存入数据库,会写入mysql.slow_log表
log_output='FILE,TABLE'  # 表示既写文件slow.log，又写mysql.slow_log表
log_output='NONE'	     # 表示禁用日志
*/
3 slow_query_log_file // 设置保存的日志文件名、path 路径，默认名称为 host_name-slow.log，除非给出绝对路径名来指定其他目录，否则服务器将在数据目录中创建该文件。
4 long_query_time：//定义查询执行时间的阈值，超过此时间的查询会被记录到慢查询日志，最小值和默认值 long_query_time分别为 0 和 10。该值可以指定为微秒的精度。
```

查询慢 SQL 配置

```sql
SHOW VARIABLES LIKE 'slow_query_log';          -- 是否启用慢查询日志（ON/OFF）
SHOW VARIABLES LIKE 'log_output';             -- 日志输出方式（FILE/TABLE）
SHOW VARIABLES LIKE 'long_query_time';        -- 慢查询阈值（单位：秒）
SHOW VARIABLES LIKE 'log_queries_not_using_indexes';  -- 是否记录未使用索引的查询（ON/OFF）
SHOW VARIABLES LIKE 'log_slow_admin_statements';      -- 是否记录管理语句（如 OPTIMIZE TABLE）
SHOW VARIABLES LIKE 'min_examined_row_limit';         -- 查询检查的最小行数阈值
SHOW VARIABLES LIKE 'slow_query_log_file';    -- 慢查询日志文件路径（如果 log_output=FILE）

SHOW CREATE TABLE mysql.slow_log;    --查询存储日志表的表结构

```

**默认参数** log\_output='FILE' ，表中是没有数据的；

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMJry0PDq3p8/img/8ed1807e-88a0-4223-8785-c8505b03ca4e.png)

在 RDS 数据库，参数组中修改参数

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMJry0PDq3p8/img/65ced2ab-6314-40da-8480-1d5623d587e2.png)

数据库操作

查询日志存储表

```sql
--Blog 格式存储，需要转成文本格式
SELECT * FROM mysql.slow_log;

```
```sql
--输出为文本格式
SELECT 
    start_time,
    user_host,
    query_time,
    lock_time,
    rows_sent,
    rows_examined,
    db,
    CAST(sql_text AS CHAR) AS sql_text
FROM 
    mysql.slow_log;
```

方案三

aws 的 RDS 数据库默认支持 cloudwatch 收集日志，只需要开启参数即可

优势：简单方便，托管，免费

缺点：太长的sql 记录不全（99%够用），默认免费只保留7天，升级需付费

开启 RDS 慢 sql 日志：

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMJry0PDq3p8/img/c7d9b2b0-c1b9-4952-a268-770f1668f2a9.png)

查看日志：

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMJry0PDq3p8/img/fda179a1-67b8-41a6-98cf-a9957279d812.png)

支持下载为 csv 文件：

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMJry0PDq3p8/img/4c44dab1-03c6-412d-a614-a9eae6cbad96.png)