# 手动更新o2oa-server服务镜像

历史遗留原因，o2oa-server 服务没有使用 jenkins 发版；所以每次更新需要手动改配置，再重新打镜像

不巧的是，dockerfile 文件也不知道在哪里 [跪了]，只能手动基于目前的镜像进行配置更新；

1 拉取 o2oa 当前镜像（需要先登录 4064 aws账户 ecr 仓库）

密码只有运维管理员有

```sql
aws configure set aws_access_key_id AKIAV5ISR6EZ2OK*****  
aws configure set aws_secret_access_key wHmhW51rXX1zBGHa**************
aws configure set default.region ap-east-1
aws ecr get-login-password --region ap-east-1 | docker login --username AWS --password-stdin 406450204979.dkr.ecr.ap-east-1.amazonaws.com
```

拉取镜像

```shell
docker pull 406450204979.dkr.ecr.ap-east-1.amazonaws.com/ops-o2oa-server:9.0.63
```

2 进入镜像

```shell
docker run -it --rm 406450204979.dkr.ecr.ap-east-1.amazonaws.com/ops-o2oa-server:9.0.63
```

3 修改配置，配置文件都在 /home/appuser/config 下面，其他配置联系相关开发（目前是@曾雪峰）

```shell
cd /home/appuser/config

vim  /home/appuser/config/externalDataSources.json


[
        {
                "url": "jdbc:mysql://pre-hk-bms.pre-hk-dns:5036/o2oa?allowMultiQueries=true&rewriteBatchedStatements=true&useAffectedRows=true&continueBatchOnError=false&serverTimezone=Asia/Shanghai&useUnicode=true&characterEncoding=UTF-8",
                "username": "o2oa",
                "password": "Ew@RWpwQh123",
                "includes": [],
                "excludes": [],
                "enable": true,
                "maxTotal": 100,
                "maxIdle": 10
        }
]
```

4 保存运行中的镜像（生产环境镜像标签为6.0开头，pre环境为 9.0开头）

```shell
docker commit df1441b03adc 406450204979.dkr.ecr.ap-east-1.amazonaws.com/ops-o2oa-server:9.0.64
```

5 上传镜像（上传过后，k8s集群的flux 组件检测到新镜像，会自动更新版本）

```shell
docker push  406450204979.dkr.ecr.ap-east-1.amazonaws.com/ops-o2oa-server:9.0.64
```