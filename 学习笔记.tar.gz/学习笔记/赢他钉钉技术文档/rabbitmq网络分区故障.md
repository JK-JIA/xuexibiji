# rabbitmq网络分区故障

### 1.临时处理恢复方式：

美国

Network Partitions

Node rabbit@zk-mq-03 cannot communicate with rabbit@zk-mq-01, rabbit@zk-mq-02

欧洲

Network Partitions

Node rabbit@zk-mq-01 cannot communicate with rabbit@zk-mq-02

Node rabbit@zk-mq-03 cannot communicate with rabbit@zk-mq-02

进入集群的一个rabbitmq容器内， 执行 rabbitmqctl cluster\_status 查看Network Partitions ，发现如果连不上某个节点，进入节点进行重启rabbitmq。

### 2.配置相关参数防止分区故障

配置 ticktime 参数

1 查看当前配置 （默认60）

```c
# 查看当前 ticktime
rabbitmqctl eval 'net_kernel:get_net_ticktime().'
60
```

配置为 120，在 /etc/rabbitmq/advanced.config  文件添加配置，挂载到容器

```c
cat rabbitmq/advanced.config 
  
[
  {kernel, [{net_ticktime, 120}]}
].
```

docker-compose 文件：

```c
 cat docker-compose.yaml 
version: '3'
services:
  rabbitmq:
    container_name: rabbitmq-hk-uat
    restart: always  
    hostname: hkpre-zk-mq-01
    build:
      context: .
      dockerfile: Dockerfile
    command: ["sh", "-c", "rabbitmq-server --detached & sleep 10 && rabbitmqctl trace_on && tail -f /dev/null"]
    ports:
      - 5672:5672
      - 4369:4369
      - 15672:15672
      - 25672:25672
      - 15692:15692
    #entrypoint:
    #- rabbitmq-server
    #- --detached
    volumes:
      - /etc/hosts:/etc/hosts
      - /etc/localtime:/etc/localtime
      - /etc/timezone:/etc/timezone
     #- ./enabled_plugins:/etc/rabbitmq/enabled_plugins
      - ./rabbitmq:/etc/rabbitmq
      - ./data:/var/lib/rabbitmq/
      - ./log:/var/log/rabbitmq/
    healthcheck:
      test: ["CMD", "rabbitmq-diagnostics", "ping"]
      interval: 1m30s
      timeout: 10s
      retries: 3
```

2 配置 cluster\_partition\_handling 参数

默认是 ignore

```c
 docker exec -it 5c24be312a2a  rabbitmqctl environment | grep cluster_partition_handling
      {cluster_partition_handling,ignore},
```

在 rabbitmq.conf 文件新增配置

```c
 cat rabbitmq/rabbitmq.conf 
loopback_users.guest = false
listeners.tcp.default = 5672
management.tcp.port = 15672
management_agent.disable_metrics_collector = false
cluster_partition_handling = pause_minority
```

3 重启容器生效

```c
docker-compose down
docker-compose up -d
```

4 查看是否生效

```c
docker exec -it 17aae2dbff1d rabbitmqctl eval 'net_kernel:get_net_ticktime().'
120

docker exec -it 17aae2dbff1d  rabbitmqctl environment | grep cluster_partition_handling
      {cluster_partition_handling,pause_minority},
```