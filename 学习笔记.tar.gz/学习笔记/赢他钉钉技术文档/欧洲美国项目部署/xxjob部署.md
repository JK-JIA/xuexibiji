# xxjob部署

xxl-job-admin 数据存储不在本地，需要存储在数据库中

在数据库中创建库和用户xxl_job_eu 用户并授权拥有 xxl_job_eu库的权限

```plaintext
create database eu_xxljob default character set utf8mb4;
create user eu_xxljob@'%' identified WITH mysql_native_password BY "ETZFOIZ6Z0Yy";
grant all privileges on eu_xxljob.* to eu_xxljob@'%';
```

官网提供了数据库初始化文件（https://github.com/xuxueli/xxl-job/releases/tag/v2.2.0）

下载需要的版本并解压

```plaintext
wget https://github.com/xuxueli/xxl-job/archive/refs/tags/v2.2.0.tar.gz
tar xf v2.2.0.tar.gz

ls xxl-job-2.2.0/doc/db/
tables_xxl_job.sql
```

数据库导入初始化文件

这里展示一下我下在的 tables_xxl_job.sql 文件，修改了库名 xxl_job_eu

```plaintext
#
# XXL-JOB v2.2.0
# Copyright (c) 2015-present, xuxueli.

CREATE database if NOT EXISTS `eu_xxljob` default character set utf8mb4 collate utf8mb4_unicode_ci;
use `eu_xxljob`;

SET NAMES utf8mb4;

CREATE TABLE `xxl_job_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_group` int(11) NOT NULL COMMENT '执行器主键ID',
  `job_cron` varchar(128) NOT NULL COMMENT '任务执行CRON',
  `job_desc` varchar(255) NOT NULL,
  `add_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `author` varchar(64) DEFAULT NULL COMMENT '作者',
  `alarm_email` varchar(255) DEFAULT NULL COMMENT '报警邮件',
  `executor_route_strategy` varchar(50) DEFAULT NULL COMMENT '执行器路由策略',
  `executor_handler` varchar(255) DEFAULT NULL COMMENT '执行器任务handler',
  `executor_param` varchar(512) DEFAULT NULL COMMENT '执行器任务参数',
  `executor_block_strategy` varchar(50) DEFAULT NULL COMMENT '阻塞处理策略',
  `executor_timeout` int(11) NOT NULL DEFAULT '0' COMMENT '任务执行超时时间，单位秒',
  `executor_fail_retry_count` int(11) NOT NULL DEFAULT '0' COMMENT '失败重试次数',
  `glue_type` varchar(50) NOT NULL COMMENT 'GLUE类型',
  `glue_source` mediumtext COMMENT 'GLUE源代码',
  `glue_remark` varchar(128) DEFAULT NULL COMMENT 'GLUE备注',
  `glue_updatetime` datetime DEFAULT NULL COMMENT 'GLUE更新时间',
  `child_jobid` varchar(255) DEFAULT NULL COMMENT '子任务ID，多个逗号分隔',
  `trigger_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '调度状态：0-停止，1-运行',
  `trigger_last_time` bigint(13) NOT NULL DEFAULT '0' COMMENT '上次调度时间',
  `trigger_next_time` bigint(13) NOT NULL DEFAULT '0' COMMENT '下次调度时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `xxl_job_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `job_group` int(11) NOT NULL COMMENT '执行器主键ID',
  `job_id` int(11) NOT NULL COMMENT '任务，主键ID',
  `executor_address` varchar(255) DEFAULT NULL COMMENT '执行器地址，本次执行的地址',
  `executor_handler` varchar(255) DEFAULT NULL COMMENT '执行器任务handler',
  `executor_param` varchar(512) DEFAULT NULL COMMENT '执行器任务参数',
  `executor_sharding_param` varchar(20) DEFAULT NULL COMMENT '执行器任务分片参数，格式如 1/2',
  `executor_fail_retry_count` int(11) NOT NULL DEFAULT '0' COMMENT '失败重试次数',
  `trigger_time` datetime DEFAULT NULL COMMENT '调度-时间',
  `trigger_code` int(11) NOT NULL COMMENT '调度-结果',
  `trigger_msg` text COMMENT '调度-日志',
  `handle_time` datetime DEFAULT NULL COMMENT '执行-时间',
  `handle_code` int(11) NOT NULL COMMENT '执行-状态',
  `handle_msg` text COMMENT '执行-日志',
  `alarm_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '告警状态：0-默认、1-无需告警、2-告警成功、3-告警失败',
  PRIMARY KEY (`id`),
  KEY `I_trigger_time` (`trigger_time`),
  KEY `I_handle_code` (`handle_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `xxl_job_log_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trigger_day` datetime DEFAULT NULL COMMENT '调度-时间',
  `running_count` int(11) NOT NULL DEFAULT '0' COMMENT '运行中-日志数量',
  `suc_count` int(11) NOT NULL DEFAULT '0' COMMENT '执行成功-日志数量',
  `fail_count` int(11) NOT NULL DEFAULT '0' COMMENT '执行失败-日志数量',
  PRIMARY KEY (`id`),
  UNIQUE KEY `i_trigger_day` (`trigger_day`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `xxl_job_logglue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL COMMENT '任务，主键ID',
  `glue_type` varchar(50) DEFAULT NULL COMMENT 'GLUE类型',
  `glue_source` mediumtext COMMENT 'GLUE源代码',
  `glue_remark` varchar(128) NOT NULL COMMENT 'GLUE备注',
  `add_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `xxl_job_registry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `registry_group` varchar(50) NOT NULL,
  `registry_key` varchar(255) NOT NULL,
  `registry_value` varchar(255) NOT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `i_g_k_v` (`registry_group`,`registry_key`,`registry_value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `xxl_job_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_name` varchar(64) NOT NULL COMMENT '执行器AppName',
  `title` varchar(12) NOT NULL COMMENT '执行器名称',
  `address_type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '执行器地址类型：0=自动注册、1=手动录入',
  `address_list` varchar(512) DEFAULT NULL COMMENT '执行器地址列表，多地址逗号分隔',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `xxl_job_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL COMMENT '账号',
  `password` varchar(50) NOT NULL COMMENT '密码',
  `role` tinyint(4) NOT NULL COMMENT '角色：0-普通用户、1-管理员',
  `permission` varchar(255) DEFAULT NULL COMMENT '权限：执行器ID列表，多个逗号分割',
  PRIMARY KEY (`id`),
  UNIQUE KEY `i_username` (`username`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `xxl_job_lock` (
  `lock_name` varchar(50) NOT NULL COMMENT '锁名称',
  PRIMARY KEY (`lock_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO `xxl_job_group`(`id`, `app_name`, `title`, `address_type`, `address_list`) VALUES (1, 'xxl-job-executor-sample', '示例执行器', 0, NULL);
INSERT INTO `xxl_job_info`(`id`, `job_group`, `job_cron`, `job_desc`, `add_time`, `update_time`, `author`, `alarm_email`, `executor_route_strategy`, `executor_handler`, `executor_param`, `executor_block_strategy`, `executor_timeout`, `executor_fail_retry_count`, `glue_type`, `glue_source`, `glue_remark`, `glue_updatetime`, `child_jobid`) VALUES (1, 1, '0 0 0 * * ? *', '测试任务1', '2018-11-03 22:21:31', '2018-11-03 22:21:31', 'XXL', '', 'FIRST', 'demoJobHandler', '', 'SERIAL_EXECUTION', 0, 0, 'BEAN', '', 'GLUE代码初始化', '2018-11-03 22:21:31', '');
INSERT INTO `xxl_job_user`(`id`, `username`, `password`, `role`, `permission`) VALUES (1, 'admin', 'e10adc3949ba59abbe56e057f20f883e', 1, NULL);
INSERT INTO `xxl_job_lock` ( `lock_name`) VALUES ( 'schedule_lock');

commit;
```

测试集群数据库docker部署在 192.168.3.204 机器上

source  /path 路径

```plaintext
mysql -h 127.0.0.1 -P3306 -uroot -pein4efoh7IthuoT7ie

mysql> CREATE USER 'eu_xxl_job'@'%' IDENTIFIED BY 'AeJ9ahshodo';
mysql> GRANT ALL PRIVILEGES ON eu_xxl_job.* TO 'eu_xxl_job'@'%';
mysql> FLUSH PRIVILEGES;
mysql> source /opt/xxl-job-2.2.0/doc/db/tables_xxl_job.sql;
```

编写yaml 文件 xxl-job-admin2.yaml

这里为了方便测试，开启了nodeport  30088 (测试集群部署)

```plaintext
apiVersion: apps/v1
kind: Deployment
metadata:
  labels:
    app: xxl-job-admin2
    app.kubernetes.io/managed-by: Helm
    version: v1
  name: xxl-job-admin2
  namespace: us
spec:
  replicas: 1
  revisionHistoryLimit: 2
  selector:
    matchLabels:
      app: xxl-job-admin2
      version: v1
  strategy:
    rollingUpdate:
      maxSurge: 25%
      maxUnavailable: 25%
    type: RollingUpdate
  template:
    metadata:
      labels:
        app: xxl-job-admin2
        version: v1
    spec:
      containers:
      - command:
        - java
        - -jar
        - app.jar
        env:
        - name: aliyun_logs_xxl-job-admin2-stdout
          value: stdout
        - name: ZOO_4LW_COMMANDS_WHITELIST
          value: a
        image: xuxueli/xxl-job-admin:2.2.0
        imagePullPolicy: IfNotPresent
        name: xxl-job-admin2
        ports:
        - containerPort: 8080
          name: api
          protocol: TCP
        resources:
          limits:
            cpu: "2"
            memory: 8Gi
          requests:
            cpu: 10m
            memory: 20Mi
        terminationMessagePath: /dev/termination-log
        terminationMessagePolicy: File
        volumeMounts:
        - mountPath: /application.properties
          name: config
          subPath: application.properties
      dnsPolicy: ClusterFirst
      imagePullSecrets:
      - name: ytdocker
      restartPolicy: Always
      schedulerName: default-scheduler
      securityContext: {}
      terminationGracePeriodSeconds: 5
      volumes:
      - configMap:
          defaultMode: 420
          name: xxl-job-admin2-configmap
        name: config

---



apiVersion: v1
kind: Service
metadata:
  labels:
    app: xxl-job-admin2
    app.kubernetes.io/managed-by: Helm
  name: xxl-job-admin2
  namespace: us
spec:
  internalTrafficPolicy: Cluster
  ipFamilies:
  - IPv4
  ipFamilyPolicy: SingleStack
  ports:
  - name: tcp
    nodePort: 31427
    port: 8080
    protocol: TCP
    targetPort: 8080
    nodePort: 30088
  selector:
    app: xxl-job-admin2
  type: NodePort

---

apiVersion: v1
data:
  application.properties: |
    ### web
    server.port=8080
    server.servlet.context-path=/xxl-job-admin

    ### actuator
    management.server.servlet.context-path=/actuator
    management.health.mail.enabled=false

    ### resources
    spring.mvc.servlet.load-on-startup=0
    spring.mvc.static-path-pattern=/static/**
    spring.resources.static-locations=classpath:/static/

    ### freemarker
    spring.freemarker.templateLoaderPath=classpath:/templates/
    spring.freemarker.suffix=.ftl
    spring.freemarker.charset=UTF-8
    spring.freemarker.request-context-attribute=request
    spring.freemarker.settings.number_format=0.##########

    ### mybatis
    mybatis.mapper-locations=classpath:/mybatis-mapper/*Mapper.xml
    #mybatis.type-aliases-package=com.xxl.job.admin.core.model

    ### xxl-job, datasource
    #spring.datasource.url=jdbc:mysql://mysql.uat.yintaerp.com:3306/xxl_job2?useUnicode=true&characterEncoding=UTF-8&autoReconnect=true&serverTimezone=Asia/Shanghai
    #spring.datasource.username=xxl_job2
    #spring.datasource.password=aeXohgh7ph
    #spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
    spring.datasource.url=jdbc:mysql://mysql.sit.yintaerp.com:3306/xxl_job_test?useUnicode=true&characterEncoding=UTF-8&autoReconnect=true&serverTimezone=Asia/Shanghai
    spring.datasource.username=xxl_job_test
    spring.datasource.password=AeJ9ahshodo
    spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

    ### datasource-pool
    spring.datasource.type=com.zaxxer.hikari.HikariDataSource
    spring.datasource.hikari.minimum-idle=10
    spring.datasource.hikari.maximum-pool-size=30
    spring.datasource.hikari.auto-commit=true
    spring.datasource.hikari.idle-timeout=30000
    spring.datasource.hikari.pool-name=HikariCP
    spring.datasource.hikari.max-lifetime=900000
    spring.datasource.hikari.connection-timeout=10000
    spring.datasource.hikari.connection-test-query=SELECT 1
    spring.datasource.hikari.validation-timeout=1000

    ### xxl-job, email
    spring.mail.host=smtp.qq.com
    spring.mail.port=25
    spring.mail.username=xxx@qq.com
    spring.mail.from=xxx@qq.com
    spring.mail.password=xxx
    spring.mail.properties.mail.smtp.auth=true
    spring.mail.properties.mail.smtp.starttls.enable=true
    spring.mail.properties.mail.smtp.starttls.required=true
    spring.mail.properties.mail.smtp.socketFactory.class=javax.net.ssl.SSLSocketFactory

    ### xxl-job, access token
    xxl.job.accessToken=

    ### xxl-job, i18n (default is zh_CN, and you can choose "zh_CN", "zh_TC" and "en")
    xxl.job.i18n=zh_CN

    ## xxl-job, triggerpool max size
    xxl.job.triggerpool.fast.max=200
    xxl.job.triggerpool.slow.max=100

    ### xxl-job, log retention days
    xxl.job.logretentiondays=30
kind: ConfigMap
metadata:
  labels:
    app.kubernetes.io/managed-by: Helm
  name: xxl-job-admin2-configmap
  namespace: us
```

（生产集群部署文件）

```plaintext
apiVersion: apps/v1
kind: Deployment
metadata:
  annotations:
    deployment.kubernetes.io/revision: "10"
    fluxcd.io/automated: "false"
  creationTimestamp: "2022-04-24T08:47:49Z"
  generation: 20
  labels:
    app: xxl-job-admin
    version: v1
  name: xxl-job-admin
  namespace: erp-prod
  resourceVersion: "889315063"
  uid: 2ae0b938-bbce-4ebc-983e-36908337d945
spec:
  progressDeadlineSeconds: 600
  replicas: 1
  revisionHistoryLimit: 2
  selector:
    matchLabels:
      app: xxl-job-admin
      version: v1
  strategy:
    rollingUpdate:
      maxSurge: 25%
      maxUnavailable: 25%
    type: RollingUpdate
  template:
    metadata:
      annotations:
        kubectl.kubernetes.io/restartedAt: "2023-07-16T19:40:11+08:00"
      creationTimestamp: null
      labels:
        app: xxl-job-admin
        version: v1
    spec:
      containers:
      - command:
        - java
        - -Dfile.encoding=UTF-8
        - -Dserver.port=8080
        - -javaagent:./agent/skywalking-agent.jar
        - -Dskywalking.agent.namespace=erp-prod
        - -Dskywalking.agent.service_name=erp-prod-xxl-job-admin
        - -Dskywalking.collector.backend_service=apm.sit.yintaerp.com:11800
        - -jar
        - app.jar
        env:
        - name: aliyun_logs_xxl-job-admin-stdout
          value: stdout
        - name: ZOO_4LW_COMMANDS_WHITELIST
          value: '*'
        image: dockerhub-prod.yintaerp.com/xxl-job-admin:2.2.0
        imagePullPolicy: IfNotPresent
        livenessProbe:
          failureThreshold: 3
          httpGet:
            path: xxl-job-admin/actuator/health
            port: api
            scheme: HTTP
          initialDelaySeconds: 20
          periodSeconds: 10
          successThreshold: 1
          timeoutSeconds: 8
        name: xxl-job-admin
        ports:
        - containerPort: 8080
          name: api
          protocol: TCP
        readinessProbe:
          failureThreshold: 3
          httpGet:
            path: xxl-job-admin/actuator/health
            port: api
            scheme: HTTP
          initialDelaySeconds: 20
          periodSeconds: 10
          successThreshold: 1
          timeoutSeconds: 8
        resources:
          limits:
            cpu: "8"
            memory: 16Gi
          requests:
            cpu: 10m
            memory: 20Mi
        startupProbe:
          failureThreshold: 30
          httpGet:
            path: xxl-job-admin/actuator/health
            port: api
            scheme: HTTP
          periodSeconds: 10
          successThreshold: 1
          timeoutSeconds: 5
        terminationMessagePath: /dev/termination-log
        terminationMessagePolicy: File
        volumeMounts:
        - mountPath: /home/appuser/application.properties
          name: config
          subPath: application.properties
      dnsPolicy: ClusterFirst
      imagePullSecrets:
      - name: ytdocker
      restartPolicy: Always
      schedulerName: default-scheduler
      securityContext: {}
      terminationGracePeriodSeconds: 5
      volumes:
      - configMap:
          defaultMode: 420
          name: xxl-job-admin-configmap
        name: config
status:
  availableReplicas: 1
  conditions:
  - lastTransitionTime: "2022-04-24T08:47:49Z"
    lastUpdateTime: "2023-07-16T11:40:54Z"
    message: ReplicaSet "xxl-job-admin-69669c878d" has successfully progressed.
    reason: NewReplicaSetAvailable
    status: "True"
    type: Progressing
  - lastTransitionTime: "2024-09-12T03:03:28Z"
    lastUpdateTime: "2024-09-12T03:03:28Z"
    message: Deployment has minimum availability.
    reason: MinimumReplicasAvailable
    status: "True"
    type: Available
  observedGeneration: 20
  readyReplicas: 1
  replicas: 1
  updatedReplicas: 1

---

apiVersion: v1
kind: Service
metadata:
  creationTimestamp: "2022-04-24T08:47:48Z"
  labels:
    app: xxl-job-admin
  name: xxl-job-admin
  namespace: erp-prod
  resourceVersion: "6236710"
  uid: f62ae546-3fad-4c1c-ba83-1e0748b738cc
spec:
  clusterIP: 172.20.190.244
  clusterIPs:
  - 172.20.190.244
  internalTrafficPolicy: Cluster
  ipFamilies:
  - IPv4
  ipFamilyPolicy: SingleStack
  ports:
  - name: tcp
    port: 8080
    protocol: TCP
    targetPort: 8080
  selector:
    app: xxl-job-admin
  sessionAffinity: None
  type: ClusterIP
status:
  loadBalancer: {}
  
---

apiVersion: v1
data:
  application.properties: |
    ### web
    server.port=8080
    server.servlet.context-path=/xxl-job-admin

    ### actuator
    management.server.servlet.context-path=/actuator
    management.health.mail.enabled=false

    ### resources
    spring.mvc.servlet.load-on-startup=0
    spring.mvc.static-path-pattern=/static/**
    spring.resources.static-locations=classpath:/static/

    ### freemarker
    spring.freemarker.templateLoaderPath=classpath:/templates/
    spring.freemarker.suffix=.ftl
    spring.freemarker.charset=UTF-8
    spring.freemarker.request-context-attribute=request
    spring.freemarker.settings.number_format=0.##########

    ### mybatis
    mybatis.mapper-locations=classpath:/mybatis-mapper/*Mapper.xml
    #mybatis.type-aliases-package=com.xxl.job.admin.core.model

    ### xxl-job, datasource
    spring.datasource.url=jdbc:mysql://tms-mysql-cluster.cluster-c2bihysdu6ok.ap-east-1.rds.amazonaws.com:3536/xxl_job?useUnicode=true&characterEncoding=UTF-8&autoReconnect=true&serverTimezone=Asia/Shanghai
    spring.datasource.username=xxl_job
    spring.datasource.password=OayM763df
    spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

    ### datasource-pool
    spring.datasource.type=com.zaxxer.hikari.HikariDataSource
    spring.datasource.hikari.minimum-idle=10
    spring.datasource.hikari.maximum-pool-size=30
    spring.datasource.hikari.auto-commit=true
    spring.datasource.hikari.idle-timeout=30000
    spring.datasource.hikari.pool-name=HikariCP
    spring.datasource.hikari.max-lifetime=900000
    spring.datasource.hikari.connection-timeout=30000
    spring.datasource.hikari.connection-test-query=SELECT 1
    spring.datasource.hikari.validation-timeout=10000

    ### xxl-job, email
    spring.mail.host=smtp.exmail.qq.com
    spring.mail.port=465
    spring.mail.username=
    spring.mail.from=
    spring.mail.password=
    spring.mail.properties.mail.smtp.auth=true
    spring.mail.properties.mail.smtp.starttls.enable=true
    spring.mail.properties.mail.smtp.starttls.required=true
    spring.mail.properties.mail.smtp.socketFactory.class=javax.net.ssl.SSLSocketFactory

    ### xxl-job, access token
    xxl.job.accessToken=

    ### xxl-job, i18n (default is zh_CN, and you can choose "zh_CN", "zh_TC" and "en")
    xxl.job.i18n=zh_CN

    ## xxl-job, triggerpool max size
    xxl.job.triggerpool.fast.max=200
    xxl.job.triggerpool.slow.max=100

    ### xxl-job, log retention days
    xxl.job.logretentiondays=30
kind: ConfigMap
metadata:
  creationTimestamp: "2022-04-24T08:47:48Z"
  name: xxl-job-admin-configmap
  namespace: erp-prod
  resourceVersion: "889353219"
  uid: 46835fc0-fba5-409f-8b1e-fa56b9bfd311
```

创建 ytdocker，访问镜像仓库

```plaintext
apiVersion: v1
data:
  .dockerconfigjson: eyJhdXRocyI6eyJkb2NrZXJodWItcHJvZC55aW50YWVycC5jb20iOnsidXNlcm5hbWUiOiJBV1MiLCJwYXNzd29yZCI6ImV5SndZWGxzYjJGa0lqb2lkbWc1VkRGRU9WZ3dObEk0VmpKSkswdHBNell3VldGM1NYbHZaMEZ2YjIwNVpESlBPVGhOYTFobE1uSkZVbFV2UVRNcmJEWXpNMlF3YTA5bFYxSkdNbXM0V0ZnMlMwcGFibTFaYVRaT1IyZFhkWEpPTUU1a1YyVmFRMDk0Wld0U1pIUmpMelZDTWtrclpEVk5TVk0wUlRONlpHTkZXVmRLYm1vdmQwc3lPU3RYZWxkNWJYQkJia0pTTlhSdmQyTjJWMmhNY1dVNWVURkNPWGswVlRRMldFbFZPWFYzY1RVNU1WRk9TWFJDT0ZsWFNuWnBOelZUTDBkUlJIcDRURWhoWjNaR1RFUlZSM3A1VWpkSVRqY3lURWhCVXpJNWFWVkdjM0ZtU0ZsdGVqSnNZelV2Ukd0emRpOUVObHBVYUM4cmEwWkNaMFJITldKWWNpdHRkeklyZHlzMlFWWmFlVzEyY1d0dFRWbFlRaXRrTlZNd2R6TkdhQ3RPVjJ4MGVUUTBSVXRDVEZselkwZE5kMFpEYlhsWWFtMTNLMUZGZEVFeVpEWldiVGR0WmxKT09GTkRUV0pDVVd0VlVFZGtSbHBIV1RoaVVrMWFiakJQYzBkbFlUbDRWVzVUZVRacVZUaDFTa1JCVmtkRU9VUkVRbXN6UkVwTWFXdDJhSEJsVjNkNWVXRkxSRVl6VTNOUFVuQTJhbnBrUzFacVUySk5OV2t5Ym5GWWNUQk1jMU5pUjBWVE9HdEhLek4zUWtsbWRFMDRNamQyV1VneGNtVTRlVFp6ZW1wNlZUWlVLMmMxYkhoV2NuZG5jbXN3YmtKQ2JHTXlXVlozYTB0V2RWQkVia1ptU0drM1dDOUVkMjkyWjNCS1FUazJWRm93VEdoeWFrRmFXVlZvUzI4MldGbFBNVTlOWWs5bFRrYzRaRzlvVkVSdmNucGtXR0ZDWmxsdVJtZDJkMkpKYXpJelFubFljMFF6ZUdSamRURkxUa3AwUm1OdWRUbEdTRVZNVFVGR2NrSldURVV5YURWNFZXZGhXSFl2VTJwc05YRTRZbFJRS3pGb2JHNVpRVEk1Y1ZkTE5FY3ZPWEV2V1VOM2NIcHpjemxNTkhSbWNFSXlLM1Y1Um5KNWVFSTBLMmQ1YVhwRldGSllUazVCVEhaS1VHWkhUWFUxWlVGdVIwdENTM0Z5YkhjM2RqZFNTSGt3ZG1kRVJsSlJOamxxVkVSMFVYcDFOa1JQYWtSME0wNUxVSGxVY3pkVWFtcFlXak5aVW5KWFprMHJlVGRIUVdRMlIwOXFOeTlFVTB0SGVWVjNUa3haVUM5a1FqaFVlV1J6TTBGSldXWnJaMk00TmtWcWNIcFZZemtyUlRjMFVtODBkRU5NTkZCWGQwRmhOVmxNTjFJNGFqa3lVbXRTWlVGU2RuRTRWbGhqU3k5bFkwUktlbFZ3VTNSd1pWTkdWbEprZFRORU0wbHNja1ZaVjBod2JrSXhhR2d2ZEU5eGNsWTVLMVEwVGpOUFp6VktZakZCYkZGbFdUVnBjbHBoVFhoalRsaEphMk5MU1ZBMFFrcDJVRkpOWkVwcVFVY3ZWa1UzWkdOM1RYWXZOVUl6WVhKclJFcHNjR3cwTjJ3MFRYbEdibkJQV1VGNVIwdElha2QyZUd4MFJUVldaMU4zU1VacWRtSjZaMDFwVDJJeUsycEJOR1V3YVVWU2JGTkJWVTR6Y0haNFlVRkdTblJWU0hOMFdTOVFZakEwVWxjclJrRmxkMHBEWjI5S1ZVVjRRMHhqYzNobmMxcGlhRUpOT1hwMFRURnhjVFYwWTFaS05HeEhOR1Y2UWpnMlpEaEhURUpLVUZwTFJuUkxVME0zV0ZwUWRGcFRSRTVvV2pKTlUwZGtWV3hHV21waWVWcG1ka3hvTUhjMGJqWjNTRXhGVVRGdVlsRXpabWR0ZFU5VFZtTXdZMWhZVmpseU9WRk1UbFZHYVZCbWVXMVlablZWYUVGTWFFcEZUUzlNZW5ocGVXbzBSRU5TWVRkSlJWRjBhVlIxVG1rdmNEWldSbVZ5YUVzclZWcHhTWE5hU1RZeVRIRmFVelp4VWtsU1ZGUkVjMDV5TkZSNVRYaHFkSFZZWjFKa1dHbzFURU5GV1dST09VSm1SM2xvZUVwNmNYcDVPWFkzTjFsQ05VdHJOVkpMVjJsV1dVRXhlSGN3UkRsRVNubzJhVk00UjBKcmVVcDBXbWhMVkRsQ2FGWlNNbXBOY0ZGUk5IUkdVV0ZTT1hKdVpHcG1SekprWjBGM1FtNUdPREYyY0VWTFRXUjFjM04zVFVaRldXcDBjek5VYzI1bVZGSXZXakUyYUVSWmR6WlpWRmxRTlVWMWIxcENOVXBOTVhoT0wzTmFOV2d5T1RjMFYwUlNibXRxZVVjMVRFSmFkRFZrT0hKMlFXNVlVMVJ3TW5oMmRqbDVZekYzV0dNdlJXSXlWRzlhVmpOc2JrTkJXSGhOUTBJeU0xWTVabWQ1Y1ZndlZFSnROVmhUT1hOaU1tRktkMGhVUTJFNVJHOXFPRXN6YWtObVFsTldOVzlMVFRWbU1sbGhPR2MzSzBreFFYb3JPRVV2VjA5RmJ6TlhhRlJEWjBOMlN6SkxkbkpUUTFKb2NqTm9XRzVtTnpCYVEyRkRWRFExYUU5QlZtOWpLM2REY1ZsUlJUWkhPVTB2UzJWTU4yVmtLMVJTTTJVd1RGcEdPRXByVVhob2JWSmxSVWRPVFV4SGVXaGtaV1pJUlc1dmJEQTJiVTkwV1cxUlRpODVWRWt5VVQwOUlpd2laR0YwWVd0bGVTSTZJa0ZSU1VKQlNHZDRVV0Z4UWs5S01FZHhiMEZzY21VNE5HUnFjV0ZNVTBKNVRWZDZjalJuUVdwa2RUbHJTSGxOY1ZKM1J6RmtXVFY2Vm01blNIUjFSbnBLVm5vMWRtVkxhVUZCUVVGbWFrSTRRbWRyY1docmFVYzVkekJDUW5kaFoySjZRblJCWjBWQlRVZG5SME5UY1VkVFNXSXpSRkZGU0VGVVFXVkNaMnhuYUd0blFscFJUVVZCVXpSM1JWRlJUWFJLVVdKeGExUklXR0pUUm14WVltUkJaMFZSWjBSMGEyOU1OVzVxYmxkVFJ5dHZRVWxWTjFsVFdYaE9aVTVFUlhKcGRUaEZjazgzTXpnMlpqTmxkM0JzZFROQmRVMXJiemd6ZW10T1pEQlhVbTB4UTNCcGJucFpRa1pLVEZZNFkyNVpUM2REWnowOUlpd2lkbVZ5YzJsdmJpSTZJaklpTENKMGVYQmxJam9pUkVGVVFWOUxSVmtpTENKbGVIQnBjbUYwYVc5dUlqb3hOekk1TURnd01EWXhmUT09IiwiZW1haWwiOiJhd3NyZWdyZW5ld0BkZW1vLnRlc3QiLCJhdXRoIjoiUVZkVE9tVjVTbmRaV0d4ellqSkdhMGxxYjJsa2JXYzFWa1JHUlU5V1ozZE9iRWswVm1wS1Nrc3dkSEJOZWxsM1ZsZEdNMU5ZYkhaYU1FWjJZakl3TlZwRVNsQlBWR2hPWVRGb2JFMXVTa1pWYkZWMlVWUk5jbUpFV1hwTk1sRjNZVEE1YkZZeFNrZE5iWE0wVjBabk1sTXdjR0ZpYlRGYVlWUmFUMUl5WkZoa1dFcFBUVVUxYTFZeVZtRlJNRGswV2xkMFUxcElVbXBNZWxaRFRXdHJjbHBFVms1VFZrMHdVbFJPTmxwSFRrWlhWbVJMWW0xdmRtUXdjM2xQVTNSWVpXeGtOV0pZUWtKaWEwcFRUbGhTZG1ReVRqSldNbWhOWTFkVk5XVlVSa05QV0dzd1ZsUlJNbGRGYkZaUFdGWXpZMVJWTlUxV1JrOVRXRkpEVDBac1dGTnVXbkJPZWxaVVREQmtVbEpJY0RSVVJXaG9Xak5hUjFSRlVsWlNNM0ExVldwa1NWUnFZM2xVUldoQ1ZYcEpOV0ZXVmtkak0wWnRVMFpzZEdWcVNuTlplbFYyVWtkMGVtUnBPVVZPYkhCVllVTTRjbUV3V2tOYU1GSklUbGRLV1dOcGRIUmtla2x5Wkhsek1sRldXbUZsVnpFeVkxZDBkRlJXYkZsUmFYUnJUbFpOZDJSNlRrZGhRM1JQVmpKNE1HVlVVVEJTVlhSRFZFWnNlbGt3WkU1a01GcEVZbGhzV1dGdE1UTkxNVVpHWkVWRmVWcEVXbGRpVkdSMFdteEtUMDlHVGtSVVYwcERWVmQwVmxWRlpHdFNiSEJJVjFSb2FWVnJNV0ZpYWtKUVl6QmtiRmxVYkRSV1Z6VlVaVlJhY1ZaVWFERlRhMUpDVm10a1JVOVZVa1ZSYlhONlVrVndUV0ZYZERKaFNFSnNWak5rTldWWFJreFNSVmw2VlROT1VGVnVRVEpoYm5CclV6RmFjVlV5U2s1T1YydDVZbTVHV1dOVVFrMWpNVTVwVWpCV1ZFOUhkRWhMZWs0elVXdHNiV1JGTURSTmFtUXlWMVZuZUdOdFZUUmxWRnA2Wlcxd05sWlVXbFZMTW1NeFlraG9WMk51Wkc1amJYTjNZbXRLUTJKSFRYbFhWbG96WVRCMFYyUldRa1ZpYTFwdFUwZHJNMWRET1VWa01qa3lXak5DUzFGVWF6SldSbTkzVkVkb2VXRnJSbUZYVmxadlV6STRNbGRHYkZCTlZUbE9XV3M1YkZScll6UmFSemx2VmtWU2RtTnVjR3RYUjBaRFdteHNkVkp0WkRKa01rcEtZWHBKZWxGdWJGbGpNRkY2WlVkU2FtUlVSa3hVYTNBd1VtMU9kV1JVYkVkVFJWWk5WRlZHUjJOclNsZFVSVlY1WVVSV05GWlhaR2hYU0ZsMlZUSndjMDVZUlRSWmJGSlJTM3BHYjJKSE5WcFJWRWsxWTFaa1RFNUZZM1pQV0VWMlYxVk9NMk5JY0hwamVteE5Ua2hTYldORlNYbExNMVkxVW01S05XVkZTVEJMTW1RMVlWaHdSbGRHU2xsVWF6VkNWRWhhUzFWSFdraFVXRlV4V2xWR2RWSXdkRU5UTTBaNVlraGpNMlJxWkZOVFNHdDNaRzFrUlZKc1NsSk9hbXh4VmtWU01GVlljREZPYTFKUVlXdFNNRTB3TlV4VlNHeFZZM3BrVldGdGNGbFhhazVhVlc1S1dGcHJNSEpsVkdSSVVWZFJNbEl3T1hGT2VUbEZWVEIwU0dWV1ZqTlVhM2hhVlVNNWExRnFhRlZsVjFKNlRUQkdTbGRYV25KYU1rMDBUbXRXY1dOSWNGWlplbXR5VWxSak1GVnRPREJrUlU1TlRrWkNXR1F3Um1oT1ZteE5UakZKTkdGcWEzbFZiWFJUV2xWR1UyUnVSVFJXYkdocVUzazViRmt3VWt0bGJGWjNWVE5TZDFwV1RrZFdiRXByWkZST1JVMHdiSE5qYTFaYVZqQm9kMkpyU1hoaFIyZDJaRVU1ZUdOc1dUVkxNVkV3VkdwT1VGcDZWa3RaYWtaQ1lrWkdiRmRVVm5CamJIQm9WRmhvYWxSc2FFcGhNazVNVTFaQk1GRnJjREpWUmtwT1drVndjVkZWWTNaV2ExVXpXa2RPTTFSWVdYWk9WVWw2V1ZoS2NsSkZjSE5qUjNjd1RqSjNNRlJZYkVkaWJrSlFWMVZHTlZJd2RFbGhhMlF5WlVkNE1GSlVWbGRhTVU0elUxVmFjV1J0U2paYU1ERndWREpKZVVzeWNFSk9SMVYzWVZWV1UySkdUa0pXVlRSNlkwaGFORmxWUmtkVGJsSldVMGhPTUZkVE9WRlpha0V3Vld4amNsSnJSbXhrTUhCRVdqSTVTMVpWVmpSUk1IaHFZek5vYm1NeGNHbGhSVXBPVDFod01GUlVSbmhqVkZZd1dURmFTMDVIZUVoT1IxWTJVV3BuTWxwRWFFaFVSVXBMVlVad1RGSnVVa3hWTUUwelYwWndVV1JHY0ZSU1JUVnZWMnBLVGxVd1pHdFdWM2hIVjIxd2FXVldjRzFrYTNodlRVaGpNR0pxV2pOVFJYaEdWVlJHZFZsc1JYcGFiV1IwWkZVNVZGWnRUWGRaTVdoWlZtcHNlVTlXUmsxVWJGWkhZVlpDYldWWE1WbGFibFpXWVVWR1RXRkZjRVpVVXpsTlpXNW9jR1ZYYnpCU1JVNVRXVlJrU2xKV1JqQmhWbEl4VkcxcmRtTkVXbGRTYlZaNVlVVnpjbFpXY0hoVFdFNWhVMVJaZVZSSVJtRlZlbHA0Vld0c1UxWkdVa1ZqTURWNVRrWlNOVlJZYUhGa1NGWlpXakZLYTFkSGJ6RlVSVTVHVjFkU1QwOVZTbTFTTTJ4dlpVVndObU5ZY0RWUFdGa3pUakZzUTA1VmRISk9Wa3BNVmpKc1YxZFZSWGhsU0dOM1VrUnNSVk51YnpKaFZrMDBVakJLY21WVmNEQlhiV2hNVmtSc1EyRkdXbE5OYlhCT1kwWkdVazVJVWtkVlYwWlRUMWhLZFZwSGNHMVNla3ByV2pCR00xRnROVWRQUkVZeVkwVldURlJYVWpGak0wNHpWRlZhUmxkWGNEQmplazVWWXpJMWJWWkdTWFpYYWtVeVlVVlNXbVI2V2xwV1JteFJUbFZXTVdJeGNFTk9WWEJPVFZob1Qwd3pUbUZPVjJkNVQxUmpNRll3VWxOaWJYUnhaVlZqTVZSRlNtRmtSRlpyVDBoS01sRlhOVmxWTVZKM1RXNW9NbVJxYkRWWmVrWXpWMGROZGxKWFNYbFdSemxoVm1wT2MySnJUa0pYU0doT1VUQkplVTB4V1RWYWJXUTFZMVpuZGxaRlNuUk9WbWhVVDFoT2FVMXRSa3RrTUdoVlVUSkZOVkpIT1hGUFJYTjZZV3RPYlZGc1RsZE9WemxNVkZSV2JVMXNiR2hQUjJNelN6QnJlRkZZYjNKUFJWVjJWakE1Um1KNlRsaGhSbEpFV2pCT01sTjZTa3hrYmtwVVVURktiMk5xVG05WFJ6VnRUbnBDWVZFeVJrUldSRkV4WVVVNVFsWnRPV3BMTTJSRVkxWnNVbEpVV2toUFZUQjJVekpXVFU0eVZtdExNVkpUVFRKVmQxUkdjRWRQUlhCeVZWaG9iMkpXU214U1ZXUlBWRlY0U0dWWGFHdGFWMXBKVWxjMWRtSkVRVEppVlRrd1YxY3hVbFJwT0RWV1JXdDVWVlF3T1VscGQybGFSMFl3V1ZkMGJHVlRTVFpKYTBaU1UxVktRbE5IWkRSVlYwWjRVV3M1UzAxRlpIaGlNRVp6WTIxVk5FNUhVbkZqVjBaTlZUQktOVlJXWkRaamFsSnVVVmR3YTJSVWJISlRTR3hPWTFaS00xSjZSbXRYVkZZMlZtMDFibE5JVWpGU2JuQkxWbTV2TVdSdFZreGhWVVpDVVZWR2JXRnJTVFJSYldSeVkxZG9jbUZWWXpWa2VrSkRVVzVrYUZveVNqWlJibEpDV2pCV1FsUlZaRzVTTUU1VVkxVmtWRk5YU1hwU1JrWkdVMFZHVlZGWFZrTmFNbmh1WVVkMGJsRnNjRkpVVlZaQ1ZYcFNNMUpXUmxKVVdGSkxWVmRLZUdFeFVrbFhSMHBVVW0xNFdWbHRVa0phTUZaU1dqQlNNR0V5T1UxT1Z6VnhZbXhrVkZKNWRIWlJWV3hXVGpGc1ZGZFlhRTlhVlRWRlVsaEtjR1JVYUVaamF6Z3pUWHBuTWxwcVRteGtNMEp6WkZST1FtUlZNWEppZW1kNlpXMTBUMXBFUWxoVmJUQjRVVE5DY0dKdWNGcFJhMXBMVkVaWk5Ga3lOVnBVTTJSRVdub3dPVWxwZDJsa2JWWjVZekpzZG1KcFNUWkpha2xwVEVOS01HVllRbXhKYW05cFVrVkdWVkZXT1V4U1ZtdHBURU5LYkdWSVFuQmpiVVl3WVZjNWRVbHFiM2hPZWtrMVRVUm5kMDFFV1hobVVUMDkifX19
kind: Secret
metadata:
  name: ytdocker
  namespace: erp-prod
type: kubernetes.io/dockerconfigjson
```

执行 yaml 文件

```plaintext
kubectl apply -f ytdocker.yaml
```
```plaintext
kubectl apply -f /opt/xxl-job-admin2.yaml
```

浏览器访问

后缀一定要带上/xxl-job-admin，不然会404

```plaintext
http://192.168.3.101:30088/xxl-job-admin/
```

默认用户密码

```plaintext
admin / 123456
```
```plaintext
spring.datasource.url=jdbc:mysql://mysql8.ops.yintaerp.com:3306/xxl_job_eu?useUnicode=true&characterEncoding=UTF-8&autoReconnect=true&serverTimezone=Asia/Shanghai
```