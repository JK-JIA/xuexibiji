# zookeeper-rabbitmq搭建

##### 生产基础环境概述

欧洲和美国站点都需要部署 rabbitmq 集群，zookeeper 集群，都做3副本集群，复用服务器，采用dockercompose 方式部署

下面编写 us 美国服务器部署（eu 欧洲服务器部署方式一样）

aws 云 051826713468）账号，us-east-1 弗吉尼亚北部 region

配置如下，3台 ec2 实例

|  服务器ip  |  配置  |  环境  |
| --- | --- | --- |
|  172.34.128.194  |  4c/8G  Ubuntu 24.04.1 LTS  |  zk-mq-01  |
|  172.34.149.214  |  4c/8G  Ubuntu 24.04.1 LTS  |  zk-mq-02  |
|  172.34.174.75  |  4c/8G  Ubuntu 24.04.1 LTS  |  zk-mq-03  |

### 基础环境配置 (3台都做)

#### 1 配置时间同步

安装 ntpdate 命令

```plaintext
sudo apt update
sudo apt install ntpdate -y
```

同步阿里云

```plaintext
ntpdate ntp.aliyun.com
```

检查时间

```plaintext
date

timedatectl
```

升级openssh后Xshell无法使用sftp

参考网址

```plaintext
https://blog.csdn.net/mayifan0/article/details/89882052
```

修改文件

```plaintext
vim /etc/ssh/sshd_config
# 注释掉原来的
#Subsystem sftp  /usr/libexec/openssh/sftp-server
Subsystem sftp  internal-sftp
```

重启服务

```plaintext
systemctl restart ssh
```

#### 2 安装docker，docker-compose 服务

ubuntu20.04 安装docker 和 docker-compose

```plaintext
1、卸载可能存在的或者为安装成功的Docker版本
sudo apt-get remove docker docker-engine docker-ce docker.io

2、添加阿里云的GPG密钥
curl -fsSL http://mirrors.aliyun.com/docker-ce/linux/ubuntu/gpg | sudo apt-key add -

或者添加官方gpg密钥 #（这里因为服务器在欧洲，所以使用的官方的）
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

3、使用以下命令设置阿里云存储库
sudo add-apt-repository "deb [arch=amd64] http://mirrors.aliyun.com/docker-ce/linux/ubuntu $(lsb_release -cs) stable"

或者使用官方存储库 #（这里因为服务器在欧洲，所以使用的官方的）
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

4、更新apt包索引，安装最新版本的Docker Engine、containerd 和 Docker Compose
sudo apt-get update
sudo apt-get install docker-ce docker-ce-cli containerd.io docker-compose-plugin -y

验证docker
sudo docker version
sudo systemctl start docker
sudo systemctl enable docker

查看系统架构类型
uname -a
Linux ip-172-34-128-194 6.8.0-1016-aws #17-Ubuntu SMP Wed Sep  4 11:15:30 UTC 2024 aarch64 aarch64 aarch64 GNU/Linux

安装 docker-compose (amd64 版本)
sudo curl -SL https://github.com/docker/compose/releases/download/v2.6.0/docker-compose-linux-x86_64 -o /usr/local/bin/docker-compose && chmod +x /usr/local/bin/docker-compose

安装 docker-compose (aarch64 版本)
sudo curl -SL https://github.com/docker/compose/releases/download/v2.6.0/docker-compose-linux-aarch64 -o /usr/local/bin/docker-compose && chmod +x /usr/local/bin/docker-compose

启动 dockers-compose
sudo systemctl start docker-compose
sudo systemctl enable docker-compose
```

##### 2.1 修改主机名

```plaintext
hostnamectl set-hostname zk-mq-01
hostnamectl set-hostname zk-mq-02
hostnamectl set-hostname zk-mq-03

#重新连接会话生效
exec bash 
```

修改 hosts 文件

```plaintext
vim /etc/hosts

172.34.128.197 zk-mq-01
172.34.149.214 zk-mq-02
172.33.160.20 zk-mq-03
```

基础环境设置完毕，下面开始编写 zookeeper 和 rabbitmq 集群的 docker-compose 文件

先部署 rabbitmq 集群

#### 3 编写 docker-compose 文件

查看部署目录结构

```plaintext
tree rabbitmq
rabbitmq
├── Dockerfile
├── data  #挂载的本地存储目录
├── docker-compose.yaml
├── rabbitmq
│   ├── enabled_plugins  #指定 RabbitMQ 启动时需要加载的插件
│   └── rabbitmq.conf  #配置文件
└── rabbitmq_delayed_message_exchange-3.11.1.ez # 插件
```

查看 rabbitmq.conf 文件

```plaintext
cat rabbitmq/rabbitmq.conf 
loopback_users.guest = false # 禁用 guest 用户通过非本地（非 localhost）连接访问 RabbitMQ
listeners.tcp.default = 5672 # 指定 RabbitMQ 使用的 AMQP监听的默认 TCP 端口，默认是 5672
management.tcp.port = 15672 # 指定 RabbitMQ web控制台 插件使用的 HTTP 端口，默认是 15672
management_agent.disable_metrics_collector = false # 禁用 RabbitMQ Management Agent 的指标收集功能
```

查看 enabled\_plugins 文件

```plaintext
cat rabbitmq/enabled_plugins 
[rabbitmq_prometheus,rabbitmq_delayed_message_exchange,rabbitmq_management,rabbitmq_prometheus].
```

docker-compose up 启动后会自动创建挂载卷

```plaintext
docker volume ls
DRIVER    VOLUME NAME
local     2f9a7ab95d2fcff4b6f9829e13a6351e67f5de8e788a7382993064956e3652a2
local     52b50306b9c927bbbe91efb71d50ec3bec7efdf780d9d1df7bb4b00c093fa7c7
local     733f8f2496b463a902974e363049e2048bc337259fb313b09be125e859ac6ca0
local     254124bd4f60e29cf1934383af3aee67d9272c44fee6e125bf07f97223f02d6a
local     7122208a8e0d449b8c7c06788e44fac01a751b367aa90c41a1f4bd6274383238
local     fd79098d555689fa7d115c7bc495be5c955318b8e018284902be3748786802c1
local     rabbitmq-sit_datasit # docker-compos 配置的名字，自动创建


docker volume inspect rabbitmq-sit_datasit 
[
    {
        "CreatedAt": "2024-09-23T02:39:23Z",
        "Driver": "local",
        "Labels": {
            "com.docker.compose.project": "rabbitmq-sit",
            "com.docker.compose.version": "2.6.0",
            "com.docker.compose.volume": "datasit"
        },
        "Mountpoint": "/var/lib/docker/volumes/rabbitmq-sit_datasit/_data", #挂载地址
        "Name": "rabbitmq-sit_datasit",
        "Options": null,
        "Scope": "local"
    }
```

修改Dockerfile ，From 镜像设置为 3.11

（FROM rabbitmq:3 会拉取最新版本，启动会插件兼容性报错）

```plaintext
cat Dockerfile 
FROM rabbitmq:3.11
COPY rabbitmq_delayed_message_exchange-3.11.1.ez /opt/rabbitmq/plugins/rabbitmq_delayed_message_exchange-3.11.1.ez
```

编写dockercompose.yaml 文件 （zk-mq-01）

```plaintext
version: '3'
services:
  rabbitmq:
    container_name: rabbitmq-us  #这里eu环境改为eu
    restart: always  
    hostname: zk-mq-01
    build:
      context: .
      dockerfile: Dockerfile
    ports:
      - 5672:5672
      - 4369:4369
      - 15672:15672
      - 25672:25672
      - 15692:15692
    entrypoint:
    - rabbitmq-server
    - --detached
    volumes:
      - /etc/hosts:/etc/hosts
      - /etc/localtime:/etc/localtime
      - /etc/timezone:/etc/timezone
     #- ./enabled_plugins:/etc/rabbitmq/enabled_plugins
      - ./rabbitmq:/etc/rabbitmq
      - ./data:/var/lib/rabbitmq/
    healthcheck:
      test: ["CMD", "rabbitmq-diagnostics", "ping"]
      interval: 1m30s
      timeout: 10s
      retries: 3
```

编写dockercompose.yaml 文件 （zk-mq-02）

```plaintext
version: '3'
services:
  rabbitmq:
    container_name: rabbitmq-us ##这里eu环境改为eu
    restart: always  
    hostname: zk-mq-02
    build:
      context: .
      dockerfile: Dockerfile
    ports:
      - 5672:5672
      - 4369:4369
      - 15672:15672
      - 25672:25672
      - 15692:15692
    entrypoint:
    - rabbitmq-server
    - --detached
    volumes:
      - /etc/hosts:/etc/hosts
      - /etc/localtime:/etc/localtime
      - /etc/timezone:/etc/timezone
     #- ./enabled_plugins:/etc/rabbitmq/enabled_plugins
      - ./rabbitmq:/etc/rabbitmq
      - ./data:/var/lib/rabbitmq/
    healthcheck:
      test: ["CMD", "rabbitmq-diagnostics", "ping"]
      interval: 1m30s
      timeout: 10s
      retries: 3
```

编写dockercompose.yaml 文件 （zk-mq-03）

```plaintext
version: '3'
services:
  rabbitmq:
    container_name: rabbitmq-us  ##这里eu环境改为eu
    restart: always  
    hostname: zk-mq-03
    build:
      context: .
      dockerfile: Dockerfile
    ports:
      - 5672:5672
      - 4369:4369
      - 15672:15672
      - 25672:25672
      - 15692:15692
    entrypoint:
    - rabbitmq-server
    - --detached
    volumes:
      - /etc/hosts:/etc/hosts
      - /etc/localtime:/etc/localtime
      - /etc/timezone:/etc/timezone
     #- ./enabled_plugins:/etc/rabbitmq/enabled_plugins
      - ./rabbitmq:/etc/rabbitmq
      - ./data:/var/lib/rabbitmq/
    healthcheck:
      test: ["CMD", "rabbitmq-diagnostics", "ping"]
      interval: 1m30s
      timeout: 10s
      retries: 3
```

启动服务

```plaintext
docker-compose up -d 
```

进入容器

```plaintext
docker-compose exec rabbitmq /bin/bash
```

查看集群状态dock

```plaintext
rabbitmqctl cluster_status
```

加入集群

```plaintext
rabbitmqctl stop_app
rabbitmqctl reset
rabbitmqctl join_cluster rabbit@zk-mq-01
rabbitmqctl start_app
```

查看开启的插件

```plaintext
rabbitmq-plugins list -E

Listing plugins with pattern ".*" ...
 Configured: E = explicitly enabled; e = implicitly enabled
 | Status: * = running on rabbit@rabbitmq-eu
 |/
[E*] rabbitmq_delayed_message_exchange 3.8.0
[E*] rabbitmq_federation               3.10.1
[E*] rabbitmq_federation_management    3.10.1
[E*] rabbitmq_management               3.10.1
[E*] rabbitmq_prometheus               3.10.1
```

如果未开启，在容器中执行命令开启

```plaintext
rabbitmq-plugins enable rabbitmq_federation
rabbitmq-plugins enable rabbitmq_federation_management
```

访问控制台

```plaintext
http://172.33.165.34:15672/
```

默认用户密码

```plaintext
guest / guest
```

登录控制台，Admin 修改 guest 用户默认密码

至此 rabbitmq 部署完成

## 2 部署zookeeper

1 查看目录结构

```plaintext
tree zookeeper
zookeeper
├── data #数据存储目录
│   └── myid # 根据机器改为 1,2,3 ，zk-mq-01为1
└── docker-compose.yaml
```

2 zk-mq-01 编写docker-compose文件

```plaintext
version: '3'
services:
  zookeeper-eu:
    container_name: zookeeper-us
    image:  zookeeper:3.8
    restart: always  
    # 设置为节点hostname 名称
    hostname: zk-mq-01
    ports:
    - 2181:2181
    - 2888:2888
    - 3888:3888
    environment:
    - ZOO_4LW_COMMANDS_WHITELIST=*
    - ZOO_MAX_CLIENT_CNXNS=3000
    - ZOO_INIT_LIMIT=10
    - ZOO_MY_ID=1 #这里改为1
    - ZOO_SERVERS=server.1=0.0.0.0:2888:3888;2181 server.2=172.34.149.214:2888:3888;2181 server.3=172.34.174.75:2888:3888;2181

    volumes:
      - /etc/hosts:/etc/hosts
      - /etc/localtime:/etc/localtime
      - /etc/hostname:/etc/hostname
      # 挂载配置目录
      - ./data:/data
    healthcheck:
      test: ["CMD", "bin/zkServer.sh", "status"]
      interval: 1m30s
      timeout: 10s
      retries: 3
```

zk-mq-02 编写docker-compose文件

```plaintext
version: '3'
services:
  zookeeper-us:
    container_name: zookeeper-us
    image:  zookeeper:3.8
    restart: always  
    # 设置为节点hostname 名称
    hostname: zk-mq-02
    ports:
    - 2181:2181
    - 2888:2888
    - 3888:3888
    environment:
    - ZOO_4LW_COMMANDS_WHITELIST=*
    - ZOO_MAX_CLIENT_CNXNS=3000
    - ZOO_INIT_LIMIT=10
    - ZOO_MY_ID=2 #这里改为2
    - ZOO_SERVERS=server.1=172.34.128.194:2888:3888;2181 server.2=0.0.0.0:2888:3888;2181 server.3=172.34.174.75:2888:3888;2181

    volumes:
      - /etc/hosts:/etc/hosts
      - /etc/localtime:/etc/localtime
      - /etc/hostname:/etc/hostname
      # 挂载配置目录
      - ./data:/data
    healthcheck:
      test: ["CMD", "bin/zkServer.sh", "status"]
      interval: 1m30s
      timeout: 10s
      retries: 3
```

zk-mq-03 编写docker-compose文件

```plaintext
version: '3'
services:
  zookeeper-us:
    container_name: zookeeper-us
    image:  zookeeper:3.8
    restart: always  
    # 设置为节点hostname 名称
    hostname: zk-mq-03
    ports:
    - 2181:2181
    - 2888:2888
    - 3888:3888
    environment:
    - ZOO_4LW_COMMANDS_WHITELIST=*
    - ZOO_MAX_CLIENT_CNXNS=3000
    - ZOO_INIT_LIMIT=10
    - ZOO_MY_ID=3 #这里改为3
    - ZOO_SERVERS=server.1=172.34.128.194:2888:3888;2181 server.2=172.34.149.214:2888:3888;2181 server.3=0.0.0.0:2888:3888;2181

    volumes:
      - /etc/hosts:/etc/hosts
      - /etc/localtime:/etc/localtime
      - /etc/hostname:/etc/hostname
      # 挂载配置目录
      - ./data:/data
    healthcheck:
      test: ["CMD", "bin/zkServer.sh", "status"]
      interval: 1m30s
      timeout: 10s
      retries: 3
```

#### 3 创建挂在需要的配置目录和文件

```plaintext
mkdir /data
```

##### 3.1 创建集群 myid 文件

3.101设置为 1 ，3.102 设置为 2 ，3.204 设置为 3

```plaintext
cat data/myid 
1
```

#### 4 启动 docker-compose

```plaintext
docker-compose up -d 
```

##### 4.1 进入容器查看集群状态

```plaintext
docker-compose exec zookeeper-us /bin/bash
```

##### 4.2 查看当前节点状态

```plaintext
./bin/zkServer.sh status
ZooKeeper JMX enabled by default
Using config: /conf/zoo.cfg
Client port found: 2181. Client address: localhost. Client SSL: false.
Mode: follower  # 显示角色为 follower
```

##### 4.3 显示其他节点角色

```plaintext
echo stat | nc <节点ip> 2181
```