# rabbitmq 开启trace\_on插件

简介：

王飞需求，新项目需要 mq 开启 trace\_on 功能；此插件无法放到 mq 插件配置中自动加载；

只能手动执行命令  rabbitmqctl trace\_on 开启，为了重启也生效，在启动命令中加了启动命令；

环境：  

TEST，PRE，PROD 都需要添加

TEST 的 mq 举例，机器：192.168.3.232

1.  进入 docker 容器内部
    

```plaintext
docker ps
CONTAINER ID   IMAGE                                                      COMMAND                  CREATED         STATUS                     PORTS                                                                                                                                      NAMES
977f338fa02c   devhub.yintaerp.com/yintatech-public/uat-rabbitmq:3.10.1   "docker-entrypoint.s…"   6 minutes ago   Up 6 minutes (unhealthy)   4369/tcp, 0.0.0.0:5672->5672/tcp, :::5672->5672/tcp, 5671/tcp, 15691-15692/tcp, 25672/tcp, 0.0.0.0:15672->15672/tcp, :::15672->15672/tcp   rabbitmq-uat
9af97a2c2020   redis:buster                                               "docker-entrypoint.s…"   17 months ago   Up 3 hours (healthy)       0.0.0.0:6379->6379/tcp, :::6379->6379/tcp                                                                                                  redis-log
e8995ff616b5   redis:buster                                               "docker-entrypoint.s…"   17 months ago   Up 3 hours (unhealthy)     0.0.0.0:16379->6379/tcp, :::16379->6379/tcp                                                                                                redis
```
```plaintext
docker  exec  -it  977f338fa02c  /bin/bash
```

执行命令，输出如下表示启动

```shell
root@sh-3-232:/# rabbitmqctl trace_on
Starting tracing for vhost "/" ...
Trace enabled for vhost /
```

加入 docker-compose 文件，实现重启自动开启 trace\_on

```yaml
command: ["sh", "-c", "rabbitmq-server & sleep 10 && rabbitmqctl trace_on && tail -f /dev/null"]
```
```yaml
cat docker-compose.yaml 
version: '3'
services:
  rabbitmq-uat:
    container_name: rabbitmq-uat
    restart: always  
    hostname: sh-3-232
    #build:
    #  context: .
    #  dockerfile: Dockerfile
    #image: rabbitmq:3.0.0
    #image: devhub.yintaerp.com/yintatech-public/rabbitmq:3.10.1
    image: devhub.yintaerp.com/yintatech-public/uat-rabbitmq:3.10.1
    ports:
      - 5672:5672
      - 15672:15672
    command: ["sh", "-c", "rabbitmq-server & sleep 10 && rabbitmqctl trace_on && tail -f /dev/null"]
    volumes:
      #- /etc/hosts:/etc/hosts
      - /etc/localtime:/etc/localtime
      - /etc/timezone:/etc/timezone
     #- ./enabled_plugins:/etc/rabbitmq/enabled_plugins
      - ./rabbitmq:/etc/rabbitmq
      - data:/var/lib/rabbitmq/
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost"]
      interval: 1m30s
      timeout: 10s
      retries: 3
volumes:
  data: 
```

重启测试

```yaml
docker-compose down
docker-compose up -d
```

日志输出包含如下，表示开启 trace\_on

![mq日志.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/YdgOkp0yZWNgl4BX/img/0c9dfa5b-382a-4469-a125-211ca215e7c9.png)