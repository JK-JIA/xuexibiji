# 跨区域Dubbo和消息互通

# Dubbo服务跨区域互通

## Dubbo服务注册

**删除原有dubbo.registry，新增dubbo.registries，其他代码不需要调整。**

**1.香港注册中心配置**

```yaml
dubbo:
  registries:
    zk-hk:
      id: zk-hk
      address: zookeeper://zk.aws.yintaerp.com:2181
      protocol: zookeeper
      register: true # 是否将dubbo服务注册到本数据中心
      default: true # 是否将本数据中心作为服务提供者、服务调用者默认数据中心
    zk-eu:
      id: zk-eu
      address: zookeeper://欧洲zk域名:2181
      protocol: zookeeper
      register: false
      default: false
    zk-us:
      id: zk-us
      address: zookeeper://美国zk域名:2181
      protocol: zookeeper
      register: false
      default: false
```

**2.欧洲注册中心配置**

```yaml
dubbo:
  registries:
    zk-hk:
      id: zk-hk
      address: zookeeper://zk.aws.yintaerp.com:2181
      protocol: zookeeper
      register: false
      default: false
    zk-eu:
      id: zk-eu
      address: zookeeper://欧洲zk域名:2181
      protocol: zookeeper
      register: true # 是否将dubbo服务注册到本数据中心
      default: true # 是否将本数据中心作为服务提供者、服务调用者默认数据中心
```

**3.美国注册中心配置**

```yaml
dubbo:
  registries:
    zk-hk:
      id: zk-hk
      address: zookeeper://zk.aws.yintaerp.com:2181
      protocol: zookeeper
      register: false
      default: false
    zk-us:
      id: zk-us
      address: zookeeper://美国zk域名:2181
      protocol: zookeeper
      register: true # 是否将dubbo服务注册到本数据中心
      default: true # 是否将本数据中心作为服务提供者、服务调用者默认数据中心
```

## Dubbo服务部分注册、部分不注册

**1.使用springboot注解，结合nacos配置。**

```java
@ConditionalOnExpression("${yinta.dubbo.com-yinta-test-TestService}")
```

**PS：@DubboService注解，register为boolean类型，不是字符串类型，无法使用${}做动态注入。**

## Dubbo服务调用

**1.不存在跨数据中心调用**

~~代码不需要调整。~~

:::
10月28号晚上发现：

SIT环境，欧洲Web服务yinta-wms-web，调用欧洲Dubbo服务InvTransactionApi，有时调用到欧洲，有时调用到香港。

10月29号白天验证：

SIT环境，欧洲Web服务yinta-wms-web，调用欧洲Dubbo服务InvTransactionApi，有时调用到欧洲，有时调用到香港。

SIT环境，欧洲Web服务yinta-wms-web，手动指定欧洲注册中心，调用欧洲Dubbo服务InvTransactionApi，正常。

SIT环境，香港Web服务yinta-wms-web，调用香港Dubbo服务InvTransactionApi，正常。

本地环境，调用SIT环境的Dubbo服务InvTransactionApi，香港调用到香港，欧洲调用到欧洲，正常。

目前排查一天，未发现异常原因。未避免生产环境也出现此问题，经讨论后，决定分两个方向：1.手动指定注册中心 2.继续排查此问题。

10月30号：

使用demo-web、demo-rpc，启动欧洲web、欧洲rpc、香港rpc，模拟欧洲web调用欧洲rpc，正常。

SIT环境欧洲，部署一份yinta-wms-web2，远程调试dubbo源码，发现DynamicDirectory读取回来的Invoker既有欧洲、也有香港。进而排查，发现yinta-wms-web的bootstrap-dev.yml里面有配置香港ZK，而发布欧洲的脚本，恰恰也没改过来指定了dev（-Dspring.profiles.active=dev），导致调用异常。
:::

结论：

1.1官方说明文档是有效的。也就是说不显示指定注册中心，默认使用全局默认注册中心。

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/2M9qPBp2VpoZl015/img/edd5f90e-ccd9-44ac-bba1-3c7860346e23.png)

1.2本区域调用，也可以使用手动指定注册中心的方式，以InvTransactionApi为例，统一调整代码为

```java
@DubboReference(registry = {"${yinta.dubbo.region}"})
private InvTransactionApi invTransactionApi;
```

1.3原zk.yml保持不变，维持原单注册中心的配置。新增zk-multi.yml，表示多注册中心的配置，大家按需使用。

**2.存在跨数据中心调用**

修改@DubboReference配置内容。以下配置，可以保证同一套代码，三个数据中心都可以使用。

```java
# 此处只写registry的配置，其他原配置不需要调整
@DubboReference(registry = {"zk-hk"})
private TestService testServiceHk;

@DubboReference(registry = {"zk-eu"})
private TestService testServiceEu;

@DubboReference(registry = {"zk-us"})
private TestService testServiceUs;
```

# RabbitMQ跨区域消息互通

## 1.同区域发送消息、消费消息的情况

代码不变，只需要nacos配置对应的RabbitMQ Server

## 2.跨区域发送消息、消费消息的情况

Exchange交换机的命名，统一使用federated前缀（**federated.原Exchange名**），可以改造完**提前上线**。

**需要注意：本地队列没有消费者后，及时清理，否则会导致消息积压。**

## 3.联邦插件配置

|  Federation Upstream配置  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  区域  |  Name  |  URI  |  Ack mode  |  Exchange  |  Max Hops  |
|  香港  |  eu\_upstream  |  amqp://user:password@欧洲host  |  on-confirm  |  空  |  1  |
|  |  us\_upstream  |  amqp://user:password@美国host  |  on-confirm  |  空  |  1  |
|  欧洲  |  hk\_upstream  |  amqp://user:password@香港host  |  on-confirm  |  空  |  1  |
|  美国  |  hk\_upstream  |  amqp://user:password@香港host  |  on-confirm  |  空  |  1  |

|  Federation Upstream Set配置  |  |  |
| --- | --- | --- |
|  区域  |  Name  |  命令  |
|  香港  |  eu\_us\_upstream\_set  |  rabbitmqctl set\_parameter federation-upstream-set eu\_us\_upstream\_set '\[{"upstream": "eu\_upstream"}, {"upstream": "us\_upstream"}\]'  |

|  Federation Policy配置  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  区域  |  Name  |  Pattern  |  Apply to  |  Definition  |
|  香港  |  eu\_us\_policy  |  ^federated.\*$  |  exchanges  |  federation-upstream-set:eu\_us\_upstream\_set  |
|  欧洲  |  hk\_policy  |  ^federated.\*$  |  exchanges  |  federation-upstream:hk\_upstream  |
|  美国  |  hk\_policy  |  ^federated.\*$  |  exchanges  |  federation-upstream:hk\_upstream  |

# Dubbo&消息互通与上线节点的关系

注意：因为我们欧洲数据中心、美国数据中心是分开上线的，**代码拉分支时**，要**同时拉欧洲分支、美国分支**，千万不要把代码混在一起。

## 1.欧洲数据中心、美国数据中心未上线

*   Dubbo服务
    

香港数据中心 <=> 香港数据中心

*   RabbitMQ消息
    

香港数据中心 <=> 香港数据中心

## 2.欧洲数据中心上线、美国数据中心未上线

*   Dubbo服务
    

香港数据中心 <=> 香港数据中心（包括香港调用本地的服务、香港调用即将迁移到美国的服务）

欧洲数据中心 <=> 欧洲数据中心

香港数据中心 <=> 欧洲数据中心

*   RabbitMQ消息
    

香港数据中心 <=> 香港数据中心（包括香港本地的消息互通、香港与即将迁移到美国的消息互通）

欧洲数据中心 <=> 欧洲数据中心

香港数据中心 <=> 欧洲数据中心

## 3.欧洲数据中心上线、美国数据中心上线

*   Dubbo服务、RabbitMQ消息
    

香港数据中心 <=> 香港数据中心

欧洲数据中心 <=> 欧洲数据中心

美国数据中心 <=> 美国数据中心

香港数据中心 <=> 欧洲数据中心

香港数据中心 <=> 美国数据中心