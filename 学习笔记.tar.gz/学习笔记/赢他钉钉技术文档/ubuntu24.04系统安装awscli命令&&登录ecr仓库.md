# ubuntu24.04系统安装awscli命令&&登录ecr仓库

参考网址： https://www.liberiangeek.net/2024/04/install-aws-cli-ubuntu-24-04/

删除aws cli 命令，以防有旧版本残留

```shell
file $(which aws)
/usr/local/bin/aws

sudo rm /usr/local/bin/aws
```

#### 1 安装 AWS CLI

1.1 使用 Snap 包管理器以“**经典**”模式在**Ubuntu 24.04上安装 AWS CLI**：

```shell
sudo snap install aws-cli --classic
```

1.2 设置 PATH 环境变量

```plaintext
export PATH=$PATH:/snap/bin
```

1.3 安装docker

```shell
snap install docker
```

#### 2  aws 账号 access\_key && config 汇总

access\_key 和 secret\_key 需要找 运维管理员

2.1 香港生产账号 4902账号  

```shell
aws configure set aws_access_key_id AKIAQYEI44N6JU*****
aws configure set aws_secret_access_key 1U/wenOx20ZatAeIgfdTY07Mu9jUHMRvX****
aws configure set default.region us-east-1
```

2.2 香港生产账号 4064账号  

```plaintext
aws configure
AWS Access Key ID [****************2F4J]: AKIAV5ISR6EZ2OK****
AWS Secret Access Key [****************J0dy]: wHmhW51rXX1zBGHa4DdH8DJ90Tf1****
Default region name [ap-east-1]: ap-east-1
Default output format [json]: json
```
```shell
aws configure set aws_access_key_id AKIAV5ISR6EZ2O****
aws configure set aws_secret_access_key wHmhW51rXX1zBGHa4DdH8DJ90Tf1KTf****
aws configure set default.region ap-east-1
aws ecr get-login-password --region ap-east-1 | docker login --username AWS --password-stdin 406450204979.dkr.ecr.ap-east-1.amazonaws.com
```

2.3 欧洲生产账号 0518  

```plaintext
aws configure set aws_access_key_id "AKIAQYEI44N6JU****
aws configure set aws_secret_access_key "1U/wenOx20ZatAeIgfdTY07Mu9jUHMRv*****
aws configure set default.region "eu-central-1"
```

2.4 美国生产账号 0518  

```plaintext
aws configure set aws_access_key_id "AKIAQYEI44N6JUIW2PI3"
aws configure set aws_secret_access_key "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"
aws configure set default.region "us-east-1"
```

#### 3 登录 aws ecr 仓库

（ECR 仓库在 4064 账号）

3.1 登录 4064账号  access\_key 和 secret\_key 需要找 运维管理员

操作之前记得备份原来的 aws config 文件，在 /root/.aws 目录

```plaintext
aws configure set aws_access_key_id AKIAV5ISR6EZ2O****
aws configure set aws_secret_access_key wHmhW51rXX1zBGHa4DdH8DJ90Tf1KTf****
aws configure set default.region ap-east-1
aws ecr get-login-password --region ap-east-1 | docker login --username AWS --password-stdin 406450204979.dkr.ecr.ap-east-1.amazonaws.com
```

3.2 命令行登录 ECR 仓库

```shell
aws ecr get-login-password --region ap-east-1 | docker login --username AWS --password-stdin 406450204979.dkr.ecr.ap-east-1.amazonaws.com

输出：
WARNING! Your password will be stored unencrypted in /root/snap/docker/2918/.docker/config.json.
Configure a credential helper to remove this warning. See
https://docs.docker.com/engine/reference/commandline/login/#credentials-store

Login Succeeded
```

然后就可以拉取镜像，上传镜像了[PK]