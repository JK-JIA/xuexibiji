```groovy
def findAllViews(name) {                                                                                                                                                                                                                                    
    def jen = Jenkins.getInstance();
    def views = jen.getViews()
    for(def view in views) {
        if(view.contains(jen.getItem(name))== true){
            t = view.getDisplayName()
            if(t != "All") {
                return t
            }
        }
    }
}
 
def getRepoName(s) {
    def agent = "linux"
    def git_repo = "${env.JOB_NAME}".replaceFirst(/^${s}-/,"")
    if (git_repo =~ '.*ios.*') {
       git_repo = "${git_repo}".replaceFirst(/^ios-/,"")
       agent = "ios"
    }
    return [git_repo, agent]
}
 
GITTEAM = findAllViews("${env.JOB_NAME}")
(git_repo, agent) = getRepoName(GITTEAM)
 
pipeline {
    agent {        
      label "linux"
    }

    options {
        timeout(time: 35, unit: 'MINUTES') 
        retry(1) 
        ansiColor('xterm')
        buildDiscarder(logRotator(numToKeepStr: '30', artifactNumToKeepStr: '30'))
    }
         
    parameters {
        choice(name: 'deployenv', choices: ['build:prod','build:eu-prod','build:us-prod','build:pre','build:eu-pre','build:us-pre'], description: '部署环境')
        RESTList(cacheTime: 5, 
           credentialId: '', 
           defaultValue: 'build', 
           mimeType: 'APPLICATION_JSON', 
           name: 'action', 
           restEndpoint: "https://ops-admin.yintaerp.com/ci/parameter/${JOB_NAME}", 
           description: '打包环境的项目，抓紧时间修改',
           valueExpression: '$.*.value')

        gitParameter branchFilter: 'origin/(.*)', defaultValue: 'uat', name: 'branch2', type: 'PT_BRANCH',sortMode: 'DESCENDING_SMART',selectedValue: 'DEFAULT', useRepository: ".${git_repo}.git"

        string(name: "commitId", defaultValue: "", description: "【pre仿真环境不用填写】")
        string(name: "option", defaultValue: "", description: "option to build")
        choice(name: 'action2', choices: ['','sonar-scan','nodeploy'], description: '')
    }


    environment {   // REGISTRY and NAMESPACE can be changed to Artifactory configuration when Artifactory is available in China.
        REGISTRY  = "406450204979.dkr.ecr.ap-east-1.amazonaws.com"
        docker_registry = "ecr:ap-east-1:ecr"
        git_auth = "git"
        git_host = "git@git.yintaerp.com"
        git_repo_ci = "git@git.yintaerp.com:ops/cicd.git"
        branch="master"
        build_commit_id=""
        //共2处需要修改， 1
        // GITTEAM = "orchard"
    }


    stages {

        stage("Prepare") {
            steps {
                //deleteDir()
                //echo "每次构建前清空workspace： Workspace has been cleaned.如需关闭请注释"

                buildName "#${action}-${BUILD_NUMBER}-${branch}"
                wrap([$class: 'BuildUser']) {
                  script{
                    if ("${BUILD_USER}" != "meijinmeng" ) {
                        if (commitId == "" && (deployenv == "build:prod" || deployenv == "build:eu-prod" || deployenv == "build:us-prod")) {
                            error("请提供uat环境打包job中用到的分支commit id")
                        }
                    }
                    if (!params.action) {
                        error("Please choose action!")
                    }

                    echo "#####################################################\n" +
                            "Choosed action: ${action}\n" +
                            "Choosed branch: ${branch}\n" +
                            "#####################################################"
                    //git_repo = "${env.JOB_NAME}".replaceFirst(/^${GITTEAM}-/,"")
                 
                    git_url = "${git_host}:${GITTEAM}/${git_repo}.git"
                    IMAGE_NAME = "${GITTEAM}-${git_repo}".toLowerCase().replaceAll(/_/,"-")
                    app_name = git_repo.replaceAll(/_/,"-").toLowerCase()

                    if(action != "build" && action != "build:sit" && action != "build:uat" && action != "build:prod" && action != "build:pre" ) {
                        app_name = action.replaceAll(/_/,"-")
                        IMAGE_NAME = "${GITTEAM}-${action}".toLowerCase()
                    }

                    dockerfile  = "Dockerfile"
                    //TAG = "${branch}.${BUILD_NUMBER}"    
                    TAG = "1.0.${BUILD_NUMBER}-${branch}"
                    k8sname = "erp-sit"
                    echo "MY BRANCH $branch"
                    //tt = branch.split("/")
                    //MY_BRANCH = tt[-1]
                    MY_BRANCH = branch
                    //tmp = tt[-1].replaceAll(/\.[xX]/,"")
                    //TAG = "${tmp}.${BUILD_NUMBER}"
                    //TAG = "1.0.${BUILD_NUMBER}-${tmp}.1"
                    TAG = "1.0.${BUILD_NUMBER}"
                    if (deployenv == "build:prod") {
                       TAG = "6.0.${BUILD_NUMBER}"
                       k8sname = "erp-prod"
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    }
                    if (deployenv == "build:eu-prod") {
                       TAG = "6.0.${BUILD_NUMBER}"
                       k8sname = "eu-erp-prod"
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    }
                    if (deployenv == "build:us-prod") {
                       TAG = "6.0.${BUILD_NUMBER}"
                       k8sname = "us-erp-prod"
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    }
                    if (deployenv == "build:pre") {
                       TAG = "9.0.${BUILD_NUMBER}"
                       k8sname = "pre"
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    }
                    if (deployenv == "build:eu-pre") {
                       TAG = "9.0.${BUILD_NUMBER}"
                       k8sname = "eu-pre"
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    }
                    if (deployenv == "build:us-pre") {
                       TAG = "9.0.${BUILD_NUMBER}"
                       k8sname = "us-pre"
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    }
                    echo "TAG $TAG ${MY_BRANCH} ${IMAGE_NAME}"                    
                    tmpBranch="tmp-ops-${BUILD_NUMBER}"
                  }
                }
            }
        }

        stage('Clean Workspace') {
            steps {
                cleanWs()  // 清理当前工作空间
            }
        }


        stage("Checkout") {
            steps {
                script {
                     buildName "#${action}-${BUILD_NUMBER}-clone master"


                     checkout([
                         $class           : "GitSCM",
                         userRemoteConfigs: [[credentialsId: "$git_auth", url: "${git_url}"]],
                         branches         : [[name: "master"],[name: "${branch2}"]],
                         extensions: [
                             [$class: 'CloneOption',depth: 0, noTags: false, reference: '', shallow: false, timeout: 10],
                             [$class: 'GitLFSPull'],
                             [$class: 'LocalBranch'],
                             [$class: 'UserIdentity', name: 'prod-ci', email: 'it_support@yintatech.com']
                         ]
                     ])

                     if (branch2 != "master") {
                         sh """
                            git config --global user.name 'prod-ci'
                            git config --global user.email 'it_support@yintatech.com'
                            git checkout master
                         """
                         def exists = fileExists ".git/refs/remotes/origin/${branch2}"
                         if (! exists) {
                            error("未查找到${branch2}分支.")
                         }
                         exists = fileExists ".git/refs/heads/${branch2}"
                         if (exists) {
                            sh "git branch -D ${branch2}"
                         }
                         if(commitId != "") {
                           buildName "#${action}-${BUILD_NUMBER}-${branch2}-${commitId}->master"
                           sh """
                              git checkout -b ${branch2} ${commitId}
                              """
                         } else {
                           buildName "#${action}-${BUILD_NUMBER}-${branch2}->master"
                           sh """
                              git checkout ${branch2}
                              """
                         }
                     }
                }

            }
        }


        stage("build tool sync") {
            steps {
                checkout([
                    $class: 'GitSCM', 
                    branches: [[name: "*/master"]],
                    doGenerateSubmoduleConfigurations: false, 
                    extensions: [[$class: 'CheckoutOption', timeout: 30], [$class: 'CloneOption', depth: 2, noTags: false, reference: '', shallow: true, timeout: 30],[$class: 'RelativeTargetDirectory', relativeTargetDir: 'yt-ci']], 
                    submoduleCfg: [], 
                    userRemoteConfigs: [[credentialsId: "$git_auth", url: "$git_repo_ci"]]
                ])
            } 
        }     

        stage("git merge") {
            steps {
                script {
                    if (deployenv == "build:pre" || deployenv == "build:eu-pre" || deployenv == "build:us-pre") {
                        // 如果 deployenv 是 build:eu-prod 或 build:us-prod，打印信息
                        echo "暂时跳过合并：Skipping git push to master branch for action: ${action} deployenv: ${deployenv}"
                    
                    } else {
                        sh """
                        echo "$deployenv"
                        git checkout master
                        git pull origin master
                        git merge --no-ff ${branch2}

                        """
                    }
                }
                script {
                    build_commit_id = sh(returnStdout: true, script: "git rev-parse HEAD").trim()
                }
            }
        }
  



        stage("Test Audit") {
      	    steps {
            	script {
                    if (deployenv == "build:pre" || deployenv == "build:eu-pre" || deployenv == "build:us-pre") {
                        println("跳过测试平台校验：Skipping Audit for action: ${action} deployenv: ${deployenv}")
                    } else {
            	        def response = httpRequest timeout: 20, url: "https://erp.erp-sit.yintaerp.com/test-platform/api/test_tools/bkci_Callback?Assembly_id=${env.JOB_NAME}&status=3&build_id=${env.BUILD_NUMBER}", wrapAsMultipart: false
            	        def responseJson = readJSON text: response.content
					    println(responseJson)
            	        if (responseJson['code'] == 10005 ) {
						    println("测试平台校验不通过，联系测试组沟通")
                            sh "exit 1"
                        }

                    }
            	}
            }
        }





        stage("build cmd") {
            steps {
                sh """
                    if [ -f "yt-ci/toolbox/${GITTEAM}/${git_repo}/Dockerfile" -o -f "yt-ci/toolbox/${GITTEAM}/${git_repo}/build.sh" ];then
                       cp -rvf yt-ci/toolbox/${GITTEAM}/${git_repo}/* .
                    fi
                    if [ -f "build.sh" ];then
                        sh ./build.sh "$action" "$option" "$deployenv"
                    fi                 
                """  
                script {
                    myDockerfile = fileExists dockerfile
                }
            } 
        }     

        stage("Image Build") {
            when { expression { myDockerfile == true } }

            failFast true
            parallel {
              stage("Image Build - 1") {
                steps {        
                    withDockerRegistry(credentialsId: "${docker_registry}", url: "https://${REGISTRY}/") {
                       sh """
                           if [ -f "${dockerfile}" ];then
                               DOCKER_BUILDKIT=1 docker build --no-cache --pull \
                                   --build-arg action=${action} \
                                   --build-arg option=${option} \
                                   --build-arg deployenv=${deployenv} \
                                   -t ${REGISTRY}/${IMAGE_NAME}:${TAG} \
                                   -f ${dockerfile} .
                           fi
                           
                          """
                    }
                }
              }
            }
        }

        stage("git push") {
            steps {        
                withCredentials([sshUserPrivateKey(credentialsId: "$git_auth", keyFileVariable: 'SSH_KEY')]) {
                    script {
                        // 添加条件判断
                        // 打印变量值以供调试
                        echo "deployenv: ${deployenv}"
                        echo "branch2: ${branch2}"
                        echo "action: ${action}"
                        if (branch2 != "" && !(deployenv in ["build:pre", "build:eu-pre", "build:us-pre"])) {
                            sh """
                                git tag prod-ci-$BUILD_NUMBER
                                git push origin prod-ci-$BUILD_NUMBER
                                git config pull.rebase false
                                git pull origin master
                                git push origin master
                                #git branch -d ${branch2}
                             """
                            if (branch2 != "uat") {
                                sh """
                                    date
                                 """
                            }
                        } else {
                            // 如果 deployenv 是 build:eu-prod 或 build:us-prod，打印信息
                            echo "跳过合并代码原因： branch2:{branch2}   action:${action}   deployenv: ${deployenv}"
                        }
                    }
                }
            }
        }


        
        stage("check repository") {
            steps {
                withCredentials([[
                    $class: 'AmazonWebServicesCredentialsBinding',
                    credentialsId: "ecr",
                    accessKeyVariable: 'AWS_ACCESS_KEY_ID',
                    secretKeyVariable: 'AWS_SECRET_ACCESS_KEY'
                ]]) {
                    sh """
                    docker run --rm  \
                       -e AWS_ACCESS_KEY_ID="\${AWS_ACCESS_KEY_ID}" \
                       -e AWS_SECRET_ACCESS_KEY="\${AWS_SECRET_ACCESS_KEY}" \
                       -e AWS_REGION=ap-east-1  \
                       --entrypoint='' \
                       -v `pwd`:/home/ \
                       amazon/aws-cli  \
                       sh -c "cd /home;sh yt-ci/ecr-mgr.sh ${IMAGE_NAME}"
                    """
                }
            }
        }
        stage("Push image") {   
            when { expression { myDockerfile == true } }           
            steps {
                //    Push images to docker registry currently
                withDockerRegistry(credentialsId: "${docker_registry}", url: "https://${REGISTRY}/") {
                    sh """
                        if [ -f "${dockerfile}" ];then
                            docker push  ${REGISTRY}/${IMAGE_NAME}:${TAG}
                        fi
                       """
                }
            }
        }


        stage("Delete image") {   
            when { expression { myDockerfile == true } }           
            steps {
                withDockerRegistry(credentialsId: "${docker_registry}", url: "https://${REGISTRY}/") {
                    sh """
                        if [ -f "${dockerfile}" ];then
                            docker rmi -f  ${REGISTRY}/${IMAGE_NAME}:${TAG}
                        fi
                       """
                }
            }
        }
        // stage("deploy image") {    
        //     when { expression { myDockerfile ==  true && k8sname != "erp-prod" } }
        //     steps {
        //         sh "kubectl set image deployment/${app_name} ${app_name}=${REGISTRY}/${IMAGE_NAME}:${TAG} -n ${k8sname}"
        //     }
    //    }
    }
    post {
        success {
            sh 'pwd'
            sh 'whoami'
            sh 'id'
            sh 'ls -la'
            //sh 'sudo rm -rf ./*'
            //sh 'bash yt-ci/toolbox/clean.sh'
        }

        //failure {
        //    slackSend (color: '#FF0000', message: "FAILED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]' (${env.BUILD_URL})")
        //}
        always {
            // junit  "service/content/build/reports/*/*/*.html"
            wrap([$class: 'BuildUser']) {
                script {
                    def color = '#00FF00'
                    if(currentBuild.currentResult != "SUCCESS"){
                        color = '#FF0000'
                    }

                    println("build_commit_id: ${build_commit_id}")
                    def response = httpRequest acceptType: 'APPLICATION_JSON', contentType: 'APPLICATION_JSON', httpMode: 'POST', requestBody: """{
                        "name": "${JOB_NAME}",
                        "num": "${BUILD_NUMBER}",
                        "env": "prod",
                        "action": "${action}",
                        "commitId": "${build_commit_id}",
                        "host": "jenkins.yintaerp.com"
                    }""", responseHandle: 'NONE', timeout: null, url: 'https://ops-admin.yintaerp.com/ci/jobInfo', wrapAsMultipart: false
                    println("Status: ${response.status}")
                    println("Response: ${response}")
               }
            }
        }
    }
}


```

修改之后的

```
def findAllViews(name) {                                                                                                                                                                                                                                    
    def jen = Jenkins.getInstance();
    def views = jen.getViews()
    for(def view in views) {
        if(view.contains(jen.getItem(name))== true){
            t = view.getDisplayName()
            if(t != "All") {
                return t
            }
        }
    }
}
 
def getRepoName(s) {
    def agent = "linux"
    def git_repo = "${env.JOB_NAME}".replaceFirst(/^${s}-/,"")
    if (git_repo =~ '.*ios.*') {
       git_repo = "${git_repo}".replaceFirst(/^ios-/,"")
       agent = "ios"
    }
    return [git_repo, agent]
}
 
GITTEAM = findAllViews("${env.JOB_NAME}")
(git_repo, agent) = getRepoName(GITTEAM)
 
pipeline {
    agent {        
      label "linux"
    }

    options {
        timeout(time: 35, unit: 'MINUTES') 
        retry(1) 
        ansiColor('xterm')
        buildDiscarder(logRotator(numToKeepStr: '30', artifactNumToKeepStr: '30'))
    }
         
    parameters {
        choice(name: 'deployenv', choices: ['build:prod','build:eu-prod','build:us-prod'], description: '部署环境')
        RESTList(cacheTime: 5, 
           credentialId: '', 
           defaultValue: 'build', 
           mimeType: 'APPLICATION_JSON', 
           name: 'action', 
           restEndpoint: "https://ops-admin.yintaerp.com/ci/parameter/${JOB_NAME}", 
           description: '打包环境的项目，抓紧时间修改',
           valueExpression: '$.*.value')

        gitParameter branchFilter: 'origin/(.*)', defaultValue: 'uat', name: 'branch2', type: 'PT_BRANCH',sortMode: 'DESCENDING_SMART',selectedValue: 'DEFAULT', useRepository: ".${git_repo}.git"

        string(name: "commitId", defaultValue: "", description: "")
        string(name: "option", defaultValue: "", description: "option to build")
        choice(name: 'action2', choices: ['','sonar-scan','nodeploy'], description: '')
    }


    environment {   // REGISTRY and NAMESPACE can be changed to Artifactory configuration when Artifactory is available in China.
        REGISTRY  = "406450204979.dkr.ecr.ap-east-1.amazonaws.com"
        docker_registry = "ecr:ap-east-1:ecr"
        git_auth = "git"
        git_host = "git@git.yintaerp.com"
        git_repo_ci = "git@git.yintaerp.com:ops/cicd.git"
        branch="master"
        build_commit_id=""
        //共2处需要修改， 1
        // GITTEAM = "orchard"
    }


    stages {

        stage("Prepare") {
            steps {
                //deleteDir()
                //echo "每次构建前清空workspace： Workspace has been cleaned.如需关闭请注释"

                buildName "#${action}-${BUILD_NUMBER}-${branch}"
                wrap([$class: 'BuildUser']) {
                  script{
                    if ("${BUILD_USER}" != "meijinmeng" ) {
                        if (commitId == "") {
                            error("请提供uat环境打包job中用到的分支commit id")
                        }
                    }
                    if (!params.action) {
                        error("Please choose action!")
                    }

                    echo "#####################################################\n" +
                            "Choosed action: ${action}\n" +
                            "Choosed branch: ${branch}\n" +
                            "#####################################################"
                    //git_repo = "${env.JOB_NAME}".replaceFirst(/^${GITTEAM}-/,"")
                 
                    git_url = "${git_host}:${GITTEAM}/${git_repo}.git"
                    IMAGE_NAME = "${GITTEAM}-${git_repo}".toLowerCase().replaceAll(/_/,"-")
                    app_name = git_repo.replaceAll(/_/,"-").toLowerCase()

                    if(action != "build" && action != "build:sit" && action != "build:uat" && action != "build:prod" ) {
                        app_name = action.replaceAll(/_/,"-")
                        IMAGE_NAME = "${GITTEAM}-${action}".toLowerCase()
                    }

                    dockerfile  = "Dockerfile"
                    //TAG = "${branch}.${BUILD_NUMBER}"    
                    TAG = "1.0.${BUILD_NUMBER}-${branch}"
                    k8sname = "erp-sit"
                    echo "MY BRANCH $branch"
                    //tt = branch.split("/")
                    //MY_BRANCH = tt[-1]
                    MY_BRANCH = branch
                    //tmp = tt[-1].replaceAll(/\.[xX]/,"")
                    //TAG = "${tmp}.${BUILD_NUMBER}"
                    //TAG = "1.0.${BUILD_NUMBER}-${tmp}.1"
                    TAG = "1.0.${BUILD_NUMBER}"
                    if (deployenv == "build:prod") {
                       TAG = "6.0.${BUILD_NUMBER}"
                       k8sname = "erp-prod"
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    }
                    if (deployenv == "build:eu-prod") {
                       TAG = "7.0.${BUILD_NUMBER}"
                       k8sname = "eu-erp-prod"
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    }
                    if (deployenv == "build:us-prod") {
                       TAG = "8.0.${BUILD_NUMBER}"
                       k8sname = "us-erp-prod"
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    }
                    echo "TAG $TAG ${MY_BRANCH} ${IMAGE_NAME}"                    
                    tmpBranch="tmp-ops-${BUILD_NUMBER}"
                  }
                }
            }
        }

        stage("Checkout") {
            steps {
                script {
                     buildName "#${action}-${BUILD_NUMBER}-clone master"
                     checkout([
                         $class           : "GitSCM",
                         userRemoteConfigs: [[credentialsId: "$git_auth", url: "${git_url}"]],
                         branches         : [[name: "master"],[name: "${branch2}"]],
                         extensions: [
                             [$class: 'CloneOption',depth: 0, noTags: false, reference: '', shallow: false, timeout: 10],
                             [$class: 'GitLFSPull'],
                             [$class: 'LocalBranch'],
                             [$class: 'UserIdentity', name: 'prod-ci', email: 'it_support@yintatech.com']
                         ]
                     ])

                     if (branch2 != "master") {
                         sh """
                            git config --global user.name 'prod-ci'
                            git config --global user.email 'it_support@yintatech.com'
                            git checkout master
                         """
                         def exists = fileExists ".git/refs/remotes/origin/${branch2}"
                         if (! exists) {
                            error("未查找到${branch2}分支.")
                         }
                         exists = fileExists ".git/refs/heads/${branch2}"
                         if (exists) {
                            sh "git branch -D ${branch2}"
                         }
                         if(commitId != "") {
                           buildName "#${action}-${BUILD_NUMBER}-${branch2}-${commitId}->master"
                           sh """
                              git checkout -b ${branch2} ${commitId}
                              """
                         } else {
                           buildName "#${action}-${BUILD_NUMBER}-${branch2}->master"
                           sh """
                              git checkout ${branch2}
                              """
                         }
                     }
                }

            }
        }


        stage("build tool sync") {
            steps {
                checkout([
                    $class: 'GitSCM', 
                    branches: [[name: "*/master"]],
                    doGenerateSubmoduleConfigurations: false, 
                    extensions: [[$class: 'CheckoutOption', timeout: 30], [$class: 'CloneOption', depth: 2, noTags: false, reference: '', shallow: true, timeout: 30],[$class: 'RelativeTargetDirectory', relativeTargetDir: 'yt-ci']], 
                    submoduleCfg: [], 
                    userRemoteConfigs: [[credentialsId: "$git_auth", url: "$git_repo_ci"]]
                ])
            } 
        }     

        stage("git merge") {
            steps {
                script {
                    if (deployenv == "build:us-prod") {
                        // 如果 deployenv 是 build:eu-prod 或 build:us-prod，打印信息
                        echo "暂时跳过合并：Skipping git push to master branch for deployenv: ${deployenv}"
                    
                    } else {
                        sh """
                        echo "$deployenv"
                        git checkout master
                        git pull origin master
                        git merge --no-ff ${branch2}

                        """
                    }
                }
                script {
                    build_commit_id = sh(returnStdout: true, script: "git rev-parse HEAD").trim()
                }
            }
        }
  


        stage("Test Audit") {
      	    steps {
            	script {
                    //if (audit == "yes") {
            	    def response = httpRequest timeout: 20, url: "https://erp.erp-sit.yintaerp.com/test-platform/api/test_tools/bkci_Callback?Assembly_id=${env.JOB_NAME}&status=3&build_id=${env.BUILD_NUMBER}", wrapAsMultipart: false
            	    def responseJson = readJSON text: response.content
					println(responseJson)
            	    if (responseJson['code'] == 10005 ) {
						println("测试检验不通过，联系测试组沟通")
                        sh "exit 1"
                    }

                    //}
            	}
            }
        }





        stage("build cmd") {
            steps {
                sh """
                    if [ -f "yt-ci/toolbox/${GITTEAM}/${git_repo}/Dockerfile" -o -f "yt-ci/toolbox/${GITTEAM}/${git_repo}/build.sh" ];then
                       cp -rvf yt-ci/toolbox/${GITTEAM}/${git_repo}/* .
                    fi
                    if [ -f "build.sh" ];then
                        sh ./build.sh "$action" "$option" "$deployenv"
                    fi                 
                """  
                script {
                    myDockerfile = fileExists dockerfile
                }
            } 
        }     

        stage("Image Build") {
            when { expression { myDockerfile == true } }

            failFast true
            parallel {
              stage("Image Build - 1") {
                steps {        
                    withDockerRegistry(credentialsId: "${docker_registry}", url: "https://${REGISTRY}/") {
                       sh """
                           if [ -f "${dockerfile}" ];then
                               DOCKER_BUILDKIT=1 docker build --no-cache --pull \
                                   --build-arg action=${action} \
                                   --build-arg option=${option} \
                                   --build-arg deployenv=${deployenv} \
                                   -t ${REGISTRY}/${IMAGE_NAME}:${TAG} \
                                   -f ${dockerfile} .
                           fi
                           
                          """
                    }
                }
              }
            }
        }

        stage("git push") {
            steps {        
                withCredentials([sshUserPrivateKey(credentialsId: "$git_auth", keyFileVariable: 'SSH_KEY')]) {
                    script {
                        // 添加条件判断
                        // 打印变量值以供调试
                        echo "deployenv: ${deployenv}"
                        echo "branch2: ${branch2}"
                        if (branch2 != "" && !(deployenv == "build:us-prod")) {
                            sh """
                                git tag prod-ci-$BUILD_NUMBER
                                git push origin prod-ci-$BUILD_NUMBER
                                git pull origin master
                                git push origin master
                                #git branch -d ${branch2}
                             """
                            if (branch2 != "uat") {
                                sh """
                                    date
                                 """
                            }
                        } else {
                            // 如果 deployenv 是 build:eu-prod 或 build:us-prod，打印信息
                            echo "跳过合并：Skipping git push to master branch for deployenv: ${deployenv}"
                        }
                    }
                }
            }
        }


        
        stage("check repository") {
            steps {
                withCredentials([[
                    $class: 'AmazonWebServicesCredentialsBinding',
                    credentialsId: "ecr",
                    accessKeyVariable: 'AWS_ACCESS_KEY_ID',
                    secretKeyVariable: 'AWS_SECRET_ACCESS_KEY'
                ]]) {
                    sh """
                    docker run --rm  \
                       -e AWS_ACCESS_KEY_ID="\${AWS_ACCESS_KEY_ID}" \
                       -e AWS_SECRET_ACCESS_KEY="\${AWS_SECRET_ACCESS_KEY}" \
                       -e AWS_REGION=ap-east-1  \
                       --entrypoint='' \
                       -v `pwd`:/home/ \
                       amazon/aws-cli  \
                       sh -c "cd /home;sh yt-ci/ecr-mgr.sh ${IMAGE_NAME}"
                    """
                }
            }
        }
        stage("Push image") {   
            when { expression { myDockerfile == true } }           
            steps {
                //    Push images to docker registry currently
                withDockerRegistry(credentialsId: "${docker_registry}", url: "https://${REGISTRY}/") {
                    sh """
                        if [ -f "${dockerfile}" ];then
                            docker push  ${REGISTRY}/${IMAGE_NAME}:${TAG}
                        fi
                       """
                }
            }
        }


        stage("Delete image") {   
            when { expression { myDockerfile == true } }           
            steps {
                withDockerRegistry(credentialsId: "${docker_registry}", url: "https://${REGISTRY}/") {
                    sh """
                        if [ -f "${dockerfile}" ];then
                            docker rmi -f  ${REGISTRY}/${IMAGE_NAME}:${TAG}
                        fi
                       """
                }
            }
        }
        // stage("deploy image") {    
        //     when { expression { myDockerfile ==  true && k8sname != "erp-prod" } }
        //     steps {
        //         sh "kubectl set image deployment/${app_name} ${app_name}=${REGISTRY}/${IMAGE_NAME}:${TAG} -n ${k8sname}"
        //     }
    //    }
    }
    post {
        success {
            sh 'bash yt-ci/toolbox/clean.sh'
        }

        //failure {
        //    slackSend (color: '#FF0000', message: "FAILED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]' (${env.BUILD_URL})")
        //}
        always {
            // junit  "service/content/build/reports/*/*/*.html"
            wrap([$class: 'BuildUser']) {
                script {
                    def color = '#00FF00'
                    if(currentBuild.currentResult != "SUCCESS"){
                        color = '#FF0000'
                    }

                    println("build_commit_id: ${build_commit_id}")
                    def response = httpRequest acceptType: 'APPLICATION_JSON', contentType: 'APPLICATION_JSON', httpMode: 'POST', requestBody: """{
                        "name": "${JOB_NAME}",
                        "num": "${BUILD_NUMBER}",
                        "env": "prod",
                        "action": "${action}",
                        "commitId": "${build_commit_id}",
                        "host": "jenkins.yintaerp.com"
                    }""", responseHandle: 'NONE', timeout: null, url: 'https://ops-admin.yintaerp.com/ci/jobInfo', wrapAsMultipart: false
                    println("Status: ${response.status}")
                    println("Response: ${response}")
               }
            }
        }
    }
}

```

