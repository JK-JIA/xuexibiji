# prod>pre环境数据同步操作手册

生产环境 RDS 实例，使用快照，恢复到pre环境的 RDS 实例 (文档后面统一叫：快照实例)

步骤： nacos文件修改 pre\_test 时间戳 >> 生产环境创建快照  >>  快照恢复为RDS集群  >> 等待快照实列集群启动  >>  手动/脚本同步中间件pre数据  >>  手动/脚本同步数据量小的pre数据表/库  >>  修改Route53 映射为快照实例的地址   >>  重启nginx/haproxy服务器  >>  创建dms数据同步任务 >>  关闭需要同步数据的服务 >> 清空需要同步的表/库数据  >> 开启dms任务

### 预备操作、nacos文件修改 pre\_test 时间戳

打开 pre 环境三个区域的 nacos 界面，在 pre\_test 文件新增时间戳，后面方便同步数据后验证

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/75903685-66bc-4074-8518-25b03d9b7e65.png)

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/18ec33ee-a6cb-40bb-849f-fdb28deeb4ff.png)

### 一、生产环境创建快照，快照恢复为RDS集群

1.  生产RDS数据库创建快照，选择集群快照，快照命名为 生产数据库名称-时间戳；  
    例如：[euprod-mysql8-cluster-202505121055](https://eu-central-1.console.aws.amazon.com/rds/home?region=eu-central-1#db-snapshot:engine=aurora-mysql;id=euprod-mysql8-cluster-202505121055)
    
2.  选择 创建的快照>恢复快照>数据库命名为，环境-区域-数据库名称时间；(bms数据库在4064账户，快照要共享到 4902账户使用)  
    例如： pre-hk-erp-mysql20250317    pre-us-erp-mysql20250317
    
3.  恢复快照为RDS集群，详细配置选项  
    

```plaintext
数据库引擎：默认
数据库版本：默认最新，这里为：aurora.mysql。3.05.2
数据库实例标识符：pre-eu-mysql-20250215
配置选项：默认，标准版
实例配置：db.r5.large
VPC：PRE环境的VPC
子网：PRE环境的子网
公开访问：默认，否
VPC安全组：UAT-eu-db-net，UAT-eu-lan，default
可用区：默认，随机选择
证书颁发机构：默认，rds-ca-rsa2048-g1
其他配置
  数据库端口：5036
数据库身份验证：
  全部不勾选
加密：
  勾选默认 kms 加密，创建快照会加密
其他配置
  数据库集群参数组：pre 的参数组
  数据库参数组： pre 的参数组
日志导出：
  全部勾选
维护
  自动升级最新版本，取消勾选
```

日志勾选上慢查询日志：

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/fe729096-e477-4f10-9844-7bbec2acf726.png)

4.加密快照共享到4902账号：

手动在只读库创建快照

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/6dfbb4c7-c984-4e98-8c28-dfb106740833.png)

用共享密钥复制快照，复制后的快照再共享给4902账号

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/2802a74d-91d0-4ea9-836a-15aeb84c0194.png)

共享快照到4902账号

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/c76fcbc9-f64f-42ef-acf4-14e041772b3b.png)

### 二、手动/脚本同步中间件pre数据

同步 pre环境 nacos ，xxl-job-admin 的数据到 快照实例；

因为快照还原的快照实例是生产数据，nacos 和 xxl-job 不能用生产数据；

1.  使用 navicat 工具，清空 快照实例 nacos 和 xxl-job 所有表 
    
2.  使用 navicat 工具，同步 pre 数据库 nacos ，xxl-job 表数据
    

不需要同步的表和库详细文档如下：

[请至钉钉文档查看附件《pre数据同步-不能同步的库记录表》](https://alidocs.dingtalk.com/i/nodes/lyQod3RxJK3PoxbPHj94Ra6GJkb4Mw9r?doc_type=wiki_doc&iframeQuery=anchorId%3DX02m88ja8hhw6dq6kl128k)

香港举例：

香港的nacos 在 tms 数据库的 nacos\_v2 ，新建 navicat 连接为 快照实例，清空 nacos\_v2 数据库，不需要删除，因为 nacos 的表结构都是一样的；注意香港是 nacos\_v2

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/ca5a8600-4571-4219-84f7-50ea3df9971e.png)![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/728d1922-22bc-4b52-86af-a55ab59ccad6.png)

清空后，同步pre数据到 快照实例；因为Route53映射还未改变，现在使用 Route53 连接地址的还是原来的 Pre 数据库，找到打开选择数据传输，选择 nacos\_v2 库，选择所有表同步；

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/6ba43638-8a08-4bb5-a175-53a5f703a776.png)![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/f03fb308-012d-4e42-9da9-b7f087f01f88.png)![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/efba8a77-c86d-4f81-bc05-907f318eaa1c.png)

同步完成后，验证 nacos，xxl-job 数据是否还原

运维操作：修改nacos，xxl-job 链接的数据库链接 /root/yaml/nacos，/root/yaml/xxl-job-admin

cd  /root/yaml/nacos，修改配置文件数据库连接为 快照实例

```yaml
apiVersion: v1
data:
  mysql.db.name: eu_nacos
  #原来为：pre-eu-mysql.pre-eu-dns
  #修改为：pre-hk-tms-mysql20250317-cluster.cluster-c2bihysdu6ok.ap-east-1.rds.amazonaws.com
  mysql.host: pre-eu-mysql.pre-eu-dns
  mysql.password: SmwbGmaXZBK4
  mysql.port: "5036"
  mysql.user: eu_nacos
```

cd  /root/yaml/xxl-job-admin，修改配置文件数据库连接为 快照实例

```yaml
#原来为： pre-eu-mysql.pre-eu-dns:5036
#修改为： pre-hk-tms-mysql20250317-cluster.cluster-c2bihysdu6ok.ap-east-1.rds.amazonaws.com
    spring.datasource.url=jdbc:mysql://pre-eu-mysql.pre-eu-dns:5036/eu_xxljob?useUnicode=true&characterEncoding=UTF-8&autoReconnect=true&serverTimezone=Asia/Shanghai
    spring.datasource.username=eu_xxljob
    spring.datasource.password=ETZFOIZ6Z0Yy
    spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
```

重启 nacos 和 xxl\_job 验证数据

```yaml
kubectl delete -f nacos.yaml
kubectl delete -f xxl-job.yaml

kubectl apply -f nacos.yaml
kubectl apply -f xxl-job.yaml
```

打开 nacos 和 xxl-job 页面查看数据是否有问题，

nacos 验证： 

查看文件 pre\_test 是否为最新配置，每次同步之前在此文件添加时间戳记录同步时间

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/75903685-66bc-4074-8518-25b03d9b7e65.png)

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/18ec33ee-a6cb-40bb-849f-fdb28deeb4ff.png)

xxl-job 查看任务调度日志，有没有最新的日志

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/5d135b09-a6c5-4dc7-87ca-3438b01cfef2.png)

验证数据同步没问题后，nacos 数据库需要开启自增id，不然修改文件会报错

```shell
报错：
caused: PreparedStatementCallback; SQL [INSERT INTO his_config_info(id, data_id, group_id, tenant_id, app_name, content, md5, src_ip, src_user, gmt_modified, op_type, encrypted_data_key) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)]; Field 'nid' doesn't have a default value; nested exception is java.sql.SQLException: Field 'nid' doesn't have a default value;caused: Field 'nid' doesn't have a default value;
```

nacos 数据库执行sql 语句，开启自增ID

```plaintext
ALTER TABLE his_config_info MODIFY COLUMN  `nid` bigint unsigned NOT NULL AUTO_INCREMENT;
```

### 三、手动/脚本同步数据量小的pre数据表/库

不需要同步的表和库详细文档如下：

[请至钉钉文档查看附件《pre数据同步-不能同步的库记录表》](https://alidocs.dingtalk.com/i/nodes/lyQod3RxJK3PoxbPHj94Ra6GJkb4Mw9r?doc_type=wiki_doc&iframeQuery=anchorId%3DX02m8e4ziylun3uocrg2vb)

例如：

香港  ydp\_system库 sys\_datasource表 ，一张表，使用 navicate 手动同步数据即可

欧洲  yt\_business库  yt\_pull\_order\_time\_config，yt\_logistics\_service\_manager  表，手动同步数据

具体操作和第二步，同步Nacos 步骤一样；

### 四、修改Route53 映射为快照实例的地址

香港区域演示：

打开 route53 界面，找到对应的映射规则，点击修改，修改为当前的 快照实例地址；

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/ff857fb8-d442-42d3-be0f-ba9cedb78ec7.png)

ro 是只读库，也需要修改为 快照实例地址，香港区域不需要动名称为 eu，us 的映射；

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/76f4ad80-0c65-46ce-8eca-03bcdd6e0893.png)

### 五、 重启nginx/haproxy服务器

修改过Route53 映射后，需要重启 nginx 服务器，和阿里云的 haproxy 服务器，刷新缓存；不然使用阿里云 dms 连接数据库查询会报错，链路故障；

重启 haproxy 服务器，执行命令

systemctl restart haproxy.service 

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/ABmOoZQNj1mzqawZ/img/373a2e24-2c86-4dd6-9ce1-dc0ebd33a862.png)

重启 pre环境三个区域的 nginx 服务器，执行命令

```shell
/usr/local/openresty/nginx/sbin/nginx -t
/usr/local/openresty/nginx/sbin/nginx -s reload

./rsync2nginx.sh
```

### 六、 创建dms数据同步任务

任务量比较大的库，需要使用dms任务同步数据，dms任务都创建好了；每次使用之前需要检查一下，源和目标的地址是否正确

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/f2f90f4b-92d5-4731-81fb-3e10b59ae28a.png)

找到需要的 点进去，查看源和目标地址是否为 pre数据库地址；

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/17f7d023-abf9-4e85-9e90-49eeab89db24.png)

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/df9a9f35-e8d6-443b-8d1f-bd98c7badae1.png)

确认无误后，再确认一下dms任务同步的表映射是否满足需求，没有问题后关闭涉及此库/表写数据的服务

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/0208c636-5fbc-4d40-9fd4-3c83c078513f.png)

### 七、关闭需要同步数据的服务

例如，同步 o2oa 服务时，先把 o2oa 服务停掉；避免一边写数据，一边同步数据，出现未知问题；

使用 kuboard 缩减副本数为 0

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/be89eb37-5495-4cec-8c8f-bea7631dc3d7.png)

### 八、清空需要同步的表/库数据

因为 aws 的 dms 任务同步数据，需要保证两端表结构完全一致，不然会出现不确定的报错，导致同步失败

所以在开始 dms 任务同步之前，稳妥的做法是重新导入一边表结构；

举例 o2oa 库：

打开 navicat 删除所有表 >> 使用阿里云 dms 平台导出表结构（(不能使用 Navicat 工具同步表结构，会有未知问题)）

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/fe494c13-5026-491f-b885-e1ac1370d55c.png)

阿里云dms平台导出建表语句，导出的是sql文件，小的话可以直接复制，到 navicat 执行；大的话需要传输到 sql-windows机器执行

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/119eb4bb-b6ba-413c-9c78-0a5abd15a41e.png)

执行 sql，创建表和表结构

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/de734eb0-9eaf-414c-bc34-c27cb1b0903a.png)

表全都创建完成后，再开启 dms 任务：

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/68eed215-b4f0-42f4-a4a7-162f94361548.png)

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/4j6OJMZxZodeq3p8/img/f2f90f4b-92d5-4731-81fb-3e10b59ae28a.png)

### 九、验证方法 & 注意事项

0):  数据实例快照还原顺序：先恢复美国&欧洲  erp-mysql > tms-wms  

1):  o2oa 库

注意：同步需要开启o2oa库需要开启blob 大字段模式 

验证脚本：在dms 生产环境和pre环境执行对比差异 

SELECT \* FROM \`ptl\_page\`  where xid='8f1ef51d-831e-477a-99d4-0cd19a30a0f3'

 LIMIT 20;

### 十、各组同步后需要执行的脚本

|  **区域**  |  **实例名**  |  **库名**  |  **脚本链接**  |
| --- | --- | --- | --- |
|   |   |   |   |
|   |   |   |   |

### 备注：中间件数据同步脚本，准备中；