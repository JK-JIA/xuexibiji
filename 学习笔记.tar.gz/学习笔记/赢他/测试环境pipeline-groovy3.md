```groovy
//定义一个名为findAllViews的函数，（name）为接受参数
//显示job任务在哪个 view 视图组中
def findAllViews(name) {
    //获取 Jenkins 实例。
    def jen = Jenkins.getInstance();
    //获取 Jenkins 中所有的视图
    def views = jen.getViews()
    //遍历所有视图
    for(def view in views) {
        //检查视图是否包含某个项（job）
        //jen.getItem(name) 获取指定名称的 Job，然后 view.contains(jen.getItem(name)) 检查该 Job 是否在视图中
        if(view.contains(jen.getItem(name))== true){
            //获取视图的显示名称
            t = view.getDisplayName()
            //如果视图的显示名称不是 "All"，则返回视图名称
            if(t != "All") {
                return t
            }
        }
    }
}
//定义一个名为findAllViews的函数，（s）为接受参数
// 去掉job_name前缀，提取仓库名称，并根据仓库名称决定agent=（ios 或 linux）。
def getRepoName(s) {
    //默认设置代理为 linux
    def agent = "linux"
    //从环境变量 JOB_NAME 中提取仓库名称。
    def git_repo = "${env.JOB_NAME}".replaceFirst(/^${s}-/,"")
    //如果仓库名称包含 ios，则处理仓库名称并将代理设置为 ios。
    if (git_repo =~ '.*ios.*') {
       git_repo = "${git_repo}".replaceFirst(/^ios-/,"")
       agent = "ios"
    } 
    //返回处理后的仓库名称和代理类型
    return [git_repo, agent]
}

//调用findAllViews函数，返回job_name所在view视图组
GITTEAM = findAllViews("${env.JOB_NAME}")
//调用getRepoName函数，赋值git_repo和agent(git仓库名称和agnet标签)
(git_repo, agent) = getRepoName(GITTEAM)

dirfix=""
if(agent == "ios") {
  dirfix="-ios"
}

//定义了一个 Jenkins Pipeline。
pipeline {
    agent {
    //指定构建的代理标签，使用之前 getRepoName 函数返回的 agent。
      label agent
    }
   //配置 Pipeline 的全局选项。
    options {
        // 构建超时时间设置为 35 分钟
        timeout(time: 35, unit: 'MINUTES') 
        // 如果构建失败，重新尝试一次
        retry(1) 
        //启用 ANSI 颜色支持，用于彩色输出
        ansiColor('xterm')
        //配置构建日志和构件的保留策略，保留最近 30 个构建和构件。
        buildDiscarder(logRotator(numToKeepStr: '30', artifactNumToKeepStr: '30'))
    }
    //定义可选参数列表     
    parameters {
        //选择部署环境，name参数的名称，choices可选项列表，description参数的描述
        choice(name: 'deployenv', choices: ['build:sit','build:uat','build:uat2','build:uat3','build:dev', 'build:prod','build:sit2','build:sit3','build:sit4','build:sit5','build:sit6','build:sit7','build:sit8','build:sit9'], description: '部署环境')
        ////缓存时间5分钟
        RESTList(cacheTime: 5, 
           //凭证ID为空
           credentialId: '', 
           //默认值为 build
           defaultValue: 'build', 
           mimeType: 'APPLICATION_JSON', 
           //参数的名称
           name: 'action', 
           //REST API 端点 URL，指定了获取参数值的 API 地址
           restEndpoint: "https://ops-admin.yintaerp.com/ci/parameter/${JOB_NAME}", 
           //description参数的描述
           description: '打包环境的项目，抓紧时间修改',
           valueExpression: '$.*.value')
        choice(name: "audit", choices: ["no","yes"], description: "sit选择yes审核并且审核通过才能发uat")
        string(name: "ytAppVersion", defaultValue: "", description: "灰度发版,根据header头路由")
        //参数的名称branch，branchFilter分支的过滤规则'origin/(.*)'表示匹配 origin 远程仓库下的所有分支。type: 参数类型，这里是 PT_BRANCH，表示选择 Git 分支。sortMode: 排序模式，这里是 'DESCENDING_SMART'，表示按降序排序。useRepository: 用于指定仓库的正则表达式，这里是 '.*${git_repo}.git'  ${git_repo} 调用上面的 getRepoName(GITTEAM) 返回的 git_repo值
        gitParameter branchFilter: 'origin/(.*)', defaultValue: 'master', name: 'branch', description: "主分支(uat环境强制为master)", type: 'PT_BRANCH',sortMode: 'DESCENDING_SMART',selectedValue: 'DEFAULT', useRepository: ".*${git_repo}.git"
        gitParameter branchFilter: 'origin/(.*)', defaultValue: '', name: 'branch2', description: "合并分支:合并到branch所选分支", type: 'PT_BRANCH',sortMode: 'DESCENDING_SMART',selectedValue: 'DEFAULT', useRepository: ".*${git_repo}.git"
        string(name: "option", defaultValue: "", description: "option to build")
        choice(name: 'action2', choices: ['','sonar-scan','nodeploy'], description: '')
    }

    //定义环境变量  
    environment {   // REGISTRY and NAMESPACE can be changed to Artifactory configuration when Artifactory is available in China.
        // 定义 DockerHub 镜像仓库的地址
        REGISTRY  = "devhub.yintaerp.com"
        // 定义 Docker 注册表的认证信息,当前值为 "dockerauth"
        docker_registry = "dockerauth"
        //定义 Docker 镜像的命名空间。
        NAMESPACE = "yintatech"
        //定义 Git 仓库的认证信息,当前值为 "jenkins"，表示使用 Jenkins 的凭据进行 Git 操作。
        git_auth = "jenkins"
        //用于存储构建的提交 ID。
        build_commit_id = ""
        //共2处需要修改， 1
        // GITTEAM = "orchard"
    }
    //自动触发构建，使用 GenericTrigger 插件来处理 Webhook 触发事件，提取 JSON 负载中的信息，并根据正则表达式过滤条件决定是否触发构建
    triggers {
      GenericTrigger(
       genericVariables: [
        [key: 'branch', value: '$.ref'],
        [key: 'team', value: '$.repository.owner.username'],
        [key: 'repository', value: '$.repository.name'],
        [key: 'username', value: '$.pusher.login']
       ],
    
       causeString: 'Triggered on $username',
    
       token: 'meytasl2828',
    
       printContributedVariables: false,
       printPostContent: false,
    
       silentResponse: false,
    
       regexpFilterText: '${team}-${repository}',
       //共2处需要修改， 2
       regexpFilterExpression: '^' + GITTEAM + '-' +  git_repo + '$'
      )
    }
    
    stages {
        //定义初始环境
        stage("Prepare") {
            steps {
                //部署环境名+部署服务名+构建任务ID+分支名
                buildName "#${deployenv}-${action}-${BUILD_NUMBER}-${branch}"
                //如果action为空，返回报错
                script {
                    if (!params.action) {
                        error("Please choose action!")
                    }
    
                    echo "#####################################################\n" +
                            "Choosed action: ${action}\n" +
                            "Choosed branch: ${branch}\n" +
                            "#####################################################"
                    //git_repo = "${env.JOB_NAME}".replaceFirst(/^${GITTEAM}-/,"")
                    git_url = "git@git.yintaerp.com:${GITTEAM}/${git_repo}.git"
    		        //将 git_repo 的下划线替换为短横线。
                    app_name = git_repo.replaceAll(/_/,"-")
                    //根据 GITTEAM 和 git_repo 构建的 Docker 镜像名称，并将所有字符转为小写
                    IMAGE_NAME = "${GITTEAM}-${git_repo}".toLowerCase().replaceAll(/_/,"-")                  
                    //环境变量
                    dockerfile  = "Dockerfile"
                    //TAG = "${branch}.${BUILD_NUMBER}" 
                    //默认为1.0+构建任务版本号
                    TAG = "1.0.${BUILD_NUMBER}-${branch}"
    
                    //if(action != "build" && action != "build:sit" && action != "build:uat") {
                    //如果action不包含build，自定义变量
                    if ( ! action.contains("build")) {
                        app_name = action.replaceAll(/_/,"-")
                        IMAGE_NAME = "${GITTEAM}-${action}".toLowerCase()
                    }
                    //定义环境变量
                    k8sname = "erp-sit"
                    build_commit_id = ""
    
                    echo "MY BRANCH $branch"
                    //tt = branch.split("/")
                    //MY_BRANCH = tt[-1]
                    MY_BRANCH = branch
                    //tmp = tt[-1].replaceAll(/\.[xX]/,"")
                    //TAG = "${tmp}.${BUILD_NUMBER}"
                    //TAG = "1.0.${BUILD_NUMBER}-${tmp}.1"
                    
                    //以下都没用
                    def n = action =~ /[^\w]*(\d+)/ 
                    nnn = n.find()?n.group():""
                    nnnn = ""
                    if( nnn == "") {
                      nnnn = ""
                    } else {
                      nnnn = "-${nnn}"
                    }
                    TAG = "1.0.${BUILD_NUMBER}"
                    if (deployenv == "cache") {
                       TAG = "latest"
                       IMAGE_NAME = "${IMAGE_NAME}-base-image"
                       dockerfile = "baseimage/Dockerfile"
                    }
                    if (deployenv == "build:sit2") {
                       TAG = "1.2.${BUILD_NUMBER}"
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    }
                    if (deployenv == "build:sit3") {
                       TAG = "1.3.${BUILD_NUMBER}"
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    }
                    if (deployenv == "build:sit4") {
                       TAG = "1.4.${BUILD_NUMBER}"
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    }
                    if (deployenv == "build:sit5") {
                       TAG = "1.5.${BUILD_NUMBER}"
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    }
                    if (deployenv == "build:sit6") {
                       TAG = "1.6.${BUILD_NUMBER}"
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    }
                    if (deployenv == "build:sit7") {
                       TAG = "1.7.${BUILD_NUMBER}"
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    }
                    if (deployenv == "build:sit8") {
                       TAG = "1.8.${BUILD_NUMBER}"
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    }
                    if (deployenv == "build:sit9") {
                       TAG = "1.9.${BUILD_NUMBER}"
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    }
                    if (deployenv == "build:dev") {
                       k8sname = "dev"
                       TAG = "3.0.${BUILD_NUMBER}"
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    }
                    if (deployenv == "build:uat") {
                       k8sname = "erp-uat"
                       TAG = "5.0.${BUILD_NUMBER}"
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    }
                    if (deployenv == "build:prod") {
                       TAG = "6.0.${BUILD_NUMBER}"
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    }
                    if (deployenv == "build88:prod") {
                       TAG = "8.0.${BUILD_NUMBER}"                                                                                                                                                                                
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    } 
    
                    if (ytAppVersion != "") {
                       TAG = TAG.replaceAll(/\.0\./,".111.")
                       //IMAGE_NAME = "${IMAGE_NAME}-prod"
                    } 
                    echo "TAG $TAG ${MY_BRANCH} ${IMAGE_NAME}"                    
                }
            }
        }
       //负责从 Git 仓库中检出代码。它处理了不同的分支逻辑、合并分支和认证
        stage("Checkout") {
            steps {
                //git_auth上面定义了为 jenkins
                //credentialsId: 凭据的 ID。在您的示例中，${git_auth} 变量存储了凭据的 ID。
				//keyFileVariable: 定义环境变量名identity，用于存储 SSH 私钥文件路径
                withCredentials([sshUserPrivateKey(credentialsId: "${git_auth}",keyFileVariable: 'identity')]) {
                    script {
                         //如果环境为uat环境，必须提交合并分支
                         if (deployenv == "build:uat") {
    						 branch="master"	
                             if(branch2 == "" ){
                                error("请在branch2提供合并分支.")
                             }
    					 } 
    					 //设置buildname=环境名字+部署服务名+构建任务ID+主分支名
                         buildName "#${deployenv}-${action}-${BUILD_NUMBER}-${branch}"


                         checkout([
                             $class           : "GitSCM",
                             //指定 Git 仓库 URL 和凭据。
                             userRemoteConfigs: [[credentialsId: "$git_auth", url: "${git_url}"]],
                             //指定要检出的分支
                             branches         : [[name: "${branch}"]],
                             //指定一些检出选项
                             extensions: [
                                 //克隆选项，深度为 0，表示完全克隆。
                                 [$class: 'CloneOption',depth: 0, noTags: false, reference: '', shallow: false, timeout: 10],
                                 //启用 Git LFS 支持
                                 [$class: 'GitLFSPull'],
                                 //使用本地分支
                                 [$class: 'LocalBranch'],
                                 //设置用户身份，名称为 prod-ci，电子邮件为 ci@work
                                 [$class: 'UserIdentity', name: 'prod-ci', email: 'ci@work']
                             ]
                         ])


						 //如果 branch2 不为空且不等于 branch
                         if (branch2 != "" && branch2 != branch) {
                             //sh """
                             //   git config --global user.name 'prod-ci'
                             //   git config --global user.email 'ci@work'
                             //"""
                             
                             //检查 .git/refs/heads/${branch2} 文件是否存在
                             def exists = fileExists ".git/refs/heads/${branch2}"
                             //如果存在，删除本地分支 branch2
                             if (exists) {
                                sh "git branch -D ${branch2}"
                             }
                             ////更新构建名称为:环境名字+部署服务名+构建任务ID+主分支名->master
                             buildName "#${deployenv}-${action}-${BUILD_NUMBER}-${branch2}->master"
                             //检出 branch2 分支
                             sh """
                                git checkout ${branch2}
                                """
                             //获取 branch2 分支的提交 ID，并存储在 build_commit_id 变量中
                             build_commit_id = sh(returnStdout: true, script: "git rev-parse ${branch2}").trim()
                             println("build-commit-id $branch2 $build_commit_id")
                         }
                    }
                }
            }
        }
        ////如果 branch2 不为空且不等于 branch，执行合并分支
        stage("git merge") {
            when { expression { branch2 != "" && branch != branch2 } }
            steps {
                script {
                       sh """
                          git checkout ${branch}
                          git merge --no-ff ${branch2}
                          """
                }
            } 
        }    
    
        stage("sync tool") {
          steps {
                checkout([
                    $class: 'GitSCM', 
                    branches: [[name: "*/master"]],
                    doGenerateSubmoduleConfigurations: false, 
                    extensions: [
                        [$class: 'CheckoutOption', timeout: 30], 
                        [$class: 'CloneOption', depth: 2, noTags: false, reference: '', shallow: true, timeout: 30],
                        [$class: 'RelativeTargetDirectory', relativeTargetDir: 'toolbox']], 
                    submoduleCfg: [], 
                    userRemoteConfigs: [[credentialsId: 'jenkins', url: 'git@git.yintaerp.com:ops/toolbox.git']]
                ])
                checkout([
                    $class: 'GitSCM', 
                    branches: [[name: "*/master"]],
                    doGenerateSubmoduleConfigurations: false, 
                    extensions: [
                        [$class: 'CheckoutOption', timeout: 30], 
                        [$class: 'CloneOption', depth: 2, noTags: false, reference: '', shallow: true, timeout: 30],
                        [$class: 'RelativeTargetDirectory', relativeTargetDir: 'appconfig']], 
                    submoduleCfg: [], 
                    userRemoteConfigs: [[credentialsId: 'jenkins', url: 'git@git.yintaerp.com:ops/appconfig.git']]
                ])
            }
        }
        // 自动测试，向 http://test-platform.sit.yintaerp.com/api/test_tools/bkci_Callback 发送请求，查询测试审核状态，如果响应中的 code 值为 10005，表示测试审核未通过，打印提示信息并终止构建
        stage("test audit") {
      	    steps {
            	script {
                    //if (audit == "yes") {
            	    def response = httpRequest timeout: 20, url: "http://test-platform.sit.yintaerp.com/api/test_tools/bkci_Callback?Assembly_id=${env.JOB_NAME}&status=3&build_id=${env.BUILD_NUMBER}", wrapAsMultipart: false
            	    def responseJson = readJSON text: response.content
    				println(responseJson)
            	    if (responseJson['code'] == 10005 ) {
    					println("测试检验不通过，联系测试沟通")
                        sh "exit 1"
                    }
    
                    //}
            	}
            }
        }

        
        stage("build cmd") {
            steps {
                sh """
                //检查目录 toolbox/${GITTEAM}/${git_repo}${dirfix} 下是否存在 Dockerfile 或 build.sh 文件,存在则 把所有文件复制到当前目录。
                    if [ -f "toolbox/${GITTEAM}/${git_repo}${dirfix}/Dockerfile" -o -f "toolbox/${GITTEAM}/${git_repo}${dirfix}/build.sh" ];then
                       cp -rvf toolbox/${GITTEAM}/${git_repo}${dirfix}/* .
                    fi
                    //检查当前目录下是否存在 build.sh 文件，
                    存在则执行该脚本，并传递两个参数：$action 和 $option
                    
                    if [ -f "build.sh" ];then
                        sh ./build.sh "$action" "$option"
                    fi                 
                """  
                script {
                    myDockerfile = fileExists dockerfile
                }
            } 
        }     


        stage("Image Build") {
            //当Dockerfile文件存在时执行
            when { expression { myDockerfile == true } }
            //如果有并行的子阶段失败，整个阶段会立即失败，不会继续执行其他子阶段。
            failFast true
            //该阶段使用并行执行的方式，可以扩展多个子阶段
            parallel {
              stage("Image Build - 1") {
                steps {        
                    //配置 Docker registry 凭证，以便进行 Docker 操作
                    withDockerRegistry(credentialsId: "${docker_registry}", url: "https://${REGISTRY}/") {
                       sh """
                           //构建镜像
                           if [ -f "${dockerfile}" ];then
                               DOCKER_BUILDKIT=1 docker build --no-cache --pull \
                                   --shm-size 200m \
                                   --build-arg action=${action} \
                                   --build-arg option=${option} \
                                   --build-arg deployenv=${deployenv} \
                                   --build-arg ytAppVersion=${ytAppVersion} \
                                   -t ${REGISTRY}/${NAMESPACE}/${IMAGE_NAME}:${TAG} \
                                   -f ${dockerfile} .
                           fi
                           
                          """
                    }
                }
              }
            }
        }
        // 上传上一步构建好的镜像到dockerhub
        stage("Push image") {   
            when { expression { myDockerfile == true } }           
            steps {
                //    Push images to docker registry currently
                withDockerRegistry(credentialsId: "${docker_registry}", url: "https://${REGISTRY}/") {
                    sh """
                        if [ -f "${dockerfile}" ];then
                            docker push  ${REGISTRY}/${NAMESPACE}/${IMAGE_NAME}:${TAG}
                        fi
                       """
                }
            }
        }
        //删除本地镜像缓存
        stage("Delete image") {   
            when { expression { myDockerfile == true } }           
            steps {
                //    Push images to docker registry currently
                withDockerRegistry(credentialsId: "${docker_registry}", url: "https://${REGISTRY}/") {
                    sh """
                        if [ -f "${dockerfile}" ];then
                            docker rmi -f ${REGISTRY}/${NAMESPACE}/${IMAGE_NAME}:${TAG}
                        fi
                       """
                }
            }
        }
        
        stage("sonar scan") {
             //只有在 action2 参数等于 "sonar-scan" 时才会执行脚本
             when { expression { "${action2}" == "sonar-scan" } }
            //脚本用于执行 SonarQube 扫描
             steps {        
               sh "sh ./toolbox/sonar-scan.sh" 
             }
        }        
        stage("deploy image") {
            when { expression { myDockerfile ==  true && k8sname != "erp-prod" && action2 != "nodeploy" } }
            steps {
              
              script {
                def response = httpRequest acceptType: 'APPLICATION_JSON', contentType: 'APPLICATION_JSON', httpMode: 'POST', requestBody: """{
                    "image": "${REGISTRY}/${NAMESPACE}/${IMAGE_NAME}:${TAG}",
                    "ytAppVersion": "${ytAppVersion}"
                }""", responseHandle: 'NONE', timeout: null, url: 'http://192.168.3.204:18888/api/ci', wrapAsMultipart: false
                println("Status: ${response.status}")
                println("Response: ${response}")
              }
              //sh "kubectl set image deployment/${app_name}${nnnn} ${app_name}${nnnn}=${REGISTRY}/${NAMESPACE}/${IMAGE_NAME}:${TAG} -n ${k8sname}"
              //sh "kubectl set image deployment/${app_name}  ${app_name}=${REGISTRY}/${NAMESPACE}/${IMAGE_NAME}:${TAG} -n ${k8sname}"
    
              //sh "flux reconcile image repository ${app_name} -n flux-${k8sname}"
              //sh "flux reconcile image update ${app_name} -n flux-${k8sname}"                                                          
              //sh "flux reconcile helmrelease ${app_name} -n flux-${k8sname}"
            }
       }
    }
    post {
        success {
            sh 'bash toolbox/clean.sh'
        }
    
        //failure {
        //    slackSend (color: '#FF0000', message: "FAILED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]' (${env.BUILD_URL})")
        //}
        always {
            // junit  "service/content/build/reports/*/*/*.html"
            script {
                def color = '#00FF00'
                if(currentBuild.currentResult != "SUCCESS"){
                    color = '#FF0000'
                }
                if (deployenv == "build:uat") { 
                  println("build-commit-id $branch2 $build_commit_id")
                  def response = httpRequest acceptType: 'APPLICATION_JSON', contentType: 'APPLICATION_JSON', httpMode: 'POST', requestBody: """{
                      "name": "${JOB_NAME}",
                      "num": "${BUILD_NUMBER}",
                      "env": "uat",
                      "action": "${action}",
                      "commitId": "${build_commit_id}",
                      "host": "newjenkins.yintaerp.com"
                  }""", responseHandle: 'NONE', timeout: null, url: 'https://ops-admin.yintaerp.com/ci/jobInfo', wrapAsMultipart: false
                  println("Status: ${response.status}")
                  println("Response: ${response}")
                }
            }
        }
    }

}
```

