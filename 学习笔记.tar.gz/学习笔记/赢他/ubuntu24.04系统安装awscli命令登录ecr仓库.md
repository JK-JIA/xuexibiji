ek参考网址：
https://www.liberiangeek.net/2024/04/install-aws-cli-ubuntu-24-04/

删除旧版本残留

```shell
file $(which aws)
/usr/local/bin/aws

sudo rm /usr/local/bin/aws
```

1 **安装 AWS CLI** 

使用 Snap 包管理器以“**经典**”模式在**Ubuntu 24.04上****安装 AWS CLI**： 

```shell
sudo snap install aws-cli --classic
```

2 设置 PATH 环境变量

```shell
export PATH=$PATH:/snap/bin
```

3 安装docker

```shell
snap install docker
```

4 配置 aws config

4902账号

```shell
aws configure set aws_access_key_id AKIAXEJFJEL7EOJ4OERJ
aws configure set aws_secret_access_key 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
aws configure set default.region ap-east-1
```

```shell
aws eks update-kubeconfig --region ap-east-1 --name UAT-hk-eks-cluster
```

4064账号

```yaml
aws configure
AWS Access Key ID [****************2F4J]: AKIAV5ISR6EZ2OKP2F4J
AWS Secret Access Key [****************J0dy]: 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
Default region name [ap-east-1]: ap-east-1
Default output format [json]: json

jjk 子账户
AWS Access Key ID [****************2F4J]: AKIAV5ISR6EZQMRMK647
AWS Secret Access Key [****************J0dy]: 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
```

```shell
aws configure set aws_access_key_id AKIAV5ISR6EZ2OKP2F4J
aws configure set aws_secret_access_key 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
aws configure set default.region ap-east-1
aws ecr get-login-password --region ap-east-1 | docker login --username AWS --password-stdin 406450204979.dkr.ecr.ap-east-1.amazonaws.com
```

欧洲账号

```shell
aws configure set aws_access_key_id "AKIAQYEI44N6JUIW2PI3"
aws configure set aws_secret_access_key "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"
aws configure set default.region "eu-central-1"
```

```shell
 cat /root/.aws/credentials 
[default]
aws_access_key_id = AKIAQYEI44N6JUIW2PI3
aws_secret_access_key = 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
```

```shell
cat /root/.aws/config 
[default]
region = eu-central-1
```

美国账号

```shell
aws configure set aws_access_key_id "AKIAQYEI44N6JUIW2PI3"
aws configure set aws_secret_access_key "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"
aws configure set default.region "us-east-1"
```

5837(独立站账号)

```shell
aws configure set aws_access_key_id "AKIAYP2LKU4KJONVSVA6"
aws configure set aws_secret_access_key "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"
aws configure set default.region "us-east-1"
```

5 登录 aws ecr 仓库

```shell
aws ecr get-login-password --region ap-east-1 | docker login --username AWS --password-stdin 406450204979.dkr.ecr.ap-east-1.amazonaws.com
WARNING! Your password will be stored unencrypted in /root/snap/docker/2918/.docker/config.json.
Configure a credential helper to remove this warning. See
https://docs.docker.com/engine/reference/commandline/login/#credentials-store

Login Succeeded
```

```shell
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin 490241336062.dkr.ecr.us-east-1.amazonaws.com

# 下面这个 4064开头的是生产jenkins 使用的镜像仓库的aws账号id
aws ecr get-login-password --region ap-east-1 | docker login --username AWS --password-stdin 406450204979.dkr.ecr.ap-east-1.amazonaws.com
```

