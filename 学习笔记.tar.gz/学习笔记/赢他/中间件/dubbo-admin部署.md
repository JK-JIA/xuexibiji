dubbo-admin 部署

```shell
git clone https://github.com/apache/dubbo-admin.git
cd dubbo-admin/kubernetes
```

创建 docker secrect 密钥

```shell
kubectl create secret docker-registry ytdocker \
--docker-server=devhub.yintaerp.com \
--docker-username=admin \
--docker-password=k68cuQGcPtDy3ip \
--docker-email=flux@example.com \
--namespace=kuboard
```

helm 导出的 yaml 文件，直接apply 

```yaml
---
# Source: dubbo-admin/templates/config.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: dubbo-admin
  namespace: erp-uat
data:
  application.properties: |
    admin.registry.address=zookeeper://zookeeper.uat.yintaerp.com:2181
    admin.config-center=zookeeper://zookeeper.uat.yintaerp.com:2181
    admin.metadata-report.address=zookeeper://zookeeper.uat.yintaerp.com:2181
    
    # nacos config, add parameters to url like username=nacos&password=nacos
    #admin.registry.address=nacos://127.0.0.1:8848?group=DEFAULT_GROUP&namespace=public
    #admin.config-center=nacos://127.0.0.1:8848?group=dubbo
    #admin.metadata-report.address=nacos://127.0.0.1:8848?group=dubbo
    
    #group (Deprecated it is recommended to use URL to add parameters,will be removed in the future)
    #admin.registry.group=dubbo
    #admin.config-center.group=dubbo
    #admin.metadata-report.group=dubbo
    
    #namespace used by nacos. (Deprecated it is recommended to use URL to add parameters,will be removed in the future)
    #admin.registry.namespace=public
    #admin.config-center.namespace=public
    #admin.metadata-report.namespace=public
    
    admin.root.user.name=root
    admin.root.user.password=root
    
    #session timeout, default is one hour
    admin.check.sessionTimeoutMilli=3600000
    
    
    # apollo config
    # admin.config-center = apollo://localhost:8070?token=e16e5cd903fd0c97a116c873b448544b9d086de9&app.id=test&env=dev&cluster=default&namespace=dubbo
    
    # (Deprecated it is recommended to use URL to add parameters,will be removed in the future)
    #admin.apollo.token=e16e5cd903fd0c97a116c873b448544b9d086de9
    #admin.apollo.appId=test
    #admin.apollo.env=dev
    #admin.apollo.cluster=default
    #admin.apollo.namespace=dubbo
    
    #compress
    server.compression.enabled=true
    server.compression.mime-types=text/css,text/javascript,application/javascript
    server.compression.min-response-size=10240
    
    #token timeout, default is one hour
    admin.check.tokenTimeoutMilli=3600000
    #Jwt signingKey
    admin.check.signSecret=86295dd0c4ef69a1036b0b0c15158d77
    
    #dubbo config
    dubbo.application.name=dubbo-admin
    dubbo.registry.address=${admin.registry.address}
    
    # mysql
    #spring.datasource.driver-class-name=com.mysql.jdbc.Driver
    #spring.datasource.url=jdbc:mysql://localhost:3306/dubbo-admin?characterEncoding=utf8&connectTimeout=1000&socketTimeout=10000&autoReconnect=true
    #spring.datasource.username=root
    #spring.datasource.password=mysql
    
    # h2
    spring.datasource.url=jdbc:h2:mem:~/dubbo-admin;
    spring.datasource.username=sa
    spring.datasource.password=
    
    # id generate type
    mybatis-plus.global-config.db-config.id-type=none
---
# Source: dubbo-admin/templates/service.yaml
apiVersion: v1
kind: Service
metadata:
  name: dubbo-admin
  namespace: erp-uat
  labels:
    app: dubbo-admin
spec:
  ports:
  - port: 8080
    name: http
    targetPort: 8080
  selector:
    app: dubbo-admin
  type: ClusterIP
---
# Source: dubbo-admin/templates/deployment-v1.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: dubbo-admin
  namespace: erp-uat
  labels:
    app: dubbo-admin
    version: v1
  annotations:
    fluxcd.io/automated: "false"
spec:
  replicas: 1
  strategy:
    type: "RollingUpdate"
    rollingUpdate:
      maxSurge: 25%
      maxUnavailable: 25%

 
  revisionHistoryLimit: 2
  selector:
    matchLabels:
      app: dubbo-admin
      version: v1
  template:
    metadata:
      labels:
        app: dubbo-admin
        version: v1
    spec:
      terminationGracePeriodSeconds: 5
      containers:
      - name: dubbo-admin
        image: registry.cn-shanghai.aliyuncs.com/yintatech/ops-dubbo-admin:1.0.4 # {"$imagepolicy": "flux-erp-uat:dubbo-admin"}
        command:
        - java
        - -Dspring.config.location=/mnt/application.properties
        - -jar
        - app.jar
        env:
        - name: aliyun_logs_dubbo-admin-stdout
          value: stdout
        - name: admin.registry.address
          value: "zookeeper://zookeeper.erp-uat.yintaerp.com:2181"

        ports:
        - containerPort: 8080
          name: api
        resources:
          requests:
            cpu: 10m
            memory: 20Mi
          limits:
            cpu: "2"
            memory: "8Gi"
        volumeMounts:
        - mountPath: /mnt/application.properties
          subPath: application.properties
          name: config
      volumes:
        - name: config
          configMap:
            name: dubbo-admin

            
      imagePullSecrets:
      - name: ytdocker
---
# Source: dubbo-admin/templates/ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: dubbo-admin
  namespace: erp-uat
  #annotations:
  #  nginx.ingress.kubernetes.io/rewrite-target: /$2
spec:
  rules:
    - host: dubbo-admin.erp-uat.yintaerp.com
      http:
        paths:
          - path: /
            pathType: Prefix
            backend:
              service: 
                name: dubbo-admin
                port:
                  number: 8080

```

访问管理界面

```
http://192.168.3.101:30080/#/login?redirect=%2F
```

用户密码在 configmap 中配置

```
root / root
```

