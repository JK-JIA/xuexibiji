赢他 nginx 部署在 192.168.3.248上，目录在（/usr/local/openresty/nginx）

版本为：openresty/1.21.4.1



部署服务器版本

```shell
Distributor ID: Ubuntu
Description:    Ubuntu 20.04.4 LTS
Release:        20.04
Codename:       focal
```

1 ubuntu 系统安装 需要的基础工具

```shell
sudo apt update
sudo apt install -y build-essential libpcre3 libpcre3-dev libssl-dev make zlib1g-dev
```

二进制安装

官网下载所需要的版本，

```
https://openresty.org/cn/download.html
```

下载二进制文件

```shell
wget https://openresty.org/download/openresty-1.21.4.1.tar.gz
tar xf openresty-1.21.4.1.tar.gz
cd openresty-1.21.4.1/
```

编译安装

```shell
./configure
```

```shell
make && make install
```

安装完成，查看版本

```shell
/usr/local/openresty/nginx/sbin/nginx -v
nginx version: openresty/1.21.4.1
```

