[TOC]



#### 生产基础环境概述

生产环境部署使用 3 台aws ec2 服务器使用docker-compose部署 zookeeper 集群

配置文件在（/home/app/zookeeper 目录下）

| 服务器ip      | 配置                  | 环境 |
| ------------- | --------------------- | ---- |
| 192.168.9.92  | 4c/8G  Ubuntu 22.04.2 | zk01 |
| 192.168.9.244 | 4c/8G  Ubuntu 22.04.2 | zk02 |
| 192.168.9.235 | 4c/8G  Ubuntu 22.04.2 | zk03 |

阿里云配置域名解析

```
生产环境
zk.aws.yintaerp.com  解析到  zookeeper-5c3c7c9ef5cff837.elb.ap-east-1.amazonaws.com
zookeeper-5c3c7c9ef5cff837.elb.ap-east-1.amazonaws.com 是4064 aws 账号上生产的elb
负载到 192.168.9.92、244，235 三台机器上

sit环境
zookeeper.erp-sit.yintaerp.com   解析到    192.168.3.233 服务器
uat环境
zookeeper.erp-uat.yintaerp.com   解析到  	192.168.3.204 nginx 服务器
```

![image-20240926111122427](C:\Users\admin\AppData\Roaming\Typora\typora-user-images\image-20240926111122427.png)

![image-20240926110328069](C:\Users\admin\AppData\Roaming\Typora\typora-user-images\image-20240926110328069.png)



![image-20240926112454137](C:\Users\admin\AppData\Roaming\Typora\typora-user-images\image-20240926112454137.png)



我这里模仿生产环境搭建一套 zk 集群

| 服务器ip      | 配置                  | 环境 |
| ------------- | --------------------- | ---- |
| 192.168.3.101 | 4c/8G  Ubuntu 22.04.2 | zk01 |
| 192.168.3.102 | 4c/8G  Ubuntu 22.04.2 | zk02 |
| 192.168.3.208 | 4c/8G  Ubuntu 22.04.2 | zk03 |

### 基础环境配置

#### 1 配置时间同步

1 使用 ntp 命令

2 使用 ntpdate 命令

安装 ntpd：

```
sudo apt update
sudo apt install ntp
```

检查 ntpd 的运行状态：

```ebnf
systemctl status ntp
```

配置 ntpd

```vim
vim /etc/ntp.conf
```

找到配置中的 NTP 服务器相关的部分，通常会有如下配置：

```
复制代码
pool 0.ubuntu.pool.ntp.org iburst
pool 1.ubuntu.pool.ntp.org iburst
pool 2.ubuntu.pool.ntp.org iburst
pool 3.ubuntu.pool.ntp.org iburst
pool 4.ubuntu.pool.ntp.org iburst
pool 5.ubuntu.pool.ntp.org iburst
```

将其注释掉或删除，并替换为阿里云的 NTP 服务器：

```
复制代码
server ntp.aliyun.com iburst
```

修改配置文件之后，需要重新加载 ntpd

```
sudo systemctl restart ntp
```

验证时间同步状态

```
ntpq -p
```

确认系统时间同步

```
date
```



安装 ntpdate 命令安装 ntpdate 命令

```
sudo apt update
sudo apt install ntpdate -y
```

同步阿里云

```
timedatectl set-timezone Asia/Shanghai
ntpdate ntp.aliyun.com
```

检查时间

```
date

timedatectl
```

### 

#### 2 安装docker，docker-compose 服务

ubuntu20.04 安装docker 和 docker-compose

```shell
1、卸载可能存在的或者为安装成功的Docker版本
sudo apt-get remove docker docker-engine docker-ce docker.io

2、添加阿里云的GPG密钥
curl -fsSL http://mirrors.aliyun.com/docker-ce/linux/ubuntu/gpg | sudo apt-key add -

或者添加官方gpg密钥
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

3、使用以下命令设置阿里云存储库
sudo add-apt-repository "deb [arch=amd64] http://mirrors.aliyun.com/docker-ce/linux/ubuntu $(lsb_release -cs) stable"

或者使用官方存储库
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

4、更新apt包索引，安装最新版本的Docker Engine、containerd 和 Docker Compose
sudo apt-get update
sudo apt-get install docker-ce docker-ce-cli containerd.io docker-compose-plugin -y

验证docker
sudo docker version
sudo systemctl start docker
sudo systemctl enable docker

安装 docker-compose (amd64 版本)
sudo curl -SL https://github.com/docker/compose/releases/download/v2.6.0/docker-compose-linux-x86_64 -o /usr/local/bin/docker-compose && chmod +x /usr/local/bin/docker-compose

安装 docker-compose (aarch64 版本)
sudo curl -SL https://github.com/docker/compose/releases/download/v2.6.0/docker-compose-linux-aarch64 -o /usr/local/bin/docker-compose && chmod +x /usr/local/bin/docker-compose

启动 dockers-compose
sudo systemctl start docker-compose
sudo systemctl enable docker-compose
```

##### 2.1 修改主机名

```shell
hostnamectl set-hostname node1
hostnamectl set-hostname node2
hostnamectl set-hostname node3

vim /etc/hostname
node1
```

修改 hosts 文件

```
vim /etc/hosts

192.168.3.101 node1
192.168.3.102 node2
192.168.3.208 node3
```



#### 3 编写 docker-compose 文件

(3台服务器compose文件都放在 /home/app/zookeeper/docker-com)

zk01 服务器

```yaml
vim docker-compose.yaml

version: '3'
services:
  zookeeper:
    container_name: zookeeper
    image:  zookeeper:3.8
    restart: always  
    # 设置为节点hostname 名称
    hostname: node1
    ports:
    - 2181:2181
    - 2888:2888
    - 3888:3888
    environment:
    - ZOO_4LW_COMMANDS_WHITELIST=*
    - ZOO_MAX_CLIENT_CNXNS=3000
    - ZOO_INIT_LIMIT=10
    - ZOO_MY_ID=1
        # server.1 设置为 192.168.3.101 , server.2 设置为192.168.3.202，server.3 设置为 192.168.3.208
    - ZOO_SERVERS=server.1=0.0.0.0:2888:3888;2181 server.2=192.168.3.102:2888:3888;2181 server.3=192.168.3.208:2888:3888;2181
    volumes:
      - /etc/hosts:/etc/hosts
      - /etc/localtime:/etc/localtime
      - /etc/hostname:/etc/hostname
      # 挂载配置目录
      - ./data:/data
    healthcheck:
      test: ["CMD", "bin/zkServer.sh", "status"]
      interval: 1m30s
      timeout: 10s
      retries: 3
```

zk02 服务器

```yaml
version: '3'
services:
  zookeeper:
    container_name: zookeeper
    image:  zookeeper:3.8
    restart: always  
    # 设置为节点hostname 名称
    hostname: node2
    ports:
    - 2181:2181
    - 2888:2888
    - 3888:3888
    environment:
    - ZOO_4LW_COMMANDS_WHITELIST=*
    - ZOO_MAX_CLIENT_CNXNS=3000
    - ZOO_INIT_LIMIT=10
    - ZOO_MY_ID=2
        # server.1 设置为 192.168.3.101 , server.2 设置为192.168.3.202，server.3 设置为 192.168.3.208
    - ZOO_SERVERS=server.1=192.168.3.101:2888:3888;2181 server.2=0.0.0.0:2888:3888;2181 server.3=192.168.3.208:2888:3888;2181

    volumes:
      - /etc/hosts:/etc/hosts
      - /etc/localtime:/etc/localtime
      - /etc/hostname:/etc/hostname
      # 挂载配置目录
      - ./data:/data
    healthcheck:
      test: ["CMD", "bin/zkServer.sh", "status"]
      interval: 1m30s
      timeout: 10s
      retries: 3
```

zk03 服务器

```yaml
version: '3'
services:
  zookeeper:
    container_name: zookeeper
    image:  zookeeper:3.8
    restart: always  
    # 设置为节点hostname 名称
    hostname: node1
    ports:
    - 2181:2181
    - 2888:2888
    - 3888:3888
    environment:
    - ZOO_4LW_COMMANDS_WHITELIST=*
    - ZOO_MAX_CLIENT_CNXNS=3000
    - ZOO_INIT_LIMIT=10
    - ZOO_MY_ID=3
        # server.1 设置为 192.168.3.101 , server.2 设置为192.168.3.202，server.3 设置为 192.168.3.208
    - ZOO_SERVERS=server.1=192.168.3.101:2888:3888;2181 server.2=192.168.3.102:2888:3888;2181 server.3=0.0.0.0:2888:3888;2181

    volumes:
      - /etc/hosts:/etc/hosts
      - /etc/localtime:/etc/localtime
      - /etc/hostname:/etc/hostname
      # 挂载配置目录
      - ./data:/data
    healthcheck:
      test: ["CMD", "bin/zkServer.sh", "status"]
      interval: 1m30s
      timeout: 10s
      retries: 3

```

#### 4 创建挂在需要的配置目录和文件

```
mkdir /data
```

##### 4.1 创建集群 myid 文件

3.101设置为 1 ，3.102 设置为 2 ，3.204 设置为 3

```
cat data/myid 
1
```

#### 5 启动 docker-compose 

```
docker-compose up -d 
```

##### 5.1 进入容器查看集群状态

```shell
docker-compose exec zookeeper-eu /bin/bash
```

##### 5.2 查看当前节点状态

```yaml
./bin/zkServer.sh status
ZooKeeper JMX enabled by default
Using config: /conf/zoo.cfg
Client port found: 2181. Client address: localhost. Client SSL: false.
Mode: follower  # 显示角色为 follower
```

##### 5.3 显示其他节点角色

```
echo stat | nc <节点ip> 2181
```



单节点部署 zookeeper ，只有一个节点，不部署集群
编写 docker-compose.yaml

```yaml
version: '3'
services:
  zookeeper-eu:
    container_name: zookeeper-eu
    image: zookeeper:3.8
    restart: always
    hostname: zookeeper-node1
    ports:
      - 2182:2181  # 只需要暴露客户端连接端口
    environment:
      - ZOO_4LW_COMMANDS_WHITELIST=*
      - ZOO_MAX_CLIENT_CNXNS=3000
      - ZOO_INIT_LIMIT=10
    volumes:
      - ./data:/data
    healthcheck:
      test: ["CMD", "bin/zkServer.sh", "status"]
      interval: 1m30s
      timeout: 10s
      retries: 3
```

