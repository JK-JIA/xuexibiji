赢他 rabbitmq 部署，3副本集群

##### 生产基础环境概述

生产环境部署使用 3 台aws ec2 服务器使用docker-compose部署 zookeeper 集群

配置文件在（/home/app/rabbitmq 目录下）

| 服务器ip      | 配置                  | 环境 |
| ------------- | --------------------- | ---- |
| 192.168.9.92  | 4c/8G  Ubuntu 22.04.2 | zk01 |
| 192.168.9.244 | 4c/8G  Ubuntu 22.04.2 | zk02 |
| 192.168.9.235 | 4c/8G  Ubuntu 22.04.2 | zk03 |

sit 环境部署在 192.168.3.203 服务器上，/home/rabbitmq 目录下，docker-compose部署



### 开始部署

这里参考生产文件，部署 欧洲 eu 服务器，配置如下

| 服务器ip      | 配置                      | 环境     |
| ------------- | ------------------------- | -------- |
| 172.33.165.34 | 4c/8G  Ubuntu 24.04.1 LTS | zk-mq-01 |
| 172.33.170.64 | 4c/8G  Ubuntu 24.04.1 LTS | zk-mq-02 |
| 172.33.160.20 | 4c/8G  Ubuntu 24.04.1 LTS | zk-mq-03 |

### 基础环境配置 (3台都做)

#### 1 配置时间同步

安装 ntpdate 命令

```
sudo apt update
sudo apt install ntpdate -y
```

同步阿里云

```
timedatectl set-timezone Asia/Shanghai
ntpdate ntp.aliyun.com
```

检查时间

```
date

timedatectl
```

### 

#### 2 安装docker，docker-compose 服务

ubuntu20.04 安装docker 和 docker-compose

```shell
1、卸载可能存在的或者为安装成功的Docker版本
sudo apt-get remove docker docker-engine docker-ce docker.io

2、添加阿里云的GPG密钥
curl -fsSL http://mirrors.aliyun.com/docker-ce/linux/ubuntu/gpg | sudo apt-key add -

或者添加官方gpg密钥 #（这里因为服务器在欧洲，所以使用的官方的）
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

3、使用以下命令设置阿里云存储库
sudo add-apt-repository "deb [arch=amd64] http://mirrors.aliyun.com/docker-ce/linux/ubuntu $(lsb_release -cs) stable"

或者使用官方存储库 #（这里因为服务器在欧洲，所以使用的官方的）
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

4、更新apt包索引，安装最新版本的Docker Engine、containerd 和 Docker Compose
sudo apt-get update
sudo apt-get install docker-ce docker-ce-cli containerd.io docker-compose-plugin -y

验证docker
sudo docker version
sudo systemctl start docker
sudo systemctl enable docker

安装 docker-compose (amd64 版本)
sudo curl -SL https://github.com/docker/compose/releases/download/v2.6.0/docker-compose-linux-x86_64 -o /usr/local/bin/docker-compose && chmod +x /usr/local/bin/docker-compose

安装 docker-compose (aarch64 版本)
sudo curl -SL https://github.com/docker/compose/releases/download/v2.6.0/docker-compose-linux-aarch64 -o /usr/local/bin/docker-compose && chmod +x /usr/local/bin/docker-compose

启动 dockers-compose
sudo systemctl start docker-compose
sudo systemctl enable docker-compose
```

##### 2.1 修改主机名

```shell
hostnamectl set-hostname zk-mq-01
hostnamectl set-hostname zk-mq-02
hostnamectl set-hostname zk-mq-03
```

修改 hosts 文件

```shell
vim /etc/hosts

172.33.165.34 zk-mq-01
172.33.170.64 zk-mq-02
172.33.160.20 zk-mq-03
```

升级openssh后Xshell无法使用sftp

参考网址

```
https://blog.csdn.net/mayifan0/article/details/89882052
```

修改文件 

```shell
vim /etc/ssh/sshd_config
# 注释掉原来的
#Subsystem sftp  /usr/libexec/openssh/sftp-server
Subsystem sftp  internal-sftp
```

重启服务

```
systemctl restart ssh
```



#### 3 编写 docker-compose 文件

查看文件目录结构 /root/rabbitmq

```shell
tree rabbitmq
rabbitmq
├── docker-compose.yaml
├── Dockerfile
├── data  #挂载的本地存储目录
│   ├── mnesia  #存储的配置
├── rabbitmq
│   ├── enabled_plugins  #指定 RabbitMQ 启动时需要加载的插件
│   └── rabbitmq.conf  #配置文件
└── rabbitmq_delayed_message_exchange-3.8.0.ez  # 插件

```

查看 rabbitmq.conf 文件

```yaml
cat rabbitmq/rabbitmq.conf 
loopback_users.guest = false # 禁用 guest 用户通过非本地（非 localhost）连接访问 RabbitMQ
listeners.tcp.default = 5672 # 指定 RabbitMQ 使用的 AMQP监听的默认 TCP 端口，默认是 5672
management.tcp.port = 15672 # 指定 RabbitMQ web控制台 插件使用的 HTTP 端口，默认是 15672
management_agent.disable_metrics_collector = false # 禁用 RabbitMQ Management Agent 的指标收集功能
```

查看 enabled_plugins 文件

```
cat rabbitmq/enabled_plugins 
[rabbitmq_prometheus,rabbitmq_delayed_message_exchange,rabbitmq_management,rabbitmq_prometheus].
```

docker-compose up 启动后会自动创建挂载卷

```shell
docker volume ls
DRIVER    VOLUME NAME
local     2f9a7ab95d2fcff4b6f9829e13a6351e67f5de8e788a7382993064956e3652a2
local     52b50306b9c927bbbe91efb71d50ec3bec7efdf780d9d1df7bb4b00c093fa7c7
local     733f8f2496b463a902974e363049e2048bc337259fb313b09be125e859ac6ca0
local     254124bd4f60e29cf1934383af3aee67d9272c44fee6e125bf07f97223f02d6a
local     7122208a8e0d449b8c7c06788e44fac01a751b367aa90c41a1f4bd6274383238
local     fd79098d555689fa7d115c7bc495be5c955318b8e018284902be3748786802c1
local     rabbitmq-sit_datasit # docker-compos 配置的名字，自动创建


docker volume inspect rabbitmq-sit_datasit 
[
    {
        "CreatedAt": "2024-09-23T02:39:23Z",
        "Driver": "local",
        "Labels": {
            "com.docker.compose.project": "rabbitmq-sit",
            "com.docker.compose.version": "2.6.0",
            "com.docker.compose.volume": "datasit"
        },
        "Mountpoint": "/var/lib/docker/volumes/rabbitmq-sit_datasit/_data", #挂载地址
        "Name": "rabbitmq-sit_datasit",
        "Options": null,
        "Scope": "local"
    }
```

修改Dockerfile ，From 镜像设置为 3.10.1

（FROM rabbitmq:3 会拉取最新版本，启动会插件兼容性报错）

```dockerfile
cat Dockerfile 
FROM rabbitmq:3.11
COPY rabbitmq_delayed_message_exchange-3.11.1.ez /opt/rabbitmq/plugins/rabbitmq_delayed_message_exchange-3.11.1.ez
```

编写dockercompose.yaml 文件 （zk-mq-01）

```yaml
version: '3'
services:
  rabbitmq:
    container_name: rabbitmq-eu
    restart: always  
    hostname: zk-mq-01
    build:
      context: .
      dockerfile: Dockerfile
    ports:
      - 5672:5672
      - 4369:4369
      - 15672:15672
      - 25672:25672
      - 15692:15692
    entrypoint:
    - rabbitmq-server
    - --detached
    volumes:
      - /etc/hosts:/etc/hosts
      - /etc/localtime:/etc/localtime
      - /etc/timezone:/etc/timezone
     #- ./enabled_plugins:/etc/rabbitmq/enabled_plugins
      - ./rabbitmq:/etc/rabbitmq
      - ./data:/var/lib/rabbitmq/
    healthcheck:
      test: ["CMD", "rabbitmq-diagnostics", "ping"]
      interval: 1m30s
      timeout: 10s
      retries: 3
```

编写dockercompose.yaml 文件 （zk-mq-02）

```yaml
version: '3'
services:
  rabbitmq:
    container_name: rabbitmq-eu
    restart: always  
    hostname: zk-mq-02
    build:
      context: .
      dockerfile: Dockerfile
    ports:
      - 5672:5672
      - 4369:4369
      - 15672:15672
      - 25672:25672
      - 15692:15692
    entrypoint:
    - rabbitmq-server
    - --detached
    volumes:
      - /etc/hosts:/etc/hosts
      - /etc/localtime:/etc/localtime
      - /etc/timezone:/etc/timezone
     #- ./enabled_plugins:/etc/rabbitmq/enabled_plugins
      - ./rabbitmq:/etc/rabbitmq
      - ./data:/var/lib/rabbitmq/
    healthcheck:
      test: ["CMD", "rabbitmq-diagnostics", "ping"]
      interval: 1m30s
      timeout: 10s
      retries: 3
```

编写dockercompose.yaml 文件 （zk-mq-03）

```yaml
version: '3'
services:
  rabbitmq:
    container_name: rabbitmq-eu
    restart: always  
    hostname: zk-mq-03
    build:
      context: .
      dockerfile: Dockerfile
    ports:
      - 5672:5672
      - 4369:4369
      - 15672:15672
      - 25672:25672
      - 15692:15692
    entrypoint:
    - rabbitmq-server
    - --detached
    volumes:
      - /etc/hosts:/etc/hosts
      - /etc/localtime:/etc/localtime
      - /etc/timezone:/etc/timezone
     #- ./enabled_plugins:/etc/rabbitmq/enabled_plugins
      - ./rabbitmq:/etc/rabbitmq
      - ./data:/var/lib/rabbitmq/
    healthcheck:
      test: ["CMD", "rabbitmq-diagnostics", "ping"]
      interval: 1m30s
      timeout: 10s
      retries: 3
```

启动服务

```
docker-compose up -d 
```

进入容器

```
docker-compose exec rabbitmq /bin/bash
```

查看集群状态

```
rabbitmqctl cluster_status
```

加入集群

```
rabbitmqctl stop_app
rabbitmqctl reset
rabbitmqctl join_cluster rabbit@eupre-zk-mq-01
rabbitmqctl start_app
```

查看开启的插件

```shell
rabbitmq-plugins list -E

Listing plugins with pattern ".*" ...
 Configured: E = explicitly enabled; e = implicitly enabled
 | Status: * = running on rabbit@rabbitmq-eu
 |/
[E*] rabbitmq_delayed_message_exchange 3.8.0
[E*] rabbitmq_federation               3.10.1
[E*] rabbitmq_federation_management    3.10.1
[E*] rabbitmq_management               3.10.1
[E*] rabbitmq_prometheus               3.10.1
```

如果未开启，在容器中执行命令开启

```shell
rabbitmq-plugins enable rabbitmq_federation
rabbitmq-plugins enable rabbitmq_federation_management
```

访问控制台

```
http://172.33.165.34:15672/
```

默认用户密码

```
guest / guest
```





```shell
# 停掉rabbitmq应用
docker exec -it rabbitmq-node2 rabbitmqctl stop_app
# 停掉rabbitmq应用，重置rabbitmq、交换机、队列
docker exec -it rabbitmq-node2 rabbitmqctl reset
# 加入集群到 rabbit@zk-mq-01
docker exec -it rabbitmq-node2 rabbitmqctl join_cluster rabbit@hkpre-zk-mq-01
# 启动rabbitmq应用
docker exec -it rabbitmq-node2 rabbitmqctl start_app

docker exec -it rabbitmq-node3 rabbitmqctl stop_app
docker exec -it rabbitmq-node3 rabbitmqctl reset
docker exec -it rabbitmq-node2 rabbitmqctl join_cluster rabbit@zk-mq-01
docker exec -it rabbitmq-node3 rabbitmqctl start_app

```



单节点部署：
编写docker-compose.yaml 文件

```yaml
version: '3'
services:
  rabbitmq-sit:
    container_name: rabbitmq-eu-uat
    restart: always  
    hostname: rabbitmq-eu-uat
    build:
      context: .
      dockerfile: Dockerfile
    #image: rabbitmq:3

    ports:
      - 5672:5672
      - 15672:15672
    volumes:
      #- /etc/hosts:/etc/hosts
      - /etc/localtime:/etc/localtime
      - /etc/timezone:/etc/timezone
     #- ./enabled_plugins:/etc/rabbitmq/enabled_plugins
      - ./rabbitmq:/etc/rabbitmq
      - datasit:/var/lib/rabbitmq/
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost"]
      interval: 1m30s
      timeout: 10s
      retries: 3
volumes:
  datasit: 
```

常用命令

```yaml
# 查看集群状态
rabbitmqctl cluster_status
#查看开启插件
rabbitmq-plugins list -E
#查看参数 / 联邦配置
rabbitmqctl list_parameters
#查看 policies 设置的规则
rabbitmqctl list_policies
```



