nacos 的数据也是直接存储在数据库中的，需要创建新的库和表结构

官方提供里初始化sql（https://github.com/alibaba/nacos/releases/）

下载需要版本的tar文件，这里部署2.20版本nacos，所以下载这个版本文件

```
wget https://github.com/alibaba/nacos/releases/download/2.2.0/nacos-server-2.2.0.tar.gz
tar xf nacos-server-2.2.0.tar.gz

ll nacos/conf/
total 96
drwxr-xr-x 2  502 staff  4096 Dec  1  2022 ./
drwxr-xr-x 5 root root   4096 Sep 27 16:02 ../
-rw-r--r-- 1  502 staff  1224 Oct 31  2022 1.4.0-ipv6_support-update.sql
-rw-r--r-- 1  502 staff  9235 Dec  1  2022 application.properties
-rw-r--r-- 1  502 staff  9440 Dec  1  2022 application.properties.example
-rw-r--r-- 1  502 staff   670 Oct 31  2022 cluster.conf.example
-rw-r--r-- 1  502 staff  8939 Nov  2  2022 derby-schema.sql
-rw-r--r-- 1  502 staff 10825 Nov  2  2022 mysql-schema.sql
-rw-r--r-- 1  502 staff 31156 Oct 31  2022 nacos-logback.xml

我们需要使用 mysql-schema.sql
```

在数据库 192.168.3.233 上创建初始化库和表

```
create database eu_nacos default character set utf8mb4;
create user eu_nacos@'%' identified WITH mysql_native_password BY "SmwbGmaXZBK4";
grant all privileges on eu_nacos.* to eu_nacos@'%' ;
```

```sql
数据库docker-compose部署在 /root/b/nacos-mysql 目录

# 连接数据库
mysql -uroot -pOhJ2aima3Aexahwee -h 127.0.0.1 -P 13306

#执行命令，导入数据
mysql>create database nacos_test default character set utf8mb4;
mysql>create user nacos@'%' identified WITH mysql_native_password BY "wqL4DHTf";
mysql>grant all privileges on nacos.* to nacos@'%' ;
mysql>use nacos_test;
mysql>/opt/conf/mysql-schema.sql;
```

这里粘贴一下我下载的 mysql-schema.sql 文件

```sql
/*
 * Copyright 1999-2018 Alibaba Group Holding Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/******************************************/
/*   数据库全名 = nacos_config   */
/*   表名称 = config_info   */
/******************************************/
CREATE TABLE `config_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `data_id` varchar(255) NOT NULL COMMENT 'data_id',
  `group_id` varchar(128) DEFAULT NULL,
  `content` longtext NOT NULL COMMENT 'content',
  `md5` varchar(32) DEFAULT NULL COMMENT 'md5',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `src_user` text COMMENT 'source user',
  `src_ip` varchar(50) DEFAULT NULL COMMENT 'source ip',
  `app_name` varchar(128) DEFAULT NULL,
  `tenant_id` varchar(128) DEFAULT '' COMMENT '租户字段',
  `c_desc` varchar(256) DEFAULT NULL,
  `c_use` varchar(64) DEFAULT NULL,
  `effect` varchar(64) DEFAULT NULL,
  `type` varchar(64) DEFAULT NULL,
  `c_schema` text,
  `encrypted_data_key` text NOT NULL COMMENT '秘钥',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_configinfo_datagrouptenant` (`data_id`,`group_id`,`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='config_info';

/******************************************/
/*   数据库全名 = nacos_config   */
/*   表名称 = config_info_aggr   */
/******************************************/
CREATE TABLE `config_info_aggr` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `data_id` varchar(255) NOT NULL COMMENT 'data_id',
  `group_id` varchar(128) NOT NULL COMMENT 'group_id',
  `datum_id` varchar(255) NOT NULL COMMENT 'datum_id',
  `content` longtext NOT NULL COMMENT '内容',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `app_name` varchar(128) DEFAULT NULL,
  `tenant_id` varchar(128) DEFAULT '' COMMENT '租户字段',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_configinfoaggr_datagrouptenantdatum` (`data_id`,`group_id`,`tenant_id`,`datum_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='增加租户字段';


/******************************************/
/*   数据库全名 = nacos_config   */
/*   表名称 = config_info_beta   */
/******************************************/
CREATE TABLE `config_info_beta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `data_id` varchar(255) NOT NULL COMMENT 'data_id',
  `group_id` varchar(128) NOT NULL COMMENT 'group_id',
  `app_name` varchar(128) DEFAULT NULL COMMENT 'app_name',
  `content` longtext NOT NULL COMMENT 'content',
  `beta_ips` varchar(1024) DEFAULT NULL COMMENT 'betaIps',
  `md5` varchar(32) DEFAULT NULL COMMENT 'md5',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `src_user` text COMMENT 'source user',
  `src_ip` varchar(50) DEFAULT NULL COMMENT 'source ip',
  `tenant_id` varchar(128) DEFAULT '' COMMENT '租户字段',
  `encrypted_data_key` text NOT NULL COMMENT '秘钥',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_configinfobeta_datagrouptenant` (`data_id`,`group_id`,`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='config_info_beta';

/******************************************/
/*   数��库全名 = nacos_config   */
/*   表名称 = config_info_tag   */
/******************************************/
CREATE TABLE `config_info_tag` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `data_id` varchar(255) NOT NULL COMMENT 'data_id',
  `group_id` varchar(128) NOT NULL COMMENT 'group_id',
  `tenant_id` varchar(128) DEFAULT '' COMMENT 'tenant_id',
  `tag_id` varchar(128) NOT NULL COMMENT 'tag_id',
  `app_name` varchar(128) DEFAULT NULL COMMENT 'app_name',
  `content` longtext NOT NULL COMMENT 'content',
  `md5` varchar(32) DEFAULT NULL COMMENT 'md5',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `src_user` text COMMENT 'source user',
  `src_ip` varchar(50) DEFAULT NULL COMMENT 'source ip',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_configinfotag_datagrouptenanttag` (`data_id`,`group_id`,`tenant_id`,`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='config_info_tag';

/******************************************/
/*   数据库全名 = nacos_config   */
/*   表名称 = config_tags_relation   */
/******************************************/
CREATE TABLE `config_tags_relation` (
  `id` bigint(20) NOT NULL COMMENT 'id',
  `tag_name` varchar(128) NOT NULL COMMENT 'tag_name',
  `tag_type` varchar(64) DEFAULT NULL COMMENT 'tag_type',
  `data_id` varchar(255) NOT NULL COMMENT 'data_id',
  `group_id` varchar(128) NOT NULL COMMENT 'group_id',
  `tenant_id` varchar(128) DEFAULT '' COMMENT 'tenant_id',
  `nid` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`nid`),
  UNIQUE KEY `uk_configtagrelation_configidtag` (`id`,`tag_name`,`tag_type`),
  KEY `idx_tenant_id` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='config_tag_relation';

/******************************************/
/*   数据库全名 = nacos_config   */
/*   表名称 = group_capacity   */
/******************************************/
CREATE TABLE `group_capacity` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `group_id` varchar(128) NOT NULL DEFAULT '' COMMENT 'Group ID，空字符表示整个集群',
  `quota` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '配额，0表示使用默认值',
  `usage` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '使用量',
  `max_size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '单个配置大小上限，单位为字节，0表示使用默认值',
  `max_aggr_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '聚合子配置最大个数，，0表示使用默认值',
  `max_aggr_size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '单个聚合数据的子配置大小上限，单位为字节，0表示使用默认值',
  `max_history_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最大变更历史数量',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='集群、各Group容量信息表';

/******************************************/
/*   数据库全名 = nacos_config   */
/*   表名称 = his_config_info   */
/******************************************/
CREATE TABLE `his_config_info` (
  `id` bigint(20) unsigned NOT NULL,
  `nid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `data_id` varchar(255) NOT NULL,
  `group_id` varchar(128) NOT NULL,
  `app_name` varchar(128) DEFAULT NULL COMMENT 'app_name',
  `content` longtext NOT NULL,
  `md5` varchar(32) DEFAULT NULL,
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `src_user` text,
  `src_ip` varchar(50) DEFAULT NULL,
  `op_type` char(10) DEFAULT NULL,
  `tenant_id` varchar(128) DEFAULT '' COMMENT '租户字段',
  `encrypted_data_key` text NOT NULL COMMENT '秘钥',
  PRIMARY KEY (`nid`),
  KEY `idx_gmt_create` (`gmt_create`),
  KEY `idx_gmt_modified` (`gmt_modified`),
  KEY `idx_did` (`data_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='多租户改造';


/******************************************/
/*   数据库全名 = nacos_config   */
/*   表名称 = tenant_capacity   */
/******************************************/
CREATE TABLE `tenant_capacity` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `tenant_id` varchar(128) NOT NULL DEFAULT '' COMMENT 'Tenant ID',
  `quota` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '配额，0表示使用默认值',
  `usage` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '使用量',
  `max_size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '单个配置大小上限，单位为字节，0表示使用默认值',
  `max_aggr_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '聚合子配置最大个数',
  `max_aggr_size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '���个聚合数据的子配置大小上限，单位为字节，0表示使用默认值',
  `max_history_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最大变更历史数量',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tenant_id` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='租户容量信息表';


CREATE TABLE `tenant_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `kp` varchar(128) NOT NULL COMMENT 'kp',
  `tenant_id` varchar(128) default '' COMMENT 'tenant_id',
  `tenant_name` varchar(128) default '' COMMENT 'tenant_name',
  `tenant_desc` varchar(256) DEFAULT NULL COMMENT 'tenant_desc',
  `create_source` varchar(32) DEFAULT NULL COMMENT 'create_source',
  `gmt_create` bigint(20) NOT NULL COMMENT '创建时间',
  `gmt_modified` bigint(20) NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tenant_info_kptenantid` (`kp`,`tenant_id`),
  KEY `idx_tenant_id` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='tenant_info';

CREATE TABLE `users` (
        `username` varchar(50) NOT NULL PRIMARY KEY,
        `password` varchar(500) NOT NULL,
        `enabled` boolean NOT NULL
);

CREATE TABLE `roles` (
        `username` varchar(50) NOT NULL,
        `role` varchar(50) NOT NULL,
        UNIQUE INDEX `idx_user_role` (`username` ASC, `role` ASC) USING BTREE
);

CREATE TABLE `permissions` (
    `role` varchar(50) NOT NULL,
    `resource` varchar(255) NOT NULL,
    `action` varchar(8) NOT NULL,
    UNIQUE INDEX `uk_role_permission` (`role`,`resource`,`action`) USING BTREE
);

INSERT INTO users (username, password, enabled) VALUES ('nacos', '$2a$10$EuWPZHzz32dJN7jexM34MOeYirDdFAZm2kuWj7VEOJhhZkDrxfvUu', TRUE);

INSERT INTO roles (username, role) VALUES ('nacos', 'ROLE_ADMIN');
```

创建 nacos 文件，部署到 k8s集群

文件是从 sit  k8s 集群导出的

```shell
kubectl get statefulsets.apps -n sit nacos2 -o yaml >> nacos2.yaml
kubectl get svc -n sit nacos2 -o yaml >> nacos2.yaml
kubectl get configmaps -n sit nacos2-cm -o yaml >> nacos2.yaml
```

创建需要的 secrect 文件，拉取镜像使用

```shell
kubectl create secret docker-registry ytdocker \
--docker-server=devhub.yintaerp.com \
--docker-username=admin \
--docker-password=k68cuQGcPtDy3ip \
--docker-email=flux@example.com \
--namespace=flux-bi-sit
```

创建 nacos2 yaml 文件
注意修改 configmap 文件，数据库的连接方式

```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: nacos2
  namespace: us
spec:
  replicas: 3
  revisionHistoryLimit: 10
  selector:
    matchLabels:
      app: nacos2
  serviceName: nacos2
  template:
    metadata:
      labels:
        app: nacos2
    spec:
      containers:
      - command:
        - bin/docker-startup.sh
        env:
        - name: NACOS_REPLICAS
          value: "3"
        - name: MYSQL_SERVICE_HOST
          valueFrom:
            configMapKeyRef:
              key: mysql.host
              name: nacos2-cm
        - name: MYSQL_SERVICE_DB_NAME
          valueFrom:
            configMapKeyRef:
              key: mysql.db.name
              name: nacos2-cm
        - name: MYSQL_SERVICE_PORT
          valueFrom:
            configMapKeyRef:
              key: mysql.port
              name: nacos2-cm
        - name: MYSQL_SERVICE_USER
          valueFrom:
            configMapKeyRef:
              key: mysql.user
              name: nacos2-cm
        - name: MYSQL_SERVICE_PASSWORD
          valueFrom:
            configMapKeyRef:
              key: mysql.password
              name: nacos2-cm
        - name: JAVA_OPT
          value: -Dnacos.core.auth.server.identity.key=authKey -Dnacos.core.auth.server.identity.value=nacosSecurty
            -Dnacos.core.auth.plugin.nacos.token.secret.key=SecretKey012345678901234567890123456789012345678901234567890123456789
        - name: NACOS_AUTH_ENABLE
          value: "true"
        - name: SPRING_DATASOURCE_PLATFORM
          value: mysql
        - name: MODE
          value: cluster
        - name: NACOS_SERVER_PORT
          value: "8848"
        - name: PREFER_HOST_MODE
          value: hostname
        - name: NACOS_SERVERS
          value: nacos2-0.nacos2.us.svc.cluster.local:8848 nacos2-1.nacos2.us.svc.cluster.local:8848
            nacos2-2.nacos2.us.svc.cluster.local:8848
        image: nacos/nacos-server:v2.2.0-slim
        imagePullPolicy: Always
        livenessProbe:
          failureThreshold: 3
          httpGet:
            path: /nacos/actuator/health
            port: api
            scheme: HTTP
          initialDelaySeconds: 20
          periodSeconds: 10
          successThreshold: 1
          timeoutSeconds: 8
        name: nacos2
        ports:
        - containerPort: 8848
          name: api
          protocol: TCP
        - containerPort: 9848
          name: client-rpc
          protocol: TCP
        - containerPort: 9849
          name: raft-rpc
          protocol: TCP
        - containerPort: 7848
          name: old-raft-rpc
          protocol: TCP
        readinessProbe:
          failureThreshold: 3
          httpGet:
            path: /nacos/actuator/health
            port: api
            scheme: HTTP
          initialDelaySeconds: 20
          periodSeconds: 10
          successThreshold: 1
          timeoutSeconds: 8
        resources:
          limits:
            cpu: "4"
            memory: 8Gi
          requests:
            cpu: 10m
            memory: 20Mi
        startupProbe:
          failureThreshold: 30
          httpGet:
            path: /nacos/actuator/health
            port: api
            scheme: HTTP
          periodSeconds: 10
          successThreshold: 1
          timeoutSeconds: 5
        terminationMessagePath: /dev/termination-log
        terminationMessagePolicy: File
      dnsPolicy: ClusterFirst
      imagePullSecrets:
      - name: ytdocker
      restartPolicy: Always
      schedulerName: default-scheduler
      securityContext: {}
      terminationGracePeriodSeconds: 30
  updateStrategy:
    rollingUpdate:
      partition: 0
    type: RollingUpdate
---

apiVersion: v1
kind: Service
metadata:
  labels:
    app: nacos2
  name: nacos2
  namespace: us
spec:
  ports:
  - name: server
    port: 8848
    protocol: TCP
    targetPort: 8848
    nodePort: 30048
  - name: client-rpc
    port: 9848
    protocol: TCP
    targetPort: 9848
  - name: raft-rpc
    port: 9849
    protocol: TCP
    targetPort: 9849
  - name: old-raft-rpc
    port: 7848
    protocol: TCP
    targetPort: 7848
  selector:
    app: nacos2
  #type: ClusterIP
  type: NodePort

---

apiVersion: v1
data:
  mysql.db.name: nacos_test
  mysql.host: 192.168.3.233
  mysql.password: OhJ2aima3Aexahwee
  mysql.port: "13306"
  mysql.user: root
kind: ConfigMap
metadata:
  annotations:
    kubectl.kubernetes.io/last-applied-configuration: |
      {"apiVersion":"v1","data":{"mysql.db.name":"nacos_test","mysql.host":"192.168.3.233","mysql.password":"OhJ2aima3Aexahwee","mysql.port":"13306","mysql.user":"root"},"kind":"ConfigMap","metadata":{"annotations":{},"name":"nacos2-cm","namespace":"us"}}
  name: nacos2-cm
  namespace: us

```

```
create database nacos default character set utf8mb4;
create user nacos@'%' identified WITH mysql_native_password BY "wqL4DHTf";
grant all privileges on nacos.* to nacos@'%' ;
```

生产 nacos 不同的是 configmap 文件，定义的数据库地址不一样

```shell
apiVersion: v1
data:
  mysql.db.name: nacos_v2
  mysql.host: tms-mysql-cluster.cluster-c2bihysdu6ok.ap-east-1.rds.amazonaws.com
  mysql.password: oneiN9teeKil3eezu
  mysql.port: "3536"
  mysql.user: nacos_v2
kind: ConfigMap
metadata:
  creationTimestamp: "2023-06-11T12:20:36Z"
  name: nacos-cm
  namespace: ops
  resourceVersion: "295162280"
  uid: 96e65416-1064-463d-9f74-1c35e65a6f24
```

登录web界面

```
http://192.168.3.101:30048/nacos/#/login
```

默认sql 导入后的用户和密码为

```
nacos / nacos
```
