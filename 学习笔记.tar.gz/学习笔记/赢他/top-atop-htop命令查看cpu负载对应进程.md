top、atop 和 htop 都是 Linux 系统上的监控工具，用于查看系统资源和进程活动。以下是它们之间的主要比较：

```tex
top 是一个基本的实时进程监控工具，内置于大多数 Linux 发行版中。
它以文本模式显示当前运行的进程列表和系统资源使用情况，包括 CPU、内存、交换空间等。

htop 是一个交互式的实时进程监控工具，提供了更友好的界面和更多的功能。
它以彩色显示的方式展示进程列表

atop 是一个功能强大的性能监控工具，可以记录系统活动和资源使用情况，适用于性能分析。
它提供了丰富的历史数据记录功能，可以查看过去的资源使用情况和进程活动。
```

top 命令

```shell
top
```

htop 命令，更直观的彩色模式展示shell

```shell
htop
#指定刷新间隔10s
htop -d 10

#进入后
#直接输入数字：查找进程id
#大写P: 切换到CPU排序
#大写M：切换到内存排序
#t：取消排序，再按一次启动排序
```

atop 命令，可以查看实时负载，也可以查看历史负载

```shell
atop 
#指定2s刷新一次
atop  2
#指定2s刷新一次，刷新5次后退出
atop 2 5 
#回放模式查看历史监控数据（进入后 t 下一个时间，b 跳转到指定时间）
atop -r /var/log/atop/atop_20250121
```



根据进程 id 查看详细启动命令

```shell
top
PID USER      PR  NI    VIRT    RES    SHR S  %CPU %MEM     TIME+ COMMAND                                                                                                          
 4711 root      20   0  932096 157724  84408 S 120.0  0.1  15737:44 k3s-agent                                                                                                        
15750 root      20   0   14.5g   4.7g  12028 S  12.9  3.8   3694:22 java           
```

查看 15750 进程命令

```shell
cat /proc/15750/cmdline 
/opt/java/openjdk//bin/java-server-Duser.timezone=Asia/Shanghai-Xms4g-Xmx4g-Xmn2g-XX:+PrintGCDetails-Xloggc:gc.log-XX:+HeapDumpOnOutOfMemoryError-XX:HeapDumpPath=dump.hprof-XX:-UseContainerSupport-cp/opt/dolphinscheduler/conf:/opt/dolphinscheduler/libs/*org.apache.dolphinscheduler.server.worker.WorkerServerYou have mail in /var/spool/mail/root
```

或者

```shell
 ps aux | grep 15750
root      2600  0.0  0.0 112896   496 pts/2    S+   11:10   0:00 grep --color=auto 15750
root     15750  4.2  3.7 15262056 4965996 ?    Sl    2024 3694:30 /opt/java/openjdk//bin/java -server -Duser.timezone=Asia/Shanghai -Xms4g -Xmx4g -Xmn2g -XX:+PrintGCDetails -Xloggc:gc.log -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=dump.hprof -XX:-UseContainerSupport -cp /opt/dolphinscheduler/conf:/opt/dolphinscheduler/libs/* org.apache.dolphinscheduler.server.worker.WorkerServer
```

根据进程 id 查看监听的端口

```shell
ss -l | grep 15750 

netstat -tulnp | grep 15750 

lsof -i -p 15750
```

