[TOC]



### 配置时间同步

安装 ntpdate 命令

```
sudo apt update
sudo apt install ntpdate -y
```

同步阿里云

```
timedatectl set-timezone Asia/Shanghai
ntpdate ntp.aliyun.com
```

检查时间

```
date

timedatectl
```

### 下载安装aws命令

（https://docs.aws.amazon.com/zh_cn/cli/latest/userguide/getting-started-install.html#cliv2-linux-install）

```shell
curl "https://awscli.amazonaws.com/awscli-exe-linux-aarch64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install

aws --version
```

配置aws密钥和key

```shell
aws configure set aws_access_key_id "AKIAQYEI44N6JUIW2PI3"
aws configure set aws_secret_access_key "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"
aws configure set default.region "eu-central-1"
```



### 下载安装kubectl命令

(https://docs.aws.amazon.com/zh_cn/eks/latest/userguide/install-kubectl.html#kubectl-install-update)

```shell
curl -O https://s3.us-west-2.amazonaws.com/amazon-eks/1.31.0/2024-09-12/bin/linux/arm64/kubectl
curl -O https://s3.us-west-2.amazonaws.com/amazon-eks/1.31.0/2024-09-12/bin/linux/amd64/kubectl

chmod +x ./kubectl
mkdir -p $HOME/bin && cp ./kubectl $HOME/bin/kubectl && export PATH=$HOME/bin:$PATH

echo 'export PATH=$HOME/bin:$PATH' >> ~/.bashrc
kubectl version --client
aws eks update-kubeconfig --region region-code --name my-cluster
```

### 下载 eksctl 工具

```shell
ARCH=arm64
PLATFORM=$(uname -s)_$ARCH
curl -sLO "https://github.com/eksctl-io/eksctl/releases/latest/download/eksctl_$PLATFORM.tar.gz"
curl -sL "https://github.com/eksctl-io/eksctl/releases/latest/download/eksctl_checksums.txt" | grep $PLATFORM | sha256sum --check
tar -xzf eksctl_$PLATFORM.tar.gz -C /tmp && rm eksctl_$PLATFORM.tar.gz
sudo mv /tmp/eksctl /usr/local/bin
```

#### eksctl 查看集群

```shell
eksctl get cluster
NAME            REGION          EKSCTL CREATED
US-eks-prod     us-east-1       False
```

```
aws eks update-kubeconfig --region ap-east-1 --name UAT-hk-eks-cluster
```



#### 创建 OIDC 提供商

确定您的集群的 OIDC 发布者 ID

```shell
cluster_name=EU-eks-prod
cluster_name=test-eks-update
```

```shell
oidc_id=$(aws eks describe-cluster --name $cluster_name --query "cluster.identity.oidc.issuer" --output text | cut -d '/' -f 5)
```

```shell
echo $oidc_id
A0EB78DC899D001F190115A62726FC64
```

确定您的账户中是否已存在具有您的集群发布者 ID 的 IAM OIDC 提供商。

```shell
aws iam list-open-id-connect-providers | grep $oidc_id | cut -d "/" -f4
（NULL）
```

使用以下命令为您的集群创建 IAM OIDC 身份提供商

```shell
eksctl utils associate-iam-oidc-provider --cluster $cluster_name --approve
```

再次查看是否存在OIDC提供商

```shell
aws iam list-open-id-connect-providers | grep $oidc_id | cut -d "/" -f4
6FC8187976AE667275217CA37EE384A9"
```

生成 kubeconfig 文件

```
aws eks update-kubeconfig --region region --name cluster-name
```



### 安装 AWS Load Balancer Controller 插件

参考文档：（https://docs.aws.amazon.com/zh_cn/eks/latest/userguide/lbc-helm.html）

下载 iam 策略

```shell
curl -O https://raw.githubusercontent.com/kubernetes-sigs/aws-load-balancer-controller/v2.7.2/docs/install/iam_policy.json
```

#### 创建一个 IAM 策略

（使用上一步中下载的策略）

```shell
aws iam create-policy \
    --policy-name AWSLoadBalancerControllerIAMPolicy \
    --policy-document file://iam_policy.json
    
aws iam create-policy \
    --policy-name test_eks_IAMPolicy \
    --policy-document file://iam_policy.json
```

#### 创建 iam 角色

```shell
eksctl create iamserviceaccount \
  --cluster=US-eks-prod  \
  --namespace=kube-system \
  --name=aws-load-balancer-controller \
  --role-name AmazonEKSLoadBalancerControllerRole \
  --attach-policy-arn=arn:aws:iam::051826713468:policy/AWSLoadBalancerControllerIAMPolicy \
  --approve
  
  
eksctl create iamserviceaccount \
  --cluster=Pre-us-eks  \
  --namespace=kube-system \
  --name=us-pre-aws-load-balancer-controller \
  --role-name USUATAmazonEKSLoadBalancerControllerRole \
  --attach-policy-arn=arn:aws:iam::051826713468:policy/USUATAWSLoadBalancerControllerIAMPolicy \
  --approve
  
eksctl get iamserviceaccount --cluster=Pre-us-eks
```

查看是否创建成功

```shell
eksctl get iamserviceaccount --cluster=EU-eks-prod 
NAMESPACE       NAME                            ROLE ARN
kube-system     aws-load-balancer-controller    arn:aws:iam::051826713468:role/AmazonEKSLoadBalancerControllerRole
```



#### 在IAM控制台给 role 新增 admin权限，aws默认给的权限后面部署 Alb 会报错权限不足

![image-20241017110535661](C:\Users\admin\AppData\Roaming\Typora\typora-user-images\image-20241017110535661.png)



私有子网部署需要在 aws vpc 界面给私有子网全部添加一个标签，以让 aws loadbalacer controller 创建负载均衡器的时候可以自动选择到对应的子网，不然会报错

添加标签：

```
kubernetes.io/role/internal-elb  1
```

#### 安装helm命令

官网：https://helm.sh/zh/docs/intro/install/

```shell
curl https://baltocdn.com/helm/signing.asc | gpg --dearmor | sudo tee /usr/share/keyrings/helm.gpg > /dev/null

sudo apt-get install apt-transport-https --yes

echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/helm.gpg] https://baltocdn.com/helm/stable/debian/ all main" | sudo tee /etc/apt/sources.list.d/helm-stable-debian.list

sudo apt-get update
sudo apt-get install helm

helm version
```



![image-20241017110340845](C:\Users\admin\AppData\Roaming\Typora\typora-user-images\image-20241017110340845.png)

1. 添加 `eks-charts` Helm 图表存储库。AWS 在 GitHub 上维护[此存储库](https://github.com/aws/eks-charts)。

   ```
   helm repo add eks https://aws.github.io/eks-charts
   ```

2. 更新您的本地存储库，以确保您拥有最新的图表。

   ```
   helm repo update eks
   ```

3. 安装 AWS Load Balancer Controller。

   将 `my-cluster` 替换为您的集群名称。在以下命令中，`aws-load-balancer-controller` 是您在上一步中创建的 Kubernetes 服务账户。

   有关配置 Helm 图表的更多信息，请参阅 GitHub 上的 [`values.yaml`](https://github.com/aws/eks-charts/blob/master/stable/aws-load-balancer-controller/values.yaml)。

   ```
   helm install aws-load-balancer-controller eks/aws-load-balancer-controller \
     -n kube-system \
     --set clusterName=EU-eks-prod \
     --set serviceAccount.create=false \
     --set serviceAccount.name=aws-load-balancer-controller 
     
     
   helm install aws-load-balancer-controller eks/aws-load-balancer-controller \
     -n kube-system \
     --set clusterName=Pre-us-eks \
     --set serviceAccount.create=false \
     --set serviceAccount.name=us-pre-aws-load-balancer-controller
   ```

#### 验证控制器是否已安装

1. 验证控制器是否已安装。

   ```
   kubectl get deployment -n kube-system aws-load-balancer-controller
   ```

   示例输出如下。

   ```
   kubectl get deployment -n kube-system aws-load-balancer-controller
   NAME                           READY   UP-TO-DATE   AVAILABLE   AGE
   aws-load-balancer-controller   2/2     2            2           2m14s
   ```

### 安装 nginx-controller 控制器

编写文件 ingress-nginx-controller.yaml

```yaml
#apiVersion: v1
#kind: Namespace
#metadata:
#  labels:
#    app.kubernetes.io/instance: ingress-nginx
#    app.kubernetes.io/name: ingress-nginx
#  name: ingress-nginx
#---
apiVersion: v1
automountServiceAccountToken: true
kind: ServiceAccount
metadata:
  labels:
    app.kubernetes.io/component: controller
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.11.2
  name: ingress-nginx
  namespace: ingress-nginx
---
apiVersion: v1
automountServiceAccountToken: true
kind: ServiceAccount
metadata:
  labels:
    app.kubernetes.io/component: admission-webhook
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.11.2
  name: ingress-nginx-admission
  namespace: ingress-nginx
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  labels:
    app.kubernetes.io/component: controller
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.11.2
  name: ingress-nginx
  namespace: ingress-nginx
rules:
- apiGroups:
  - ""
  resources:
  - namespaces
  verbs:
  - get
- apiGroups:
  - ""
  resources:
  - configmaps
  - pods
  - secrets
  - endpoints
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - ""
  resources:
  - services
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - networking.k8s.io
  resources:
  - ingresses
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - networking.k8s.io
  resources:
  - ingresses/status
  verbs:
  - update
- apiGroups:
  - networking.k8s.io
  resources:
  - ingressclasses
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - coordination.k8s.io
  resourceNames:
  - ingress-nginx-leader
  resources:
  - leases
  verbs:
  - get
  - update
- apiGroups:
  - coordination.k8s.io
  resources:
  - leases
  verbs:
  - create
- apiGroups:
  - ""
  resources:
  - events
  verbs:
  - create
  - patch
- apiGroups:
  - discovery.k8s.io
  resources:
  - endpointslices
  verbs:
  - list
  - watch
  - get
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  labels:
    app.kubernetes.io/component: admission-webhook
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.11.2
  name: ingress-nginx-admission
  namespace: ingress-nginx
rules:
- apiGroups:
  - ""
  resources:
  - secrets
  verbs:
  - get
  - create
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  labels:
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.11.2
  name: ingress-nginx
rules:
- apiGroups:
  - ""
  resources:
  - configmaps
  - endpoints
  - nodes
  - pods
  - secrets
  - namespaces
  verbs:
  - list
  - watch
- apiGroups:
  - coordination.k8s.io
  resources:
  - leases
  verbs:
  - list
  - watch
- apiGroups:
  - ""
  resources:
  - nodes
  verbs:
  - get
- apiGroups:
  - ""
  resources:
  - services
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - networking.k8s.io
  resources:
  - ingresses
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - ""
  resources:
  - events
  verbs:
  - create
  - patch
- apiGroups:
  - networking.k8s.io
  resources:
  - ingresses/status
  verbs:
  - update
- apiGroups:
  - networking.k8s.io
  resources:
  - ingressclasses
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - discovery.k8s.io
  resources:
  - endpointslices
  verbs:
  - list
  - watch
  - get
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  labels:
    app.kubernetes.io/component: admission-webhook
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.11.2
  name: ingress-nginx-admission
rules:
- apiGroups:
  - admissionregistration.k8s.io
  resources:
  - validatingwebhookconfigurations
  verbs:
  - get
  - update
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  labels:
    app.kubernetes.io/component: controller
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.11.2
  name: ingress-nginx
  namespace: ingress-nginx
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: ingress-nginx
subjects:
- kind: ServiceAccount
  name: ingress-nginx
  namespace: ingress-nginx
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  labels:
    app.kubernetes.io/component: admission-webhook
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.11.2
  name: ingress-nginx-admission
  namespace: ingress-nginx
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: ingress-nginx-admission
subjects:
- kind: ServiceAccount
  name: ingress-nginx-admission
  namespace: ingress-nginx
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  labels:
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.11.2
  name: ingress-nginx
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: ingress-nginx
subjects:
- kind: ServiceAccount
  name: ingress-nginx
  namespace: ingress-nginx
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  labels:
    app.kubernetes.io/component: admission-webhook
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.11.2
  name: ingress-nginx-admission
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: ingress-nginx-admission
subjects:
- kind: ServiceAccount
  name: ingress-nginx-admission
  namespace: ingress-nginx
---
apiVersion: v1
data:
  allow-snippet-annotations: "false"
  http-snippet: |
    server {
      listen 2443;
      return 308 https://$host$request_uri;
    }
  proxy-real-ip-cidr: 172.33.0.0/16
  use-forwarded-headers: "true"
kind: ConfigMap
metadata:
  labels:
    app.kubernetes.io/component: controller
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.11.2
  name: ingress-nginx-controller
  namespace: ingress-nginx
---
apiVersion: v1
kind: Service
metadata:
  annotations:
    service.beta.kubernetes.io/aws-load-balancer-connection-idle-timeout: "300"
    service.beta.kubernetes.io/aws-load-balancer-attributes: deletion_protection.enabled=true
    service.beta.kubernetes.io/aws-load-balancer-cross-zone-load-balancing-enabled: "true"
    service.beta.kubernetes.io/aws-load-balancer-backend-protocol: tcp
    service.beta.kubernetes.io/aws-load-balancer-type: nlb
  labels:
    app.kubernetes.io/component: controller
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.11.2
  name: ingress-nginx-controller
  namespace: ingress-nginx
spec:
  externalTrafficPolicy: Local
  ipFamilies:
  - IPv4
  ipFamilyPolicy: SingleStack
  ports:
  - appProtocol: http
    name: http
    nodePort: 32017
    port: 80
    protocol: TCP
    targetPort: http
  - appProtocol: https
    name: https
    nodePort: 30705
    port: 443
    protocol: TCP
    targetPort: https  
  selector:
    app.kubernetes.io/component: controller
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
  type: LoadBalancer
---
apiVersion: v1
kind: Service
metadata:
  labels:
    app.kubernetes.io/component: controller
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.11.2
  name: ingress-nginx-controller-admission
  namespace: ingress-nginx
spec:
  ports:
  - appProtocol: https
    name: https-webhook
    port: 443
    targetPort: webhook
  selector:
    app.kubernetes.io/component: controller
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
  type: ClusterIP
---
apiVersion: apps/v1
kind: DaemonSet
metadata:
  labels:
    app.kubernetes.io/component: controller
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.11.2
  name: ingress-nginx-controller
  namespace: ingress-nginx
spec:
  selector:
    matchLabels:
      app.kubernetes.io/component: controller
      app.kubernetes.io/instance: ingress-nginx
      app.kubernetes.io/name: ingress-nginx
  template:
    metadata:
      labels:
        app.kubernetes.io/component: controller
        app.kubernetes.io/instance: ingress-nginx
        app.kubernetes.io/name: ingress-nginx
        app.kubernetes.io/part-of: ingress-nginx
        app.kubernetes.io/version: 1.11.2
    spec:
      containers:
      - args:
        - /nginx-ingress-controller
        - --publish-service=$(POD_NAMESPACE)/ingress-nginx-controller
        - --election-id=ingress-nginx-leader
        - --controller-class=k8s.io/ingress-nginx
        - --ingress-class=nginx
        - --configmap=$(POD_NAMESPACE)/ingress-nginx-controller
        - --validating-webhook=:8443
        - --validating-webhook-certificate=/usr/local/certificates/cert
        - --validating-webhook-key=/usr/local/certificates/key
        - --enable-metrics=false
        env:
        - name: POD_NAME
          valueFrom:
            fieldRef:
              fieldPath: metadata.name
        - name: POD_NAMESPACE
          valueFrom:
            fieldRef:
              fieldPath: metadata.namespace
        - name: LD_PRELOAD
          value: /usr/local/lib/libmimalloc.so
        image: registry.k8s.io/ingress-nginx/controller:v1.11.2@sha256:d5f8217feeac4887cb1ed21f27c2674e58be06bd8f5184cacea2a69abaf78dce
        imagePullPolicy: IfNotPresent
        lifecycle:
          preStop:
            exec:
              command:
              - /wait-shutdown
        livenessProbe:
          failureThreshold: 5
          httpGet:
            path: /healthz
            port: 10254
            scheme: HTTP
          initialDelaySeconds: 10
          periodSeconds: 10
          successThreshold: 1
          timeoutSeconds: 1
        name: controller
        ports:
        - containerPort: 80
          name: http
          protocol: TCP
        - containerPort: 443
          name: https
          protocol: TCP
        - containerPort: 2443
          name: tohttps
          protocol: TCP
        - containerPort: 8443
          name: webhook
          protocol: TCP
        readinessProbe:
          failureThreshold: 3
          httpGet:
            path: /healthz
            port: 10254
            scheme: HTTP
          initialDelaySeconds: 10
          periodSeconds: 10
          successThreshold: 1
          timeoutSeconds: 1
        resources:
          requests:
            cpu: 100m
            memory: 90Mi
        securityContext:
          allowPrivilegeEscalation: false
          capabilities:
            add:
            - NET_BIND_SERVICE
            drop:
            - ALL
          readOnlyRootFilesystem: false
          runAsNonRoot: true
          runAsUser: 101
          seccompProfile:
            type: RuntimeDefault
        volumeMounts:
        - mountPath: /usr/local/certificates/
          name: webhook-cert
          readOnly: true
      dnsPolicy: ClusterFirst
      nodeSelector:
        kubernetes.io/os: linux
      serviceAccountName: ingress-nginx
      terminationGracePeriodSeconds: 300
      volumes:
      - name: webhook-cert
        secret:
          secretName: ingress-nginx-admission

---
apiVersion: batch/v1
kind: Job
metadata:
  labels:
    app.kubernetes.io/component: admission-webhook
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.11.2
  name: ingress-nginx-admission-create
  namespace: ingress-nginx
spec:
  template:
    metadata:
      labels:
        app.kubernetes.io/component: admission-webhook
        app.kubernetes.io/instance: ingress-nginx
        app.kubernetes.io/name: ingress-nginx
        app.kubernetes.io/part-of: ingress-nginx
        app.kubernetes.io/version: 1.11.2
      name: ingress-nginx-admission-create
    spec:
      containers:
      - args:
        - create
        - --host=ingress-nginx-controller-admission,ingress-nginx-controller-admission.$(POD_NAMESPACE).svc
        - --namespace=$(POD_NAMESPACE)
        - --secret-name=ingress-nginx-admission
        env:
        - name: POD_NAMESPACE
          valueFrom:
            fieldRef:
              fieldPath: metadata.namespace
        image: registry.k8s.io/ingress-nginx/kube-webhook-certgen:v1.4.3@sha256:a320a50cc91bd15fd2d6fa6de58bd98c1bd64b9a6f926ce23a600d87043455a3
        imagePullPolicy: IfNotPresent
        name: create
        securityContext:
          allowPrivilegeEscalation: false
          capabilities:
            drop:
            - ALL
          readOnlyRootFilesystem: true
          runAsNonRoot: true
          runAsUser: 65532
          seccompProfile:
            type: RuntimeDefault
      nodeSelector:
        kubernetes.io/os: linux
      restartPolicy: OnFailure
      serviceAccountName: ingress-nginx-admission
---
apiVersion: batch/v1
kind: Job
metadata:
  labels:
    app.kubernetes.io/component: admission-webhook
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.11.2
  name: ingress-nginx-admission-patch
  namespace: ingress-nginx
spec:
  template:
    metadata:
      labels:
        app.kubernetes.io/component: admission-webhook
        app.kubernetes.io/instance: ingress-nginx
        app.kubernetes.io/name: ingress-nginx
        app.kubernetes.io/part-of: ingress-nginx
        app.kubernetes.io/version: 1.11.2
      name: ingress-nginx-admission-patch
    spec:
      containers:
      - args:
        - patch
        - --webhook-name=ingress-nginx-admission
        - --namespace=$(POD_NAMESPACE)
        - --patch-mutating=false
        - --secret-name=ingress-nginx-admission
        - --patch-failure-policy=Fail
        env:
        - name: POD_NAMESPACE
          valueFrom:
            fieldRef:
              fieldPath: metadata.namespace
        image: registry.k8s.io/ingress-nginx/kube-webhook-certgen:v1.4.3@sha256:a320a50cc91bd15fd2d6fa6de58bd98c1bd64b9a6f926ce23a600d87043455a3
        imagePullPolicy: IfNotPresent
        name: patch
        securityContext:
          allowPrivilegeEscalation: false
          capabilities:
            drop:
            - ALL
          readOnlyRootFilesystem: true
          runAsNonRoot: true
          runAsUser: 65532
          seccompProfile:
            type: RuntimeDefault
      nodeSelector:
        kubernetes.io/os: linux
      restartPolicy: OnFailure
      serviceAccountName: ingress-nginx-admission
---
apiVersion: networking.k8s.io/v1
kind: IngressClass
metadata:
  labels:
    app.kubernetes.io/component: controller
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.11.2
  name: nginx
spec:
  controller: k8s.io/ingress-nginx
---
apiVersion: admissionregistration.k8s.io/v1
kind: ValidatingWebhookConfiguration
metadata:
  labels:
    app.kubernetes.io/component: admission-webhook
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.11.2
  name: ingress-nginx-admission
webhooks:
- admissionReviewVersions:
  - v1
  clientConfig:
    service:
      name: ingress-nginx-controller-admission
      namespace: ingress-nginx
      path: /networking/v1/ingresses
  failurePolicy: Fail
  matchPolicy: Equivalent
  name: validate.nginx.ingress.kubernetes.io
  rules:
  - apiGroups:
    - networking.k8s.io
    apiVersions:
    - v1
    operations:
    - CREATE
    - UPDATE
    resources:
    - ingresses
  sideEffects: None
```

创建命名空间

```
kubectl create ns ingress-nginx
```

执行文件

```
kubectl apply -f ingress-nginx-controller.yaml
```

查看pod和svc

(svc 出现自动生成的 loadBalancer 为成功)

```
kubectl get pod -n ingress-nginx 
NAME                                        READY   STATUS      RESTARTS   AGE
ingress-nginx-admission-create-9l4zh        0/1     Completed   0          14h
ingress-nginx-admission-patch-2686g         0/1     Completed   0          14h
ingress-nginx-controller-7896ff5667-dq95j   1/1     Running     0          14h
ingress-nginx-controller-7896ff5667-g285d   1/1     Running     0          14h

kubectl get svc -n ingress-nginx 
NAME                                 TYPE           CLUSTER-IP      EXTERNAL-IP                                                                     PORT(S)                      AGE
ingress-nginx-controller             LoadBalancer   10.100.225.66   k8s-ingressn-ingressn-460dd84a6b-56274baaa00e8743.elb.us-east-1.amazonaws.com   80:32017/TCP,443:30705/TCP   14h
ingress-nginx-controller-admission   ClusterIP      10.100.30.138   <none>                    
```

创建EFS存储插件

1 创建IAM角色

参考网址：

```
https://docs.aws.amazon.com/zh_cn/eks/latest/userguide/efs-csi.html
```

```yaml
export cluster_name=US-eks-prod
export cluster_name=UAT-hk-eks-cluster

export role_name=US_AmazonEKS_EFS_CSI_DriverRole
export role_name=HK_UAT_AmazonEKS_EFS_CSI_DriverRole

eksctl create iamserviceaccount \
    --name efs-csi-controller-sa \
    --namespace kube-system \
    --cluster $cluster_name \
    --role-name $role_name \
    --role-only \
    --attach-policy-arn arn:aws:iam::aws:policy/service-role/AmazonEFSCSIDriverPolicy \
    --approve
TRUST_POLICY=$(aws iam get-role --role-name $role_name --query 'Role.AssumeRolePolicyDocument' | \
    sed -e 's/efs-csi-controller-sa/efs-csi-*/' -e 's/StringEquals/StringLike/')
aws iam update-assume-role-policy --role-name $role_name --policy-document "$TRUST_POLICY"

eksctl create iamserviceaccount \
    --name hk-uat-efs-csi-controller-sa \
    --namespace kube-system \
    --cluster $cluster_name \
    --role-name $role_name \
    --role-only \
    --attach-policy-arn arn:aws:iam::aws:policy/service-role/AmazonEFSCSIDriverPolicy \
    --approve
TRUST_POLICY=$(aws iam get-role --role-name $role_name --query 'Role.AssumeRolePolicyDocument' | \
    sed -e 's/efs-csi-controller-sa/efs-csi-*/' -e 's/StringEquals/StringLike/')
aws iam update-assume-role-policy --role-name $role_name --policy-document "$TRUST_POLICY"
```

创建eks附加组件efs

参考网址：

```
https://docs.aws.amazon.com/zh_cn/eks/latest/userguide/creating-an-add-on.html
```

查看集群名称

```
eksctl get cluster
```

查看某个集群版本的可用附加组件名称。将 `1.31` 替换为您的集群版本。

```
eksctl utils describe-addon-versions --kubernetes-version 1.31 | grep AddonName
```

查看要创建的附加组件的可用版本

```
eksctl utils describe-addon-versions --kubernetes-version 1.31 --name EU-eks-prod | grep AddonVersion

eksctl utils describe-addon-versions --kubernetes-version 1.31 --name UAT-hk-eks-cluster | grep AddonVersion
```

确定您要创建的附加组件是 Amazon EKS 还是 AWS Marketplace 附加组件

(没有返回内容就是eks组件)

```
eksctl utils describe-addon-versions --kubernetes-version 1.31 --name name-of-addon | grep ProductUrl

```

创建 Amazon EKS 附加组件

```shell
eksctl create addon --cluster US-eks-prod --name aws-efs-csi-driver --version latest \
    --service-account-role-arn arn:aws:iam::051826713468:role/US_AmazonEKS_EFS_CSI_DriverRole --force
    
eksctl create addon --cluster UAT-hk-eks-cluster --name aws-efs-csi-driver --version latest \
    --service-account-role-arn arn:aws:iam::490241336062:role/US_AmazonEKS_EFS_CSI_DriverRole --force
```

#### 3 创建 Amazon EFS 文件系统

替换name为集群名字

```
vpc_id=$(aws eks describe-cluster \
    --name US-eks-prod \
    --query "cluster.resourcesVpcConfig.vpcId" \
    --output text)
    
vpc_id=$(aws eks describe-cluster \
    --name Pre-us-eks \
    --query "cluster.resourcesVpcConfig.vpcId" \
    --output text)
```

替换 region 区域为你所在区域

```
cidr_range=$(aws ec2 describe-vpcs \
    --vpc-ids $vpc_id \
    --query "Vpcs[].CidrBlock" \
    --output text \
    --region ap-east-1)
```

创建安全组，替换group-name 为自定义名

```
security_group_id=$(aws ec2 create-security-group \
    --group-name MyEfsSecurityGroup \
    --description "My EFS security group" \
    --vpc-id $vpc_id \
    --output text)

security_group_id=$(aws ec2 create-security-group \
    --group-name UsPreMyEfsSecurityGroup \
    --description "My EFS security group" \
    --vpc-id $vpc_id \
    --output text)
    
security_group_id=$(aws ec2 create-security-group \
    --group-name test_eks_SecurityGroup \
    --description "test_eks_SecurityGroup" \
    --vpc-id $vpc_id \
    --output text)
```

为集群的VPC创建允许NFS流量从CIDR流入的规则

```
aws ec2 authorize-security-group-ingress \
    --group-id $security_group_id \
    --protocol tcp \
    --port 2049 \
    --cidr $cidr_range
    
aws ec2 authorize-security-group-ingress \
    --group-id sg-0edfbdac7a3dfda61 \
    --protocol tcp \
    --port 2049 \
    --cidr $cidr_range
```

创建EFS文件系统，替换 region 区域为你所在区域

```
file_system_id=$(aws efs create-file-system \
    --region us-east-1 \
    --performance-mode generalPurpose \
    --query 'FileSystemId' \
    --output text)
    
    
file_system_id=$(aws efs create-file-system \
    --region us-east-1 \
    --performance-mode generalPurpose \
    --query 'FileSystemId' \
    --output text)

```

创建挂载目标，确定集群节点的 IP 地址

```
kubectl get nodes
NAME                                              STATUS   ROLES    AGE    VERSION
ip-172-33-130-244.eu-central-1.compute.internal   Ready    <none>   8d     v1.31.0-eks-a737599
ip-172-33-139-13.eu-central-1.compute.internal    Ready    <none>   7d1h   v1.31.0-eks-a737599
ip-172-33-140-102.eu-central-1.compute.internal   Ready    <none>   7d1h   v1.31.0-eks-a737599
```

确定您的 VPC 中子网的 ID 以及子网所在的可用区

```
aws ec2 describe-subnets \
    --filters "Name=vpc-id,Values=$vpc_id" \
    --query 'Subnets[*].{SubnetId: SubnetId,AvailabilityZone: AvailabilityZone,CidrBlock: CidrBlock}' \
    --output table
```

```
aws ec2 describe-subnets \
    --filters "Name=vpc-id,Values=$vpc_id" \
    --query 'Subnets[*].{SubnetId: SubnetId,AvailabilityZone: AvailabilityZone,CidrBlock: CidrBlock}' \
    --output table
---------------------------------------------------------------------
|                          DescribeSubnets                          |
+------------------+-------------------+----------------------------+
| AvailabilityZone |     CidrBlock     |         SubnetId           |
+------------------+-------------------+----------------------------+
|  eu-central-1c   |  172.33.160.0/20  |  subnet-0b973e1a7e0634541  |
|  eu-central-1b   |  172.33.192.0/20  |  subnet-0c6dce4b1b07e306d  |
|  eu-central-1a   |  172.33.0.0/20    |  subnet-014417643965d656b  |
|  eu-central-1c   |  172.33.208.0/20  |  subnet-00eac46ab3214c44e  |
|  eu-central-1c   |  172.33.32.0/20   |  subnet-04eaf0284bd236b1b  |
|  eu-central-1a   |  172.33.176.0/20  |  subnet-00b9a93e8e037cf5f  |
|  eu-central-1a   |  172.33.128.0/20  |  subnet-015e6fef1f277f2d8  |
|  eu-central-1b   |  172.33.16.0/20   |  subnet-0b3d04d08b325b9d5  |
|  eu-central-1b   |  172.33.144.0/20  |  subnet-03d53e9c24f2d888e  |
+------------------+-------------------+----------------------------+
```

为节点所在的子网添加挂载目标

```
subnet-08cdbfc5b022d2b47 
subnet-0566993686be367c3 
subnet-0299cb69591d37b70 
```

```
aws efs create-mount-target \
    --file-system-id $file_system_id \
    --subnet-id subnet-0299cb69591d37b70    \
    --security-groups $security_group_id
    
    
aws efs create-mount-target \
    --file-system-id $file_system_id \
    --subnet-id subnet-08ba44cfa56078777       \
    --security-groups $security_group_id

```

### 安装 flux 控制器

官网：（https://github.com/fluxcd/flux2/releases）

下载需要的版本，这里使用的是

至此全部部署结束，后面需要部署服务的参考其他文档

#### 执行 install 文件

这里下载的是2.30版本

```
wget https://github.com/fluxcd/flux2/releases/download/v2.3.0/install.yaml
kubectl apply -f install.yaml
```

#### 创建自动更新 aws-ecr 仓库 secrect 的脚本

```yaml
vim k8s-ecr-login-renew-cron.yaml

---
# Source: k8s-ecr-login-renew/templates/001-ServiceAccount.yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: k8s-ecr-login-renew-account
  namespace: eupre-ops
  labels:
    app.kubernetes.io/name: k8s-ecr-login-renew
    helm.sh/chart: k8s-ecr-login-renew-1.0.3
    app.kubernetes.io/instance: refreshecr
    app.kubernetes.io/version: 1.7.1
    app.kubernetes.io/managed-by: Helm
---
# Source: k8s-ecr-login-renew/templates/004-Secret.yaml
apiVersion: v1
kind: Secret
metadata:
  name: k8s-ecr-login-renew-aws-secret
  namespace: eupre-ops
  labels:
    app.kubernetes.io/name: k8s-ecr-login-renew
    helm.sh/chart: k8s-ecr-login-renew-1.0.3
    app.kubernetes.io/instance: refreshecr
    app.kubernetes.io/version: 1.7.1
    app.kubernetes.io/managed-by: Helm
type: Opaque
stringData:
  AWS_ACCESS_KEY_ID: AKIAV5ISR6EZZRTJB76X
  AWS_SECRET_ACCESS_KEY: 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
---
# Source: k8s-ecr-login-renew/templates/002-ClusterRole.yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: k8s-ecr-login-renew-role
  labels:
    app.kubernetes.io/name: k8s-ecr-login-renew
    helm.sh/chart: k8s-ecr-login-renew-1.0.3
    app.kubernetes.io/instance: refreshecr
    app.kubernetes.io/version: 1.7.1
    app.kubernetes.io/managed-by: Helm
rules:
  - apiGroups: [""]
    resources:
      - namespaces
    verbs:
      - list
  - apiGroups: [""]
    resources:
      - secrets
      - serviceaccounts
      - serviceaccounts/token
    verbs:
      - 'delete'
      - 'create'
      - 'patch'
      - 'get'
---
# Source: k8s-ecr-login-renew/templates/003-ClusterRoleBinding.yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: k8s-ecr-login-renew-binding
  labels:
    app.kubernetes.io/name: k8s-ecr-login-renew
    helm.sh/chart: k8s-ecr-login-renew-1.0.3
    app.kubernetes.io/instance: refreshecr
    app.kubernetes.io/version: 1.7.1
    app.kubernetes.io/managed-by: Helm
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: k8s-ecr-login-renew-role
subjects:
  - kind: ServiceAccount
    name: k8s-ecr-login-renew-account
    namespace: eupre-ops
---
# Source: k8s-ecr-login-renew/templates/005-CronJob.yaml
apiVersion: batch/v1
kind: CronJob
metadata:
  name: k8s-ecr-login-renew-cron
  namespace: eupre-ops
  labels:
    app.kubernetes.io/name: k8s-ecr-login-renew
    helm.sh/chart: k8s-ecr-login-renew-1.0.3
    app.kubernetes.io/instance: refreshecr
    app.kubernetes.io/version: 1.7.1
    app.kubernetes.io/managed-by: Helm
spec:
  #schedule: "1 */6 * * *"
  schedule: "*/1 * * * *"
  successfulJobsHistoryLimit: 3
  failedJobsHistoryLimit: 5
  jobTemplate:
    spec:
      template:
        metadata:
          labels:
            app.kubernetes.io/name: k8s-ecr-login-renew
            helm.sh/chart: k8s-ecr-login-renew-1.0.3
            app.kubernetes.io/instance: refreshecr
            app.kubernetes.io/version: 1.7.1
        spec:
          serviceAccountName: k8s-ecr-login-renew-account
          terminationGracePeriodSeconds: 0
          restartPolicy: Never
          containers:
          - name: k8s-ecr-login-renew
            imagePullPolicy: IfNotPresent
            image: nabsul/k8s-ecr-login-renew:main
            env:
            - name: AWS_ACCESS_KEY_ID
              valueFrom:
                secretKeyRef:
                  name: k8s-ecr-login-renew-aws-secret
                  key: AWS_ACCESS_KEY_ID
            - name: AWS_SECRET_ACCESS_KEY
              valueFrom:
                secretKeyRef:
                  name: k8s-ecr-login-renew-aws-secret
                  key: AWS_SECRET_ACCESS_KEY
            - name: AWS_REGION
              value: ap-east-1
            - name: DOCKER_SECRET_NAME
              value: ytdocker
              # 修改为需要更新的 namespace
            - name: TARGET_NAMESPACE
              value: flux-eupre-erp-prod,flux-eupre-wms-prod,eupre-erp-prod,eupre-wms-prod,flux-eupre-bi-prod,eupre-bi-prod,eupre-ops,flux-eupre-ops,kube-system,eupre-xms-prod,flux-eupre-xms-prod
            - name: DOCKER_REGISTRIES
              value: dockerhub-prod.yintaerp.com
```

### 安装flux

#### 安装awscli命令

指定版本，老版本2.0.0cli命令

```shell
curl -s https://fluxcd.io/install.sh | sudo FLUX_VERSION=2.0.0 bash
```

安装最新版本flux cli 命令

```shell
curl -s https://fluxcd.io/install.sh | sudo bash
```

查看版本

```shell
flux --version
flux version 2.3.0
```

### 安装Metrics监控指标组件

#### 下载 components 文件

```shell
wget https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml
kubectl apply -f components.yaml
```

查看状态

```shell
kubectl get deployments.apps -n kube-system metrics-server
NAME             READY   UP-TO-DATE   AVAILABLE   AGE
metrics-server   1/1     1            1           47d
```

#### 验证，查看节点负载

```shell
kubectl top node 
NAME                                              CPU(cores)   CPU%   MEMORY(bytes)   MEMORY%   
ip-172-33-156-48.eu-central-1.compute.internal    351m         2%     57887Mi         46%       
ip-172-33-170-144.eu-central-1.compute.internal   407m         2%     61903Mi         49%       
```

### 拉取香港生产的 gitea 仓库

#### copy ssh 私钥文件

```shell
vim .ssh/id_rsa 

-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAABlwAAAAdzc2gtcn
NhAAAAAwEAAQAAAYEA62UDxhd3ykMO6q3y8iE0C+nXOLSj7SfqDTH3GdD9uABDKqy1iGUj
twoyH03cBhirFl7G9ZsFiyrJT1rckNNdKpcSaP5aR3iOsqD39dY9pXWxHh9lp/W1uisSBZ
teT4jGat7AqizfCaLXhlScsx6oaBmBVgNRk08g5lBh2fYsnP4jpvTrbvhXYN8k9JVWV3JS
PEWUt+6VVECkdcUtrNb19IoCg9cJ6wynHVjid/mEQ+kHFqzuMyq+scCNVkzsfYX/p6h95f
dybwmYnrbAyDzD6VenkQG2I6FV8P0QvveWqTitogBrKZ74dQSnCBzZ62FOjjHTuVDl+gKY
B49VfhEi3ijUubbwGo8BJoyngljWHCNcQimfWDTFRUMjaapEl3L40/aBbaoVlkGQ3czxDF
+7ZThe+TBvLNeIrhHXkiaaTGJ2TFSCvkCUJMOI/RFXruF5gjqUwPbWGUTSpaIC2LbfQ3+t
rXfXtDXLjTVDLE9ARYoivijZl8VKxao3xcLw5JL9AAAFiFosiBFaLIgRAAAAB3NzaC1yc2
EAAAGBAOtlA8YXd8pDDuqt8vIhNAvp1zi0o+0n6g0x9xnQ/bgAQyqstYhlI7cKMh9N3AYY
qxZexvWbBYsqyU9a3JDTXSqXEmj+Wkd4jrKg9/XWPaV1sR4fZaf1tborEgWbXk+IxmrewK
os3wmi14ZUnLMeqGgZgVYDUZNPIOZQYdn2LJz+I6b06274V2DfJPSVVldyUjxFlLfulVRA
pHXFLazW9fSKAoPXCesMpx1Y4nf5hEPpBxas7jMqvrHAjVZM7H2F/6eofeX3cm8JmJ62wM
g8w+lXp5EBtiOhVfD9EL73lqk4raIAayme+HUEpwgc2ethTo4x07lQ5foCmAePVX4RIt4o
1Lm28BqPASaMp4JY1hwjXEIpn1g0xUVDI2mqRJdy+NP2gW2qFZZBkN3M8Qxfu2U4Xvkwby
zXiK4R15ImmkxidkxUgr5AlCTDiP0RV67heYI6lMD21hlE0qWiAti230N/ra1317Q1y401
QyxPQEWKIr4o2ZfFSsWqN8XC8OSS/QAAAAMBAAEAAAGAJqIZkHVhj6yZ0iJicSLJ6/qg/A
mJre6TFz9QEsieG4jPfT2DPbN7vRrLRx/8MHP0AGPlu4GJ02FeUMvUz2AhNlA9EUZNgtVi
dia9C3fx/inmu87jXEGTZc6T0p/BRsRn7DpK3KMop+g1/zH71dn+QbeN5pP823RtLd+bb6
5bfBipuUkRKtFPZfK5mfq4hPmaTZIN6nIZyA4j78BA0tEk5NGRwBmW4yDcfJCN+qrU7mBc
bXhMT9GAIqQ7jiJp3eAT2MwDep5PZE/mEH/1PxK+sf1fVuQFNgyKUUfFkYc/FOwz6XaPSD
CUx0aYqA7YXDVmQgd5kECAbNkaZE2XS1qDex73RydCuyaPshCVyc+4jc7KwyeoFpdZ7NMr
WBlkjXNt0oCNAJXavsOBHZbxv3Q6fGCOPC7DvgYs6Q14C/7UwCQWXroM3zISe+2HkJ4Zi/
hm0s32OfGy3/FCQdewF8i5u028O0l+sSJvQwbwmQ1Yb9eMthrzJw2eEJlfJMXLCvNxAAAA
wG59Nbibgrj27ngqvbxIGeqWkbjStQOyxoiuw9aKRU1dP2YuxYn4lbmQQ3lPDs7bPekAd+
YeVBLrgX390h9M30HpV6V3eWs97k6fLrVwemx9jXqWkpLNXw1nfTtsA95UCYUu1w74C3rY
bwdtJQ2IgXE28OuibS/kvBqnYDZircqiRix9/wwLD+79aUjs3IxG5BpF65I17d/4+rD9Ox
HX9HW7XBxzhZL+Q6UlsSPJnL9HxL04X1BtCSfzMZmcQNon6wAAAMEA/hwtjU6a3PTAdg9b
LI2x8lbkj/NGiIUv3VQrZrN1B6OMFARnXaDPflIYczek7hb2vfFyO2vtG800uypyyGo0Ax
Ys6iAtzXqcpPGWxG4QDYXlKUCuBNlPUZ7ryoDUEIGQijn9R1NBUgCMzwdV3TP+JvKJl8oI
oFzkBbIAUVJiKm0d236izdNxEi3h886i98AR2BQElVD9gn3mN2YCf+/nQUlPHEGrTcN7rA
tz0awxnOmmKi+czX23OJPuvvA26lmXAAAAwQDtJTPpzRECuRuNhUXVYHxiS3bV8d9rd4ja
lWgfUMdgAULuXazPtX9Q3orOOB5ajBHCBml+zBuuGEYiB4BXvTz6bngQXIuY7Ok0MwMqge
Yy/4KqatEwVgWbvkx9D9CE2VahK9HnPzweNu1fmPjOfjvZMLtHAUwQSgUdzEAhuXMWaz3o
Tge0SIoIx0PhC6CUDK3xcFIZwGNa/JDFlYp/mbYgsJ7mYH3UwnaXnUy8dYPTLs0s4IzO1L
w+v6gtpL97QosAAAAScm9vdEBpcC0xMC0wLTMtMjI0AQ==
-----END OPENSSH PRIVATE KEY-----
```

#### 修改文件权限

```shell
chmod 400 .ssh/id_rsa 
```

香港生产gitea 部署在 10.0.139.96 ，elk-tmp-2 机器上，安全组开一下

#### 验证，克隆仓库

```shell
git clone ssh://git@apm.prod.yintaerp.com:2222/ops/aws-deploy-prod.git
```

### 安装kuboard

docker 启动 kuboard（在香港aws-jenkins上/opt/kuboard目录启动）

```shell
sudo docker run -d \
  --restart=unless-stopped \
  --name=kuboard \
  -p 8080:80/tcp \
  -p 10081:10081/tcp \
  -e KUBOARD_ENDPOINT="http://172.34.139.239:8080" \
  -e KUBOARD_AGENT_SERVER_TCP_PORT="10081" \
  -v /root/kuboard-data:/data \
  eipwork/kuboard:v3
```

默认用户密码：

```shell
admin / Kuboard123
```

