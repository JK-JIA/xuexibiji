chat写的配置

```
[
        {
                "url":"jdbc:mysql://pre-hk-02-cluster.cluster-c2bihysdu6ok.ap-east-1.rds.amazonaws.com:5036/o2oa?autoReconnect=true&useUnicode=true&characterEncoding=UTF-8&useLegacyDatetimeCode=false&serverTimezone=Asia/Shanghai&socketTimeout=30000&connectTimeout=30000&tcpKeepAlive=true",      
                "username" : "o2oa",
                "password" :"Ew@RWpwQh123",
                "includes": [],
                "excludes": [],
                "enable" : true
        }
]
```

生产写的配置

```
[
        {
                "url":"jdbc:mysql://mysql8-bms.cluster-cuh7qkv6weck.ap-east-1.rds.amazonaws.com:3306/o2oa?autoReconnect=true&useUnicode=true&characterEncoding=UTF-8&useLegacyDatetimeCode=false&serverTimezone=GMT%2B8",      
                "username" : "o2oa",
                "password" :"Ew@RWpwQh123",
                "includes": [],
                "excludes": [],
                "enable" : true
        }
]
```

```
[
        {
                "url":"jdbc:mysql://pre-hk-02-cluster.cluster-c2bihysdu6ok.ap-east-1.rds.amazonaws.com:5036/o2oa?autoReconnect=true&useUnicode=true&characterEncoding=UTF-8&useLegacyDatetimeCode=false&serverTimezone=GMT%2B8",      
                "username" : "o2oa",
                "password" :"Ew@RWpwQh123",
                "includes": [],
                "excludes": [],
                "enable" : true
        }
]
```

