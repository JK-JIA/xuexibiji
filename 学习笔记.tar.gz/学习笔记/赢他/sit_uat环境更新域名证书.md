# sit/uat环境更新域名证书

1 登录 3.248 nginx 服务器

证书文件都放在 /etc/letsencrypt/live 文件夹

```shell
ls /etc/letsencrypt/live

bi-sit.yintaerp.com      eu-sit.yintaerp.com  ms-uat.yintaerp.com-0001   uat.yintaerp.com      www.dwvo.xyz           www.yitaliving.xyz
bi-uat.yintaerp.com      eu-uat.yintaerp.com  nacos2.eu-us.yintaerp.com  uspre.yintaerp.com    www.geo-tower.xyz      www.yitamotor.xyz
dev.yintaerp.com         eu.yintaerp.com      README                     us-sit.yintaerp.com   www.ledkingdom-us.xyz  yintaerp.com
erp-sit.yintaerp.com     hkpre.winjie.net     s3.yintaerp.com            us-uat.yintaerp.com   www.oedro.xyz          yitaoms.yitaerp.com
erp-uat.yintaerp.com     hkpre.yintaerp.com   sit.yintaerp.com           us.yintaerp.com       www.taoautoparts.xyz
eupre.yintaerp.com       lkt.ink              spider-uat.yintaerp.com    wms-uat.yintaerp.com  www.yintatech.xyz
eupre.yintaerp.com-0001  ms-uat.yintaerp.com  test.yintaerp.com          www.autosaver88.xyz   www.yitalife.xyz
```

2 证书更新脚本

:::
这个脚本 `renew.sh` 是一个用于自动更新 Let's Encrypt SSL 证书的 Bash 脚本。它通过遍历 `/etc/letsencrypt/live/` 目录下的所有域名目录，找到与 `yintaerp.com/lkt.ink/winjie.net` 相关的域名，并使用 `certbot` 工具来更新这些域名的通配符证书（`*.yintaerp.com/lkt.ink/winjie.net`）
:::
```shell
cat  /root/aliyun-cert/renew.sh 
#!/bin/bash
for ii in `ls -d /etc/letsencrypt/live/* |grep 'yintaerp.com'`
do
    dnsname=`basename $ii`
    certbot certonly -n -d "*.${dnsname}" --manual --preferred-challenges dns --manual-auth-hook "alidns" --manual-cleanup-hook "alidns clean"
done


for kk in `ls -d /etc/letsencrypt/live/* |grep 'lkt.ink'`
do
	    dnsname=`basename $kk`
	        certbot certonly -n -d "*.${dnsname}" --manual --preferred-challenges dns --manual-auth-hook "alidns" --manual-cleanup-hook "alidns clean"
	done

for ii in `ls -d /etc/letsencrypt/live/* |grep 'winjie.net'`
do
    dnsname=`basename $ii`
    certbot certonly -n -d "*.${dnsname}" --manual --preferred-challenges dns --manual-auth-hook "alidns" --manual-cleanup-hook "alidns clean"
done

```

执行证书更新脚本，大概需要十几分钟

```shell
sh /root/aliyun-cert/renew.sh
```

脚本执行完成后，查看证书时间戳，是否更新

```shell
ll /etc/letsencrypt/live/

total 164
drwx------ 40 root root 4096 Dec 12 13:15 ./
drwxr-xr-x 11 root root 4096 Feb 17 15:29 ../
drwxr-xr-x  2 root root 4096 Feb 12 14:34 bi-sit.yintaerp.com/
drwxr-xr-x  2 root root 4096 Feb 12 14:35 bi-uat.yintaerp.com/
drwxr-xr-x  2 root root 4096 Feb 12 14:35 dev.yintaerp.com/
drwxr-xr-x  2 root root 4096 Feb 12 14:35 erp-sit.yintaerp.com/
drwxr-xr-x  2 root root 4096 Feb 12 14:36 erp-uat.yintaerp.com/
drwxr-xr-x  2 root root 4096 Dec 11 14:03 eupre.yintaerp.com/
drwxr-xr-x  2 root root 4096 Feb 12 14:36 eupre.yintaerp.com-0001/
drwxr-xr-x  2 root root 4096 Feb 12 14:37 eu-sit.yintaerp.com/
drwxr-xr-x  2 root root 4096 Feb 12 14:37 eu-uat.yintaerp.com/
drwxr-xr-x  2 root root 4096 Feb 12 14:38 eu.yintaerp.com/
drwxr-xr-x  2 root root 4096 Feb 12 14:46 hkpre.winjie.net/
drwxr-xr-x  2 root root 4096 Feb 12 14:38 hkpre.yintaerp.com/
```

3 重启 nginx 

```shell
root@sh-3-201:~# /usr/local/openresty/nginx/sbin/nginx -t

nginx: [warn] conflicting server name "wms.sit.yintaerp.com" on 0.0.0.0:80, ignored
nginx: [warn] conflicting server name "wms.sit.yintaerp.com" on 0.0.0.0:80, ignored
nginx: [warn] conflicting server name "wms.sit.yintaerp.com" on 0.0.0.0:443, ignored
nginx: [warn] conflicting server name "wms.sit.yintaerp.com" on 0.0.0.0:443, ignored
nginx: the configuration file /usr/local/openresty/nginx/conf/nginx.conf syntax is ok
nginx: configuration file /usr/local/openresty/nginx/conf/nginx.conf test is successful
root@sh-3-201:~# 
root@sh-3-201:~# /usr/local/openresty/nginx/sbin/nginx -s reload 

nginx: [warn] conflicting server name "wms.sit.yintaerp.com" on 0.0.0.0:80, ignored
nginx: [warn] conflicting server name "wms.sit.yintaerp.com" on 0.0.0.0:80, ignored
nginx: [warn] conflicting server name "wms.sit.yintaerp.com" on 0.0.0.0:443, ignored
nginx: [warn] conflicting server name "wms.sit.yintaerp.com" on 0.0.0.0:443, ignored

```

2 更新外网 nginx 证书文件

将 3.248 nginx 服务器上的 archive 目录上传到外网 nginx 139.224.251.60 上

```shell
cd  /etc/letsencrypt
tar zcf archive.tar.gz archive
```

jumpserver 登录外网 nginx ( 服务器名称为：gitlab ，ip为：139.224.251.60 )

![1739778320267.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/eYVOLXr207kLOpz2/img/df09823b-5148-4c5b-878e-ccdbb629fa51.png)

备份 /etc/letsencrypt/archive 目录

```shell
cd /etc/letsencrypt
mv archive archive-20250212
```

上传文件 archive.tar.gz 到 /etc/letsencrypt 目录，解压

右键 gitlab 服务器，选择文件管理  >>  选择 aliyun 用户目录 >> 把 archive.tar.gz 文件拖入上传

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/eYVOLXr207kLOpz2/img/7a292a83-4dca-4b9b-ad3e-e7a06029ef72.png) ![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/eYVOLXr207kLOpz2/img/818dffcc-55c8-4757-9543-4d72182b7d12.png)

上传完毕后，默认上传到服务器的 /tmp 目录下，解压文件

```shell
cd /etc/letsencrypt
mv /tmp/archive.tar.gz ./
tar xf archive.tar.gz
```

重启外网 nginx 

```shell
[root@sh-yinta-nginx-01 ~]# /usr/local/openresty/nginx/sbin/nginx -t
nginx: [warn] conflicting server name "bi-gateway.bi-uat.yintaerp.com" on 0.0.0.0:80, ignored
nginx: [warn] could not build optimal server_names_hash, you should increase either server_names_hash_max_size: 512 or server_names_hash_bucket_size: 64; ignoring server_names_hash_bucket_size
nginx: [warn] conflicting server name "bi-gateway.bi-uat.yintaerp.com" on 0.0.0.0:443, ignored
nginx: [warn] could not build optimal server_names_hash, you should increase either server_names_hash_max_size: 512 or server_names_hash_bucket_size: 64; ignoring server_names_hash_bucket_size
nginx: the configuration file /usr/local/openresty/nginx/conf/nginx.conf syntax is ok
nginx: configuration file /usr/local/openresty/nginx/conf/nginx.conf test is successful

[root@sh-yinta-nginx-01 ~]# /usr/local/openresty/nginx/sbin/nginx -s reload 
nginx: [warn] conflicting server name "bi-gateway.bi-uat.yintaerp.com" on 0.0.0.0:80, ignored
nginx: [warn] could not build optimal server_names_hash, you should increase either server_names_hash_max_size: 512 or server_names_hash_bucket_size: 64; ignoring server_names_hash_bucket_size
nginx: [warn] conflicting server name "bi-gateway.bi-uat.yintaerp.com" on 0.0.0.0:443, ignored
nginx: [warn] could not build optimal server_names_hash, you should increase either server_names_hash_max_size: 512 or server_names_hash_bucket_size: 64; ignoring server_names_hash_bucket_size
```

查看网页证书已经更新

![image.png](https://alidocs.oss-cn-zhangjiakou.aliyuncs.com/res/eYVOLXr207kLOpz2/img/7df65ca6-7edd-4c74-8a3e-a9b73c11e77d.png)

备注：脚本生成的证书为免费证书，有效期 3 个月，所以需要每 3 个月更新一次