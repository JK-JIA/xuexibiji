1 登录 4904 控制台，扩容EBS 大小，原来为100G  >  500G
![image-20250123094148501](C:\Users\admin\AppData\Roaming\Typora\typora-user-images\image-20250123094148501.png)

2 等待 ebs 状态恢复正常，登录ec2 节点执行命令，扩容分区

```
lsblk
NAME          MAJ:MIN RM  SIZE RO TYPE MOUNTPOINT
nvme0n1       259:0    0  100G  0 disk 
├─nvme0n1p1   259:1    0  100G  0 part /
└─nvme0n1p128 259:2    0   10M  0 part /boot/efi
nvme1n1       259:3    0  500G  0 disk 
├─nvme1n1p1   259:4    0    5G  0 part /emr
└─nvme1n1p2   259:5    0  495G  0 part /mnt
```

扩容分区

```
growpart /dev/nvme0n1 1
```

查看分区大小

```
lsblk
NAME          MAJ:MIN RM  SIZE RO TYPE MOUNTPOINT
nvme0n1       259:0    0  500G  0 disk 
├─nvme0n1p1   259:1    0  500G  0 part /
└─nvme0n1p128 259:2    0   10M  0 part /boot/efi
nvme1n1       259:3    0  500G  0 disk 
├─nvme1n1p1   259:4    0    5G  0 part /emr
└─nvme1n1p2   259:5    0  495G  0 part /mnt
```

扩容文件系统

```
xfs_growfs /dev/nvme0n1p1
```

查看文件系统大小

```
df -hT | grep "/dev/nvme0n1p1 "
/dev/nvme0n1p1                                                                             xfs       500G   37G  464G   8% /
```

