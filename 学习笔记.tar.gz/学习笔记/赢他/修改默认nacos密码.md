连接上数据库，查看表结构（库名.表名）

```sql
SELECT * FROM eu_nacos.users;
```

数据库存储密码使用的为 bcrypt 加密，修改密码必须使用同样加密

使用在线网站生成 bcrypt 加密后的密码（nacos使用bcrypt 加密）

![image-20250318101303032](C:\Users\admin\AppData\Roaming\Typora\typora-user-images\image-20250318101303032.png)

```http
https://www.jisuan.mobi/nX7.html
https://www.bejson.com/encrypt/bcrpyt_encode/#google_vignette
```

```
密码：pre2@&bbCQSw
加密后的密码：$2a$10$MCQqrRJJ/I/LQwPJEvSJvuVdgMRCF1.NfivYftzU1/ite4QEJY4iC
```



修改 nacos 用户密码

```sql
UPDATE us_nacos.users 
SET password = '$2a$10$MCQqrRJJ/I/LQwPJEvSJvuVdgMRCF1.NfivYftzU1/ite4QEJY4iC' 
WHERE username = 'nacos';
```

修改 develop 密码

```
密码：bGNyWJ&fSH5F
加密后的密码：$2a$10$nMoxcx35owypY.qUMS4f3u8gvchZneEmuApdK71vSUAC45J6z3YU2
```

```sql
UPDATE us_nacos.users 
SET password = '$2a$10$nMoxcx35owypY.qUMS4f3u8gvchZneEmuApdK71vSUAC45J6z3YU2' 
WHERE username = 'develop';
```



修改 xxl-job-admin 的密码

使用在线网站生成 MD5 加密后的密码（xxl-job-admin 使用 MD5 加密）

```
https://www.json.cn/md5/
```

```
密码：DH3U^cs%644W
加密后的密码：6ab59fbcd1be8dc3fddcfded35dc35c1
```

```
UPDATE us_xxljob.xxl_job_user 
SET password = '6ab59fbcd1be8dc3fddcfded35dc35c1' 
WHERE username = 'admin';
```

