---
name: Bug report
about: Create a report to help us improve EBS CSI Driver
labels: 

---

/kind bug

**What happened?**

**What you expected to happen?**

**How to reproduce it (as minimally and precisely as possible)?**

**Anything else we need to know?**:

**Environment**
- Kubernetes version (use `kubectl version`):
- Driver version:
